"""Ajustes da parte Android (nome do app, permissões, notificações).
Roda no GitHub Actions depois do 'flutter create'. Como fica dentro do zip,
mudanças futuras na parte Android viajam junto com as atualizações."""
import os
import re

# ---------------- AndroidManifest.xml ----------------
p = 'android/app/src/main/AndroidManifest.xml'
s = open(p, encoding='utf-8').read()
s = re.sub(r'android:label="[^"]*"', 'android:label="Alvo Vita"', s, count=1)

android = ['ACCESS_FINE_LOCATION', 'ACCESS_COARSE_LOCATION', 'FOREGROUND_SERVICE',
           'FOREGROUND_SERVICE_LOCATION', 'POST_NOTIFICATIONS', 'WAKE_LOCK', 'INTERNET',
           'RECEIVE_BOOT_COMPLETED', 'VIBRATE']
perms = ['android.permission.' + n for n in android]
perms.append('com.android.alarm.permission.SET_ALARM')

linhas = ''.join('    <uses-permission android:name="%s"/>\n' % n
                 for n in perms if n not in s)
s = s.replace('<application', linhas + '    <application', 1)

# Receptores que fazem os lembretes funcionarem (e voltarem depois de reiniciar o celular)
receptores = '''
        <receiver android:exported="false"
            android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
        <receiver android:exported="false"
            android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
                <action android:name="android.intent.action.QUICKBOOT_POWERON"/>
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
            </intent-filter>
        </receiver>
'''
if 'ScheduledNotificationReceiver' not in s:
    s = s.replace('</application>', receptores + '    </application>', 1)
open(p, 'w', encoding='utf-8').write(s)
print('Manifest ajustado.')

# ---------------- build.gradle (desugaring pedido pelas notificações) ----------------
kts = 'android/app/build.gradle.kts'
groovy = 'android/app/build.gradle'
DESUGAR = 'com.android.tools:desugar_jdk_libs:2.1.4'

if os.path.exists(kts):
    g = open(kts, encoding='utf-8').read()
    if 'isCoreLibraryDesugaringEnabled' not in g:
        g = re.sub(r'(compileOptions\s*\{)',
                   r'\1\n        isCoreLibraryDesugaringEnabled = true', g, count=1)
    if 'desugar_jdk_libs' not in g:
        g += '\ndependencies {\n    coreLibraryDesugaring("%s")\n}\n' % DESUGAR
    open(kts, 'w', encoding='utf-8').write(g)
    print('build.gradle.kts ajustado.')
elif os.path.exists(groovy):
    g = open(groovy, encoding='utf-8').read()
    if 'coreLibraryDesugaringEnabled' not in g:
        g = re.sub(r'(compileOptions\s*\{)',
                   r'\1\n        coreLibraryDesugaringEnabled true', g, count=1)
    if 'desugar_jdk_libs' not in g:
        g += "\ndependencies {\n    coreLibraryDesugaring '%s'\n}\n" % DESUGAR
    open(groovy, 'w', encoding='utf-8').write(g)
    print('build.gradle ajustado.')
else:
    print('AVISO: build.gradle não encontrado')
