"""Ajustes da parte Android (nome do app e permissões).
Roda no GitHub Actions depois do 'flutter create'. Como fica dentro do zip,
mudanças futuras na parte Android viajam junto com as atualizações."""
import re

p = 'android/app/src/main/AndroidManifest.xml'
s = open(p, encoding='utf-8').read()
s = re.sub(r'android:label="[^"]*"', 'android:label="Alvo Vita"', s, count=1)

android = ['ACCESS_FINE_LOCATION', 'ACCESS_COARSE_LOCATION', 'FOREGROUND_SERVICE',
           'FOREGROUND_SERVICE_LOCATION', 'POST_NOTIFICATIONS', 'WAKE_LOCK', 'INTERNET']
perms = ['android.permission.' + n for n in android]
perms.append('com.android.alarm.permission.SET_ALARM')

linhas = ''.join('    <uses-permission android:name="%s"/>\n' % n
                 for n in perms if n not in s)
s = s.replace('<application', linhas + '    <application', 1)
open(p, 'w', encoding='utf-8').write(s)
print('Manifest ajustado.')
