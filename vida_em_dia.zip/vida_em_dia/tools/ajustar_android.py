"""Ajustes da parte Android (nome do app, permissões, notificações).
Roda no GitHub Actions depois do 'flutter create'. Como fica dentro do zip,
mudanças futuras na parte Android viajam junto com as atualizações."""
import os
import re

# ---------------- AndroidManifest.xml ----------------
p = 'android/app/src/main/AndroidManifest.xml'
s = open(p, encoding='utf-8').read()
s = re.sub(r'android:label="[^"]*"', 'android:label="Alvo Vita"', s, count=1)

android = ['ACCESS_FINE_LOCATION', 'ACCESS_COARSE_LOCATION', 'FOREGROUND_SERVICE',
           'FOREGROUND_SERVICE_LOCATION', 'POST_NOTIFICATIONS', 'WAKE_LOCK', 'INTERNET',
           'RECEIVE_BOOT_COMPLETED', 'VIBRATE']
perms = ['android.permission.' + n for n in android]
perms.append('com.android.alarm.permission.SET_ALARM')

linhas = ''.join('    <uses-permission android:name="%s"/>\n' % n
                 for n in perms if n not in s)
s = s.replace('<application', linhas + '    <application', 1)

# Receptores que fazem os lembretes funcionarem (e voltarem depois de reiniciar o celular)
receptores = '''
        <receiver android:exported="false"
            android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
        <receiver android:exported="false"
            android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
                <action android:name="android.intent.action.QUICKBOOT_POWERON"/>
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
            </intent-filter>
        </receiver>
'''
if 'ScheduledNotificationReceiver' not in s:
    s = s.replace('</application>', receptores + '    </application>', 1)
open(p, 'w', encoding='utf-8').write(s)
print('Manifest ajustado.')

# ---------------- build.gradle (desugaring pedido pelas notificações) ----------------
kts = 'android/app/build.gradle.kts'
groovy = 'android/app/build.gradle'
DESUGAR = 'com.android.tools:desugar_jdk_libs:2.1.4'

if os.path.exists(kts):
    g = open(kts, encoding='utf-8').read()
    if 'isCoreLibraryDesugaringEnabled' not in g:
        g = re.sub(r'(compileOptions\s*\{)',
                   r'\1\n        isCoreLibraryDesugaringEnabled = true', g, count=1)
    if 'desugar_jdk_libs' not in g:
        g += '\ndependencies {\n    coreLibraryDesugaring("%s")\n}\n' % DESUGAR
    open(kts, 'w', encoding='utf-8').write(g)
    print('build.gradle.kts ajustado.')
elif os.path.exists(groovy):
    g = open(groovy, encoding='utf-8').read()
    if 'coreLibraryDesugaringEnabled' not in g:
        g = re.sub(r'(compileOptions\s*\{)',
                   r'\1\n        coreLibraryDesugaringEnabled true', g, count=1)
    if 'desugar_jdk_libs' not in g:
        g += "\ndependencies {\n    coreLibraryDesugaring '%s'\n}\n" % DESUGAR
    open(groovy, 'w', encoding='utf-8').write(g)
    print('build.gradle ajustado.')
else:
    print('AVISO: build.gradle não encontrado')

# ---------------- gradle.properties (Java x Kotlin dos plugins) ----------------
# Alguns plugins (ex.: flutter_timezone) compilam Java com alvo 11 e Kotlin com 1.8,
# e o Gradle recusa a diferença. Isso transforma o erro em aviso.
gp = 'android/gradle.properties'
linha = 'kotlin.jvm.target.validation.mode=warning'
conteudo = open(gp, encoding='utf-8').read() if os.path.exists(gp) else ''
if linha not in conteudo:
    if conteudo and not conteudo.endswith('\n'):
        conteudo += '\n'
    open(gp, 'w', encoding='utf-8').write(conteudo + linha + '\n')
print('gradle.properties ajustado.')

# ---------------- Assinatura fixa (para o app ATUALIZAR em vez de pedir desinstalar) ----------------
# O GitHub cria uma chave nova a cada build; o Android recusa instalar por cima
# de um app assinado com outra chave. Aqui todo build usa a mesma chave.
import shutil
chave = 'tools/alvo-vita.keystore'
if os.path.exists(chave):
    shutil.copy(chave, 'android/app/alvo-vita.keystore')
    if os.path.exists(kts):
        g = open(kts, encoding='utf-8').read()
        if 'alvo-vita.keystore' not in g:
            g += '''
android {
    signingConfigs {
        getByName("debug") {
            storeFile = file("alvo-vita.keystore")
            storePassword = "alvovita123"
            keyAlias = "alvovita"
            keyPassword = "alvovita123"
        }
    }
}
'''
            open(kts, 'w', encoding='utf-8').write(g)
        print('Assinatura fixa configurada (kts).')
    elif os.path.exists(groovy):
        g = open(groovy, encoding='utf-8').read()
        if 'alvo-vita.keystore' not in g:
            g += '''
android {
    signingConfigs {
        debug {
            storeFile file("alvo-vita.keystore")
            storePassword "alvovita123"
            keyAlias "alvovita"
            keyPassword "alvovita123"
        }
    }
}
'''
            open(groovy, 'w', encoding='utf-8').write(g)
        print('Assinatura fixa configurada (groovy).')
else:
    print('AVISO: chave fixa não encontrada em tools/')

# ---------------- Ícone do coração (12 ícones que o app troca sozinho) ----------------
import glob
origem = 'tools/icones/res'
if os.path.isdir(origem):
    shutil.copytree(origem, 'android/app/src/main/res', dirs_exist_ok=True)

    nomes = ['H%d' % (100 - 10 * i) for i in range(11)] + ['HQ']
    icones = ['ic_h%d' % (100 - 10 * i) for i in range(11)] + ['ic_hq']
    s = open(p, encoding='utf-8').read()
    if 'activity-alias' not in s:
        # a MainActivity deixa de ser a "porta" do app: quem abre é o ícone (alias) ativo
        s = re.sub(r'<category android:name="android.intent.category.LAUNCHER"\s*/>', '', s, count=1)
        aliases = ''
        for i, (n, ic) in enumerate(zip(nomes, icones)):
            aliases += '''
        <activity-alias android:name=".%s"
            android:targetActivity=".MainActivity"
            android:icon="@mipmap/%s"
            android:label="Alvo Vita"
            android:enabled="%s"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity-alias>
''' % (n, ic, 'true' if i == 0 else 'false')
        s = s.replace('</application>', aliases + '    </application>', 1)
        s = re.sub(r'android:icon="@mipmap/ic_launcher"', 'android:icon="@mipmap/ic_launcher"', s)
        open(p, 'w', encoding='utf-8').write(s)
    print('Ícones do coração configurados.')

    # Parte nativa: troca o ícone quando o app pede
    achados = glob.glob('android/app/src/main/kotlin/**/MainActivity.kt', recursive=True)
    if achados:
        arq = achados[0]
        pacote = re.search(r'^package\s+([\w.]+)', open(arq, encoding='utf-8').read(), re.M)
        pacote = pacote.group(1) if pacote else 'com.alvovita.alvo_vita'
        kt = '''package %(pacote)s

import android.content.ComponentName
import android.content.pm.PackageManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val nomes = listOf(%(lista)s)

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "alvovita/icone")
            .setMethodCallHandler { call, result ->
                if (call.method == "definir") {
                    val indice = call.argument<Int>("indice") ?: 0
                    try {
                        trocar(indice)
                        result.success(true)
                    } catch (e: Exception) {
                        result.success(false)
                    }
                } else {
                    result.notImplemented()
                }
            }
    }

    private fun trocar(indice: Int) {
        val pm = packageManager
        // liga o novo antes de desligar os outros, para o app nunca ficar sem ícone
        for ((i, n) in nomes.withIndex()) {
            if (i == indice) {
                pm.setComponentEnabledSetting(
                    ComponentName(packageName, "%(pacote)s." + n),
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                    PackageManager.DONT_KILL_APP
                )
            }
        }
        for ((i, n) in nomes.withIndex()) {
            if (i != indice) {
                pm.setComponentEnabledSetting(
                    ComponentName(packageName, "%(pacote)s." + n),
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                    PackageManager.DONT_KILL_APP
                )
            }
        }
    }
}
''' % {'pacote': pacote, 'lista': ', '.join('"%s"' % n for n in nomes)}
        open(arq, 'w', encoding='utf-8').write(kt)
        print('MainActivity.kt atualizado (%s).' % arq)
    else:
        print('AVISO: MainActivity.kt não encontrado')
else:
    print('AVISO: ícones do coração não encontrados em tools/icones')
