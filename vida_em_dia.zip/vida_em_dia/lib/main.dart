import 'package:flutter/material.dart';

import 'core/armazenamento.dart';
import 'core/tema.dart';
import 'telas/navegacao.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Armazenamento.iniciar();
  final corSalva = Armazenamento.corSalva();
  if (corSalva != null) TemaApp.destaque.value = Color(corSalva);
  runApp(const VidaEmDiaApp());
}

class VidaEmDiaApp extends StatelessWidget {
  const VidaEmDiaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Color>(
      valueListenable: TemaApp.destaque,
      builder: (context, cor, _) => MaterialApp(
        title: 'Vida em Dia',
        debugShowCheckedModeBanner: false,
        theme: criarTema(Brightness.light, cor),
        darkTheme: criarTema(Brightness.dark, cor),
        themeMode: ThemeMode.system,
        home: const Navegacao(),
      ),
    );
  }
}
