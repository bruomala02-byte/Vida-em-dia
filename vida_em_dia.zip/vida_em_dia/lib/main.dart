import 'package:flutter/material.dart';

import 'core/armazenamento.dart';
import 'core/config.dart';
import 'core/tema.dart';
import 'telas/navegacao.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Armazenamento.iniciar();
  Config.carregar();
  final corSalva = Armazenamento.corSalva();
  if (corSalva != null) TemaApp.destaque.value = Color(corSalva);
  runApp(const AlvoVitaApp());
}

class AlvoVitaApp extends StatelessWidget {
  const AlvoVitaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Color>(
      valueListenable: TemaApp.destaque,
      builder: (context, cor, _) => ValueListenableBuilder<ThemeMode>(
        valueListenable: Config.modoTema,
        builder: (context, modo, _) => MaterialApp(
          title: 'Alvo Vita',
          debugShowCheckedModeBanner: false,
          theme: criarTema(Brightness.light, cor),
          darkTheme: criarTema(Brightness.dark, cor),
          themeMode: modo,
          home: const Navegacao(),
        ),
      ),
    );
  }
}
