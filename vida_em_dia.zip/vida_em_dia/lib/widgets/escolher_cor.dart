import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../core/armazenamento.dart';
import '../core/tema.dart';
import 'icones_app.dart';

/// Roda de cores: o ângulo escolhe a cor, a distância do centro escolhe a intensidade.
class RodaDeCor extends StatelessWidget {
  final HSVColor cor;
  final ValueChanged<HSVColor> aoMudar;
  final double tamanho;

  const RodaDeCor({super.key, required this.cor, required this.aoMudar, this.tamanho = 250});

  void _tocar(Offset p) {
    final d = p - Offset(tamanho / 2, tamanho / 2);
    var ang = math.atan2(d.dy, d.dx);
    if (ang < 0) ang += 2 * math.pi;
    final sat = (d.distance / (tamanho / 2)).clamp(0.0, 1.0);
    aoMudar(HSVColor.fromAHSV(1, ang * 180 / math.pi, sat, cor.value));
  }

  @override
  Widget build(BuildContext context) => GestureDetector(
        onPanDown: (d) => _tocar(d.localPosition),
        onPanUpdate: (d) => _tocar(d.localPosition),
        child: SizedBox(
          width: tamanho,
          height: tamanho,
          child: CustomPaint(painter: _RodaPainter(cor)),
        ),
      );
}

class _RodaPainter extends CustomPainter {
  final HSVColor cor;
  const _RodaPainter(this.cor);

  @override
  void paint(Canvas canvas, Size size) {
    final centro = size.center(Offset.zero);
    final raio = size.width / 2;
    final area = Rect.fromCircle(center: centro, radius: raio);

    canvas.drawCircle(
      centro,
      raio,
      Paint()
        ..shader = SweepGradient(colors: [
          for (var h = 0; h <= 360; h += 30) HSVColor.fromAHSV(1, h.toDouble(), 1, 1).toColor(),
        ]).createShader(area),
    );
    canvas.drawCircle(
      centro,
      raio,
      Paint()
        ..shader = RadialGradient(
          colors: [Colors.white, Colors.white.withValues(alpha: 0)],
        ).createShader(area),
    );
    canvas.drawCircle(
      centro,
      raio,
      Paint()..color = Colors.black.withValues(alpha: 1 - cor.value),
    );

    final ang = cor.hue * math.pi / 180;
    final alca = centro + Offset(math.cos(ang), math.sin(ang)) * (cor.saturation * raio);
    canvas.drawCircle(alca, 14, Paint()..color = Colors.white);
    canvas.drawCircle(alca, 11, Paint()..color = cor.toColor());
  }

  @override
  bool shouldRepaint(covariant _RodaPainter old) => old.cor != cor;
}

/// Conteúdo da janela "Cor do app".
class EscolherCor extends StatefulWidget {
  const EscolherCor({super.key});

  @override
  State<EscolherCor> createState() => _EscolherCorState();
}

class _EscolherCorState extends State<EscolherCor> {
  static const _prontas = [
    0xFFFF6B35, 0xFF00B894, 0xFF0984E3, 0xFFE84393,
    0xFF6C5CE7, 0xFFE74C3C, 0xFFF1C40F, 0xFF00CEC9,
  ];

  late HSVColor _hsv = HSVColor.fromColor(TemaApp.destaque.value);

  Future<void> _aplicar() async {
    final cor = _hsv.toColor();
    TemaApp.destaque.value = cor;
    await Armazenamento.salvarCor(cor.toARGB32());
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final cor = _hsv.toColor();
    final textoSobre = ThemeData.estimateBrightnessForColor(cor) == Brightness.dark
        ? Colors.white
        : Colors.black;

    return SingleChildScrollView(
      padding: EdgeInsets.fromLTRB(20, 0, 20, MediaQuery.of(context).viewPadding.bottom + 20),
      child: Column(
        children: [
          Text('Cor do app',
              style: Theme.of(context)
                  .textTheme
                  .titleLarge
                  ?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          const Text('Arraste o dedo na roda para misturar a cor que você quiser.'),
          const SizedBox(height: 16),
          RodaDeCor(cor: _hsv, aoMudar: (c) => setState(() => _hsv = c)),
          const SizedBox(height: 8),
          Row(children: [
            const Icon(Icons.brightness_6),
            Expanded(
              child: Slider(
                value: _hsv.value,
                min: 0.3,
                max: 1,
                activeColor: cor,
                onChanged: (v) => setState(() => _hsv = _hsv.withValue(v)),
              ),
            ),
          ]),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              for (final p in _prontas)
                GestureDetector(
                  onTap: () => setState(() => _hsv = HSVColor.fromColor(Color(p))),
                  child: CircleAvatar(radius: 18, backgroundColor: Color(p)),
                ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: cor.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(18),
            ),
            child: Row(children: [
              IconeApp(TipoIcone.livro, tamanho: 44, cor: cor),
              const SizedBox(width: 12),
              IconeApp(TipoIcone.pes, tamanho: 34, cor: cor),
              const SizedBox(width: 12),
              Expanded(
                child: Container(
                  height: 40,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: cor,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Text('Prévia', style: TextStyle(color: textoSobre, fontWeight: FontWeight.w700)),
                ),
              ),
            ]),
          ),
          const SizedBox(height: 16),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: cor,
              foregroundColor: textoSobre,
            ),
            onPressed: _aplicar,
            child: const Text('Usar esta cor'),
          ),
        ],
      ),
    );
  }
}
