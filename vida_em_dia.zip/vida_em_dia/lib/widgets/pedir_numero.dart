import 'package:flutter/material.dart';

/// Janelinha para a pessoa digitar um número inteiro (ex.: a meta de água).
/// Devolve o número escolhido, ou null se ela cancelar.
Future<int?> pedirNumero(
  BuildContext context, {
  required String titulo,
  required int atual,
  required String unidade,
  required int minimo,
  required int maximo,
}) {
  final controle = TextEditingController(text: '$atual');
  String? erro;

  return showDialog<int>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setLocal) {
        void confirmar() {
          final v = int.tryParse(controle.text.trim());
          if (v == null || v < minimo || v > maximo) {
            setLocal(() => erro = 'Digite um número entre $minimo e $maximo');
            return;
          }
          Navigator.pop(ctx, v);
        }

        return AlertDialog(
          title: Text(titulo),
          content: TextField(
            controller: controle,
            autofocus: true,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(suffixText: unidade, errorText: erro),
            onSubmitted: (_) => confirmar(),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
            TextButton(onPressed: confirmar, child: const Text('Salvar')),
          ],
        );
      },
    ),
  );
}
