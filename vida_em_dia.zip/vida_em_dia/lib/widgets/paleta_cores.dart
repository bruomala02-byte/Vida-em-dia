import 'package:flutter/material.dart';

import 'escolher_cor.dart' show RodaDeCor;

/// Tabela de cores prontas + seletor livre (roda de cores e código).
/// Serve para qualquer lugar do app em que a pessoa escolhe uma cor.
class PaletaCores extends StatelessWidget {
  final Color atual;
  final ValueChanged<Color> aoEscolher;

  /// Se vier, aparece como a primeira cor ("cor do app").
  final Color? corDoApp;

  const PaletaCores({
    super.key,
    required this.atual,
    required this.aoEscolher,
    this.corDoApp,
  });

  static const prontas = <Color>[
    Color(0xFFFFFFFF), // branco
    Color(0xFF000000), // preto
    Color(0xFF1C1C1E), // grafite
    Color(0xFF8E8E93), // cinza
    Color(0xFFFFD60A), // amarelo
    Color(0xFFFF9F0A), // laranja
    Color(0xFFFF6B35), // laranja do app
    Color(0xFFFF453A), // vermelho
    Color(0xFFFF2D55), // rosa
    Color(0xFFBF5AF2), // roxo
    Color(0xFF0A84FF), // azul
    Color(0xFF40C8E0), // turquesa
    Color(0xFF30D158), // verde
  ];

  bool _igual(Color a, Color b) => a.toARGB32() == b.toARGB32();

  Future<void> _livre(BuildContext context) async {
    final c = await escolherCorLivre(context, atual);
    if (c != null) aoEscolher(c);
  }

  @override
  Widget build(BuildContext context) {
    final escuro = Theme.of(context).brightness == Brightness.dark;
    final borda = escuro ? Colors.white60 : Colors.black45;
    final destaque = Theme.of(context).colorScheme.primary;
    final lista = <Color>[if (corDoApp != null) corDoApp!, ...prontas];
    final naLista = lista.any((c) => _igual(c, atual));

    Widget bolinha(Color c, {bool app = false}) {
      final sel = _igual(c, atual);
      final claro = ThemeData.estimateBrightnessForColor(c) == Brightness.light;
      return GestureDetector(
        onTap: () => aoEscolher(c),
        child: Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(
            color: c,
            shape: BoxShape.circle,
            border: Border.all(color: sel ? destaque : borda, width: sel ? 3 : 1.2),
          ),
          child: sel
              ? Icon(Icons.check, size: 20, color: claro ? Colors.black : Colors.white)
              : (app
                  ? Icon(Icons.star, size: 16, color: claro ? Colors.black : Colors.white)
                  : null),
        ),
      );
    }

    return Wrap(
      spacing: 10,
      runSpacing: 10,
      crossAxisAlignment: WrapCrossAlignment.center,
      children: [
        for (var i = 0; i < lista.length; i++) bolinha(lista[i], app: corDoApp != null && i == 0),
        // cor escolhida à mão, que não está na tabela
        if (!naLista) bolinha(atual),
        GestureDetector(
          onTap: () => _livre(context),
          child: Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: borda, width: 1.2),
              gradient: const SweepGradient(colors: [
                Color(0xFFFF453A),
                Color(0xFFFFD60A),
                Color(0xFF30D158),
                Color(0xFF0A84FF),
                Color(0xFFBF5AF2),
                Color(0xFFFF453A),
              ]),
            ),
            child: const Icon(Icons.add, size: 22, color: Colors.white),
          ),
        ),
      ],
    );
  }
}

/// Janela para misturar qualquer cor: roda, brilho (até o preto) e código.
Future<Color?> escolherCorLivre(BuildContext context, Color inicial) {
  return showDialog<Color>(
    context: context,
    builder: (_) => _DialogoCorLivre(inicial: inicial),
  );
}

class _DialogoCorLivre extends StatefulWidget {
  final Color inicial;
  const _DialogoCorLivre({required this.inicial});

  @override
  State<_DialogoCorLivre> createState() => _DialogoCorLivreState();
}

class _DialogoCorLivreState extends State<_DialogoCorLivre> {
  late HSVColor _hsv = HSVColor.fromColor(widget.inicial);
  late final TextEditingController _hex = TextEditingController(text: _codigo(widget.inicial));

  static String _codigo(Color c) =>
      (c.toARGB32() & 0xFFFFFF).toRadixString(16).padLeft(6, '0').toUpperCase();

  @override
  void dispose() {
    _hex.dispose();
    super.dispose();
  }

  void _mudou(HSVColor h) {
    setState(() => _hsv = h);
    _hex.text = _codigo(h.toColor());
  }

  void _digitou(String t) {
    final limpo = t.replaceAll('#', '').trim();
    if (limpo.length != 6) return;
    final v = int.tryParse(limpo, radix: 16);
    if (v == null) return;
    setState(() => _hsv = HSVColor.fromColor(Color(0xFF000000 | v)));
  }

  @override
  Widget build(BuildContext context) {
    final cor = _hsv.toColor();
    return AlertDialog(
      title: const Text('Escolher cor'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            RodaDeCor(cor: _hsv, aoMudar: _mudou, tamanho: 220),
            Row(children: [
              const Icon(Icons.brightness_6),
              Expanded(
                child: Slider(
                  value: _hsv.value,
                  min: 0,
                  max: 1,
                  activeColor: cor,
                  onChanged: (v) => _mudou(_hsv.withValue(v)),
                ),
              ),
            ]),
            Row(children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: cor,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.grey),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextField(
                  controller: _hex,
                  onChanged: _digitou,
                  maxLength: 7,
                  decoration: const InputDecoration(
                    labelText: 'Código da cor',
                    prefixText: '#',
                    counterText: '',
                  ),
                ),
              ),
            ]),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
        TextButton(onPressed: () => Navigator.pop(context, cor), child: const Text('Usar')),
      ],
    );
  }
}
