import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../modelos/treino.dart';

/// Distância (m) entre dois pontos próximos.
double metrosEntre(Ponto a, Ponto b) {
  final dLat = (b.lat - a.lat) * 111320.0;
  final dLng = (b.lng - a.lng) * 111320.0 * math.cos(a.lat * math.pi / 180);
  return math.sqrt(dLat * dLat + dLng * dLng);
}

/// Um ponto do gráfico: posição em km e um valor (velocidade, altitude...).
class Amostra {
  final double km, valor;
  const Amostra(this.km, this.valor);
}

List<Amostra> _suavizar(List<Amostra> bruto) => [
      for (var i = 0; i < bruto.length; i++)
        () {
          final ini = math.max(0, i - 2), fim = math.min(bruto.length - 1, i + 2);
          var soma = 0.0;
          for (var j = ini; j <= fim; j++) {
            soma += bruto[j].valor;
          }
          return Amostra(bruto[i].km, soma / (fim - ini + 1));
        }(),
    ];

/// Velocidade (km/h) ao longo do percurso, suavizada. Ignora saltos do GPS (>25).
List<Amostra> calcularVelocidades(List<Ponto> p) {
  final bruto = <Amostra>[];
  var km = 0.0;
  for (var i = 1; i < p.length; i++) {
    final m = metrosEntre(p[i - 1], p[i]);
    km += m / 1000;
    final dt = p[i].s - p[i - 1].s;
    if (dt <= 0) continue;
    bruto.add(Amostra(km, (m / dt * 3.6).clamp(0.0, 25.0)));
  }
  return _suavizar(bruto);
}

/// Altitude (m) ao longo do percurso, suavizada.
List<Amostra> calcularAltitudes(List<Ponto> p) {
  final bruto = <Amostra>[];
  var km = 0.0;
  for (var i = 1; i < p.length; i++) {
    km += metrosEntre(p[i - 1], p[i]) / 1000;
    bruto.add(Amostra(km, p[i].alt));
  }
  return _suavizar(bruto);
}

/// km/h -> min/km (limitado a 15 quando está quase parado).
double ritmoDe(double kmh) => kmh < 4 ? 15.0 : 60 / kmh;

/// 5.5 -> "5:30"
String ritmoTexto(double minutos) {
  final t = (minutos * 60).round();
  return '${t ~/ 60}:${(t % 60).toString().padLeft(2, '0')}';
}

/// Tempo de cada km completo (e do pedaço final).
class Parcial {
  final double km;
  final int segundos;
  const Parcial(this.km, this.segundos);
}

List<Parcial> calcularParciais(List<Ponto> p) {
  final r = <Parcial>[];
  var dist = 0.0, tAnterior = 0.0, proximo = 1.0;
  for (var i = 1; i < p.length; i++) {
    final m = metrosEntre(p[i - 1], p[i]) / 1000;
    if (m <= 0) continue;
    final d0 = dist, d1 = dist + m;
    final t0 = p[i - 1].s.toDouble(), t1 = p[i].s.toDouble();
    while (d1 >= proximo) {
      final t = t0 + (t1 - t0) * (proximo - d0) / m;
      r.add(Parcial(1.0, (t - tAnterior).round()));
      tAnterior = t;
      proximo += 1;
    }
    dist = d1;
  }
  final resto = dist - (proximo - 1);
  if (p.isNotEmpty && resto >= 0.05) {
    r.add(Parcial(resto, (p.last.s - tAnterior).round()));
  }
  return r;
}

/// Gráfico de área. [menorEmCima] = true deixa o valor menor no topo
/// (usado no ritmo: quanto mais rápido, mais alto no gráfico).
class GraficoLinhaPainter extends CustomPainter {
  final List<Amostra> amostras;
  final String Function(double) rotulo;
  final bool menorEmCima;
  final Color cor;
  final Color corTexto;

  const GraficoLinhaPainter({
    required this.amostras,
    required this.rotulo,
    required this.menorEmCima,
    required this.cor,
    required this.corTexto,
  });

  void _texto(Canvas c, String t, Offset o, {bool direita = false}) {
    final tp = TextPainter(
      text: TextSpan(text: t, style: TextStyle(fontSize: 11, color: corTexto)),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(c, direita ? Offset(o.dx - tp.width, o.dy - tp.height / 2) : o);
  }

  @override
  void paint(Canvas canvas, Size size) {
    if (amostras.length < 2) return;
    const esq = 40.0, base = 22.0;
    final w = size.width - esq, h = size.height - base;
    final xMax = math.max(amostras.last.km, 0.01);

    final valores = amostras.map((a) => a.valor);
    var vMin = valores.reduce(math.min).floorToDouble();
    var vMax = valores.reduce(math.max).ceilToDouble();
    if (vMax - vMin < 2) vMax = vMin + 2;

    double x(double km) => esq + km / xMax * w;
    double y(double v) {
      final f = (v - vMin) / (vMax - vMin);
      return menorEmCima ? f * h : h - f * h;
    }

    final grade = Paint()
      ..color = corTexto.withValues(alpha: 0.2)
      ..strokeWidth = 1;
    for (var i = 0; i <= 3; i++) {
      final v = vMin + (vMax - vMin) * i / 3;
      canvas.drawLine(Offset(esq, y(v)), Offset(size.width, y(v)), grade);
      _texto(canvas, rotulo(v), Offset(esq - 6, y(v)), direita: true);
    }
    for (var km = 0; km <= xMax; km++) {
      _texto(canvas, '$km km', Offset(x(km.toDouble()) - 6, h + 6));
    }

    final linha = Path()..moveTo(x(amostras.first.km), y(amostras.first.valor));
    for (final a in amostras.skip(1)) {
      linha.lineTo(x(a.km), y(a.valor));
    }
    final area = Path.from(linha)
      ..lineTo(x(amostras.last.km), h)
      ..lineTo(x(amostras.first.km), h)
      ..close();
    canvas.drawPath(
      area,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [cor.withValues(alpha: 0.2), cor.withValues(alpha: 0.65)],
        ).createShader(Rect.fromLTWH(0, 0, size.width, h)),
    );
    canvas.drawPath(
      linha,
      Paint()
        ..color = cor
        ..strokeWidth = 2.5
        ..style = PaintingStyle.stroke
        ..strokeJoin = StrokeJoin.round,
    );
  }

  @override
  bool shouldRepaint(covariant GraficoLinhaPainter old) => true;
}
