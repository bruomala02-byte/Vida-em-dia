import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

import '../core/tema.dart';
import '../modelos/treino.dart';

/// Mapa de ruas (OpenStreetMap) com o percurso por cima.
/// [seguir] = true: modo "ao vivo", o mapa acompanha a posição atual.
/// [seguir] = false: enquadra o percurso inteiro (tela de resumo).
class MapaPercurso extends StatefulWidget {
  final List<Ponto> pontos;
  final bool seguir;
  final double margemInferior;

  const MapaPercurso({
    super.key,
    required this.pontos,
    this.seguir = false,
    this.margemInferior = 32,
  });

  @override
  State<MapaPercurso> createState() => _MapaPercursoState();
}

class _MapaPercursoState extends State<MapaPercurso> {
  final _controle = MapController();

  @override
  void didUpdateWidget(covariant MapaPercurso old) {
    super.didUpdateWidget(old);
    if (widget.seguir && widget.pontos.isNotEmpty) {
      final u = widget.pontos.last;
      // Depois do desenho da tela, para não mexer no mapa durante o build.
      WidgetsBinding.instance.addPostFrameCallback((_) {
        try {
          _controle.move(LatLng(u.lat, u.lng), _controle.camera.zoom);
        } catch (_) {
          // mapa ainda não está pronto: sem problema, tenta na próxima posição
        }
      });
    }
  }

  Widget _bolinha(Color cor) => Container(
        decoration: BoxDecoration(
          color: cor,
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white, width: 3),
          boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 4)],
        ),
      );

  @override
  Widget build(BuildContext context) {
    final pts = [for (final p in widget.pontos) LatLng(p.lat, p.lng)];

    if (pts.isEmpty) {
      return Container(
        color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: 0.4),
        alignment: Alignment.center,
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.map_outlined, size: 40, color: context.destaque),
            SizedBox(height: 8),
            Text('O mapa aparece quando a corrida começar',
                textAlign: TextAlign.center),
          ],
        ),
      );
    }

    final temPercurso = pts.any((p) => p != pts.first);
    final ajustar = !widget.seguir && temPercurso;

    return Stack(
      children: [
        FlutterMap(
          mapController: _controle,
          options: MapOptions(
            initialCenter: pts.last,
            initialZoom: 17,
            initialCameraFit: ajustar
                ? CameraFit.coordinates(
                    coordinates: pts,
                    padding: EdgeInsets.fromLTRB(32, 32, 32, widget.margemInferior),
                    maxZoom: 18,
                  )
                : null,
            interactionOptions: InteractionOptions(
              flags: InteractiveFlag.all & ~InteractiveFlag.rotate,
            ),
          ),
          children: [
            TileLayer(
              urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
              userAgentPackageName: 'com.alvovita.alvo_vita',
            ),
            if (pts.length >= 2)
              PolylineLayer(
                polylines: [
                  Polyline(
                    points: pts,
                    strokeWidth: 5,
                    color: context.destaque,
                    borderStrokeWidth: 2,
                    borderColor: Colors.white,
                  ),
                ],
              ),
            MarkerLayer(
              markers: [
                Marker(
                  point: pts.first,
                  width: 22,
                  height: 22,
                  child: _bolinha(const Color(0xFF2ECC71)),
                ),
                if (temPercurso)
                  Marker(
                    point: pts.last,
                    width: 22,
                    height: 22,
                    child: _bolinha(
                      widget.seguir ? const Color(0xFF0984E3) : const Color(0xFFE74C3C),
                    ),
                  ),
              ],
            ),
          ],
        ),
        Positioned(
          left: 6,
          top: 6,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
              color: Colors.white70,
              borderRadius: BorderRadius.circular(6),
            ),
            child: const Text(
              '© OpenStreetMap',
              style: TextStyle(fontSize: 10, color: Colors.black87),
            ),
          ),
        ),
      ],
    );
  }
}
