import 'package:flutter/material.dart';

import '../core/armazenamento.dart';

/// Aviso amigável: o histórico está ficando grande e pode deixar o app lento.
/// Só aparece quando o histórico passa do limite (veja Armazenamento.limiteAviso).
class AvisoHistorico extends StatelessWidget {
  /// Se informado, mostra o botão que leva para a tela de histórico.
  final VoidCallback? aoAbrir;
  const AvisoHistorico({super.key, this.aoAbrir});

  @override
  Widget build(BuildContext context) {
    if (!Armazenamento.historicoGrande()) return const SizedBox.shrink();

    final cores = Theme.of(context).colorScheme;
    return Card(
      color: cores.tertiaryContainer,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.warning_amber_rounded, color: cores.onTertiaryContainer),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Seu histórico está ficando grande',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                      color: cores.onTertiaryContainer,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              'Com o tempo, muitos dados guardados podem deixar o app e o celular '
              'mais lentos. Antes que isso aconteça, salve o check-in do mês '
              '(um arquivo com o resumo) e depois apague os dados antigos.',
              style: TextStyle(color: cores.onTertiaryContainer),
            ),
            if (aoAbrir != null) ...[
              const SizedBox(height: 8),
              TextButton(
                onPressed: aoAbrir,
                child: Text(
                  'Salvar check-in e limpar',
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                    color: cores.onTertiaryContainer,
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
