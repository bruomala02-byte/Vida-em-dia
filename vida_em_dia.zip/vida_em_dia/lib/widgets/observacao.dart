import 'package:flutter/material.dart';

import '../core/armazenamento.dart';
import '../core/formatos.dart';
import '../core/tema.dart';
import '../core/texto.dart';
import '../core/texto_rico.dart';

/// Botão quadrado simples da barra de formatação.
class _BotaoFormato extends StatelessWidget {
  final Widget filho;
  final bool ativo;
  final VoidCallback? aoTocar;
  const _BotaoFormato({required this.filho, this.ativo = false, this.aoTocar});

  @override
  Widget build(BuildContext context) {
    final cor = context.destaque;
    return InkWell(
      borderRadius: BorderRadius.circular(10),
      onTap: aoTocar,
      child: Container(
        width: 44,
        height: 40,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: ativo ? cor.withValues(alpha: 0.2) : null,
          border: Border.all(color: ativo ? cor : Colors.grey.withValues(alpha: 0.6)),
          borderRadius: BorderRadius.circular(10),
        ),
        child: filho,
      ),
    );
  }
}

/// Barra com N (negrito), marca-texto e etiqueta (opcionais).
/// Funciona para quem nunca viu nada disso: seleciona o texto e toca.
class BarraFormato extends StatelessWidget {
  final ControladorRico controlador;
  final ValueNotifier<int> etiqueta;
  final bool completo; // marca-texto e etiqueta

  const BarraFormato({
    super.key,
    required this.controlador,
    required this.etiqueta,
    this.completo = false,
  });

  @override
  Widget build(BuildContext context) {
    return TextFieldTapRegion(
      child: AnimatedBuilder(
        animation: controlador,
        builder: (context, _) {
          return Row(
            children: [
              Tooltip(
                message: 'Negrito',
                child: _BotaoFormato(
                  ativo: controlador.negritoAtivo,
                  aoTocar: controlador.alternarNegrito,
                  filho: const Text('N',
                      style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                ),
              ),
              if (completo) ...[
                const SizedBox(width: 8),
                PopupMenuButton<int>(
                  tooltip: 'Marca-texto',
                  onSelected: controlador.definirCor,
                  itemBuilder: (_) => [
                    for (var i = 0; i < coresMarca.length; i++)
                      PopupMenuItem<int>(
                        value: i,
                        child: Row(children: [
                          i == 0
                              ? const Icon(Icons.format_color_reset, size: 22)
                              : Container(
                                  width: 22,
                                  height: 22,
                                  decoration: BoxDecoration(
                                    color: coresMarca[i],
                                    borderRadius: BorderRadius.circular(5),
                                  ),
                                ),
                          const SizedBox(width: 12),
                          Text(nomesMarca[i]),
                        ]),
                      ),
                  ],
                  child: const _BotaoFormato(filho: Icon(Icons.border_color, size: 20)),
                ),
                const SizedBox(width: 8),
                ValueListenableBuilder<int>(
                  valueListenable: etiqueta,
                  builder: (context, et, _) => PopupMenuButton<int>(
                    tooltip: 'Etiqueta colorida',
                    onSelected: (v) => etiqueta.value = v,
                    itemBuilder: (_) => [
                      for (var i = 0; i < coresEtiqueta.length; i++)
                        PopupMenuItem<int>(
                          value: i,
                          child: Row(children: [
                            i == 0
                                ? const Icon(Icons.label_off_outlined, size: 22)
                                : Icon(Icons.label, size: 22, color: coresEtiqueta[i]),
                            const SizedBox(width: 12),
                            Text(nomesEtiqueta[i]),
                          ]),
                        ),
                    ],
                    child: _BotaoFormato(
                      ativo: et > 0,
                      filho: Icon(
                        et > 0 ? Icons.label : Icons.label_outline,
                        size: 22,
                        color: et > 0 ? coresEtiqueta[et] : null,
                      ),
                    ),
                  ),
                ),
              ],
            ],
          );
        },
      ),
    );
  }
}

/// Caixa para escrever uma observação, com botão N (negrito) e, se
/// [completo], marca-texto e etiqueta colorida opcional.
/// A observação vai para a planilha do modo ('leitura' ou 'estudo').
/// [ref] devolve a que ela se refere na hora de salvar (livro ou matéria).
class CampoObservacao extends StatefulWidget {
  final String modo; // 'leitura' | 'estudo'
  final String Function() ref;
  final int? livroId;
  final String dica;
  final bool completo;

  const CampoObservacao({
    super.key,
    required this.modo,
    required this.ref,
    this.livroId,
    this.completo = false,
    this.dica = 'Escreva o que você aprendeu ou quer lembrar',
  });

  @override
  State<CampoObservacao> createState() => _CampoObservacaoState();
}

class _CampoObservacaoState extends State<CampoObservacao> {
  final _texto = ControladorRico();
  final _etiqueta = ValueNotifier<int>(0);

  @override
  void dispose() {
    _texto.dispose();
    _etiqueta.dispose();
    super.dispose();
  }

  Future<void> _salvar() async {
    final t = _texto.text;
    if (t.trim().isEmpty) return;
    final r = widget.ref().trim();
    final est = _texto.trechos;
    await Armazenamento.adicionar('observacoes', {
      'data': DateTime.now().toIso8601String(),
      'modo': widget.modo,
      'ref': r.isEmpty ? (widget.modo == 'estudo' ? 'Sem matéria' : 'Sem livro') : r,
      if (widget.livroId != null) 'lid': widget.livroId,
      'texto': t,
      if (est.isNotEmpty) 'est': est,
      if (_etiqueta.value > 0) 'et': _etiqueta.value,
    });
    _texto.clear();
    _etiqueta.value = 0;
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('Observação salva ✅')));
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextField(
          controller: _texto,
          minLines: 3,
          maxLines: 8,
          textCapitalization: TextCapitalization.sentences,
          decoration: InputDecoration(
            labelText: 'Observação (opcional)',
            hintText: widget.dica,
            alignLabelWithHint: true,
          ),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: BarraFormato(
                controlador: _texto,
                etiqueta: _etiqueta,
                completo: widget.completo,
              ),
            ),
            AnimatedBuilder(
              animation: _texto,
              builder: (context, _) => FilledButton.icon(
                style: FilledButton.styleFrom(
                  backgroundColor: context.destaque,
                  minimumSize: const Size(0, 40),
                ),
                onPressed: _texto.text.trim().isEmpty ? null : _salvar,
                icon: const Icon(Icons.check, size: 18),
                label: const Text('Salvar'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          widget.completo
              ? 'Selecione o texto e toque em N (negrito) ou no marcador (cor).'
              : 'Selecione o texto e toque em N para deixar em negrito.',
          style: const TextStyle(fontSize: 11),
        ),
      ],
    );
  }
}

/// Janela para mudar uma observação já salva (texto, negrito, cor, etiqueta).
class _EditarObservacao extends StatefulWidget {
  final Map<String, dynamic> item;
  final bool completo;
  const _EditarObservacao({required this.item, required this.completo});

  @override
  State<_EditarObservacao> createState() => _EditarObservacaoState();
}

class _EditarObservacaoState extends State<_EditarObservacao> {
  late final ControladorRico _texto;
  late final ValueNotifier<int> _etiqueta;

  @override
  void initState() {
    super.initState();
    _texto = ControladorRico(inicial: lerObsRica(widget.item));
    _etiqueta = ValueNotifier<int>((widget.item['et'] as num?)?.toInt() ?? 0);
  }

  @override
  void dispose() {
    _texto.dispose();
    _etiqueta.dispose();
    super.dispose();
  }

  void _salvar() {
    if (_texto.text.trim().isEmpty) return;
    final novo = Map<String, dynamic>.from(widget.item);
    novo['texto'] = _texto.text;
    final est = _texto.trechos;
    if (est.isEmpty) {
      novo.remove('est');
    } else {
      novo['est'] = est;
    }
    if (_etiqueta.value > 0) {
      novo['et'] = _etiqueta.value;
    } else {
      novo.remove('et');
    }
    Navigator.pop(context, novo);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 0, 20, MediaQuery.of(context).viewInsets.bottom + 20),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Editar observação',
                style: Theme.of(context)
                    .textTheme
                    .titleMedium
                    ?.copyWith(fontWeight: FontWeight.w700)),
            const SizedBox(height: 10),
            TextField(
              controller: _texto,
              autofocus: true,
              minLines: 4,
              maxLines: 10,
              textCapitalization: TextCapitalization.sentences,
            ),
            const SizedBox(height: 8),
            BarraFormato(
              controlador: _texto,
              etiqueta: _etiqueta,
              completo: widget.completo,
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancelar'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: FilledButton(onPressed: _salvar, child: const Text('Salvar')),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// A "planilha" de observações de um modo: lista com busca, edição e apagar.
class PlanilhaObservacoes extends StatefulWidget {
  final String modo; // 'leitura' | 'estudo'
  final int? livroId; // só as de um livro
  final String titulo;
  final bool completo; // marca-texto e etiqueta ao editar

  const PlanilhaObservacoes({
    super.key,
    required this.modo,
    this.livroId,
    this.completo = false,
    this.titulo = 'Observações salvas',
  });

  @override
  State<PlanilhaObservacoes> createState() => _PlanilhaObservacoesState();
}

class _PlanilhaObservacoesState extends State<PlanilhaObservacoes> {
  String _busca = '';

  Future<void> _apagar(int indice) async {
    final sim = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Apagar esta observação?'),
        content: const Text('Não dá para desfazer.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Apagar')),
        ],
      ),
    );
    if (sim == true) await Armazenamento.remover('observacoes', indice);
  }

  Future<void> _editar(int indice, Map<String, dynamic> item) async {
    final novo = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => _EditarObservacao(item: item, completo: widget.completo),
    );
    if (novo != null) await Armazenamento.substituir('observacoes', indice, novo);
  }

  @override
  Widget build(BuildContext context) {
    final estilo = Theme.of(context).textTheme;
    return ValueListenableBuilder<int>(
      valueListenable: Armazenamento.mudou,
      builder: (context, _, __) {
        final todas = Armazenamento.lista('observacoes');
        final b = normalizar(_busca);
        final visiveis = <int>[
          for (var i = 0; i < todas.length; i++)
            if (todas[i]['modo'] == widget.modo &&
                (widget.livroId == null || todas[i]['lid'] == widget.livroId) &&
                (b.isEmpty ||
                    normalizar(textoPuroObs(todas[i])).contains(b) ||
                    normalizar((todas[i]['ref'] as String?) ?? '').contains(b)))
              i,
        ];
        final existe = todas.any((e) =>
            e['modo'] == widget.modo &&
            (widget.livroId == null || e['lid'] == widget.livroId));

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.titulo,
                style: estilo.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
            if (existe)
              Padding(
                padding: const EdgeInsets.only(top: 6, bottom: 6),
                child: TextField(
                  onChanged: (v) => setState(() => _busca = v),
                  decoration: const InputDecoration(
                    hintText: 'Buscar nas observações',
                    prefixIcon: Icon(Icons.search),
                    isDense: true,
                  ),
                ),
              ),
            if (visiveis.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: Text(existe
                    ? 'Nada encontrado para "$_busca".'
                    : 'Nenhuma observação ainda. Escreva uma durante a sessão. ✍️'),
              ),
            for (final i in visiveis.take(100)) _cartao(context, i, todas[i]),
          ],
        );
      },
    );
  }

  Widget _cartao(BuildContext context, int i, Map<String, dynamic> e) {
    final estilo = Theme.of(context).textTheme;
    final d = DateTime.parse(e['data'] as String);
    final rica = lerObsRica(e);
    final et = (e['et'] as num?)?.toInt() ?? 0;
    final corEt = (et > 0 && et < coresEtiqueta.length) ? coresEtiqueta[et] : null;

    return Card(
      margin: const EdgeInsets.only(top: 8),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => _editar(i, e),
        child: Container(
          decoration: BoxDecoration(
            border: Border(
              left: BorderSide(color: corEt ?? Colors.transparent, width: 7),
            ),
          ),
          padding: const EdgeInsets.fromLTRB(12, 10, 4, 10),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${formatarData(d)}/${d.year} · ${formatarHora(d)} · ${e['ref'] ?? ''}',
                      style: estilo.bodySmall?.copyWith(color: context.destaque),
                    ),
                    const SizedBox(height: 4),
                    Text.rich(TextSpan(
                      children: spansRicos(
                        rica.texto,
                        rica.codigos,
                        DefaultTextStyle.of(context).style,
                      ),
                    )),
                  ],
                ),
              ),
              IconButton(
                tooltip: 'Editar observação',
                icon: const Icon(Icons.edit_outlined, size: 20),
                onPressed: () => _editar(i, e),
              ),
              IconButton(
                tooltip: 'Apagar observação',
                icon: const Icon(Icons.delete_outline, size: 20),
                onPressed: () => _apagar(i),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
