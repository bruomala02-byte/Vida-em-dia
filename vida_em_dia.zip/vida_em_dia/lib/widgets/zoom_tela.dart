import 'package:flutter/material.dart';

import '../core/config.dart';

/// Aplica a uma tela inteira os tamanhos escolhidos em Configurações:
/// textos, ícones e botões, cada um com a sua regulagem.
class ZoomTela extends StatelessWidget {
  final String tela;
  final Widget child;
  const ZoomTela({super.key, required this.tela, required this.child});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: Config.zoom[tela]!,
      builder: (context, percentual, _) => ValueListenableBuilder<int>(
        valueListenable: Config.icones[tela]!,
        builder: (context, pIcone, _) => ValueListenableBuilder<int>(
          valueListenable: Config.botoes[tela]!,
          builder: (context, pBotao, _) {
            final fator = percentual / 100;
            final fIcone = pIcone / 100;
            final fBotao = pBotao / 100;
            final mq = MediaQuery.of(context);
            final tema = Theme.of(context);

            // Botões: altura mínima, letra e "densidade" (espaço em volta).
            final d = ((fBotao - 1) * 5).clamp(-4.0, 4.0);
            final estiloFilled = (tema.filledButtonTheme.style ?? const ButtonStyle()).copyWith(
              minimumSize: WidgetStatePropertyAll(Size.fromHeight(56 * fBotao)),
              textStyle: WidgetStatePropertyAll(
                TextStyle(fontSize: 18 * fBotao, fontWeight: FontWeight.w700),
              ),
            );

            return Theme(
              data: tema.copyWith(
                visualDensity: VisualDensity(horizontal: d, vertical: d),
                filledButtonTheme: FilledButtonThemeData(style: estiloFilled),
              ),
              child: MediaQuery(
                data: mq.copyWith(
                  textScaler: TextScaler.linear(mq.textScaler.scale(1) * fator),
                ),
                child: IconTheme(
                  data: IconTheme.of(context).copyWith(
                    size: (IconTheme.of(context).size ?? 24) * fator * fIcone,
                  ),
                  child: child,
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
