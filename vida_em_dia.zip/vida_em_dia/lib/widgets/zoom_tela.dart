import 'package:flutter/material.dart';

import '../core/config.dart';

/// Tamanho dos botões de uma tela (1.0 = o padrão do app).
/// Os botões que têm altura própria leem daqui com [altAcao] e [altSec].
class EscalaBotoes extends InheritedWidget {
  final double acao; // botões de ação (iniciar, salvar, cadastrar...)
  final double sec; // botões secundários (baixar extrato, compartilhar...)

  const EscalaBotoes({
    super.key,
    required this.acao,
    required this.sec,
    required super.child,
  });

  static EscalaBotoes? talvez(BuildContext c) =>
      c.dependOnInheritedWidgetOfExactType<EscalaBotoes>();

  @override
  bool updateShouldNotify(EscalaBotoes old) => acao != old.acao || sec != old.sec;
}

extension EscalaBotoesContext on BuildContext {
  /// Altura de um botão de ação: [base] vezes o ajuste da tela.
  double altAcao(double base) => base * (EscalaBotoes.talvez(this)?.acao ?? 1.0);

  /// Altura de um botão secundário.
  double altSec(double base) => base * (EscalaBotoes.talvez(this)?.sec ?? 1.0);
}

/// Aplica a uma tela inteira os tamanhos escolhidos em Configurações:
/// zoom geral, textos, ícones e botões (de ação e secundários).
class ZoomTela extends StatelessWidget {
  final String tela;
  final Widget child;
  const ZoomTela({super.key, required this.tela, required this.child});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([
        Config.geral[tela]!,
        Config.zoom[tela]!,
        Config.icones[tela]!,
        Config.botoes[tela]!,
        Config.botoes2[tela]!,
      ]),
      builder: (context, _) {
        final g = Config.geral[tela]!.value / 100;
        final fTexto = Config.zoom[tela]!.value / 100 * g;
        final fIcone = Config.icones[tela]!.value / 100;
        final fAcao = Config.botoes[tela]!.value / 100 * g;
        final fSec = Config.botoes2[tela]!.value / 100 * g;
        final mq = MediaQuery.of(context);
        final tema = Theme.of(context);

        // Botões de ação: altura mínima e letra.
        final estiloFilled = (tema.filledButtonTheme.style ?? const ButtonStyle()).copyWith(
          minimumSize: WidgetStatePropertyAll(Size.fromHeight(44 * fAcao)),
          textStyle: WidgetStatePropertyAll(
            TextStyle(fontSize: 16 * fAcao, fontWeight: FontWeight.w700),
          ),
        );
        // Botões secundários: o espaço em volta ("densidade").
        final d = ((fSec - 1) * 5).clamp(-4.0, 4.0);

        return EscalaBotoes(
          acao: fAcao,
          sec: fSec,
          child: Theme(
            data: tema.copyWith(
              visualDensity: VisualDensity(horizontal: d, vertical: d),
              filledButtonTheme: FilledButtonThemeData(style: estiloFilled),
            ),
            child: MediaQuery(
              data: mq.copyWith(
                textScaler: TextScaler.linear(mq.textScaler.scale(1) * fTexto),
              ),
              child: IconTheme(
                data: IconTheme.of(context).copyWith(
                  size: (IconTheme.of(context).size ?? 24) * fTexto * fIcone,
                ),
                child: child,
              ),
            ),
          ),
        );
      },
    );
  }
}
