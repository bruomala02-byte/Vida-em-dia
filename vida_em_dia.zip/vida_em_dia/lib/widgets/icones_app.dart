import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../core/tema.dart';

enum TipoIcone { pes, relogio, chama, velocimetro, livro }

/// Ícones próprios do app, desenhados em código (sem precisar de imagem).
class IconeApp extends StatelessWidget {
  final TipoIcone tipo;
  final double tamanho;
  final Color cor;

  const IconeApp(this.tipo, {super.key, this.tamanho = 28, required this.cor});

  @override
  Widget build(BuildContext context) => SizedBox(
        width: tamanho,
        height: tamanho,
        child: CustomPaint(painter: _IconePainter(tipo, cor)),
      );
}

class _IconePainter extends CustomPainter {
  final TipoIcone tipo;
  final Color cor;
  const _IconePainter(this.tipo, this.cor);

  @override
  void paint(Canvas c, Size s) {
    final w = s.width;
    final fill = Paint()
      ..color = cor
      ..isAntiAlias = true;
    final line = Paint()
      ..color = cor
      ..style = PaintingStyle.stroke
      ..strokeWidth = w * 0.09
      ..strokeCap = StrokeCap.round
      ..isAntiAlias = true;

    switch (tipo) {
      case TipoIcone.pes:
        void pe(double dx, double dy, double ang) {
          final fw = w * 0.36, fh = w * 0.62;
          c.save();
          c.translate(dx, dy);
          c.rotate(ang);
          c.drawOval(Rect.fromLTWH(0, 0, fw, fh * 0.64), fill); // frente
          c.drawOval(Rect.fromLTWH(fw * 0.12, fh * 0.72, fw * 0.76, fh * 0.28), fill); // calcanhar
          c.restore();
        }
        pe(w * 0.08, w * 0.34, -0.18);
        pe(w * 0.56, w * 0.04, 0.18);

      case TipoIcone.relogio:
        final cx = w / 2, cy = w * 0.57, r = w * 0.36;
        c.drawCircle(Offset(cx, cy), r, line);
        c.drawLine(Offset(cx, cy), Offset(cx + r * 0.42, cy - r * 0.5), line); // ponteiro
        c.drawLine(Offset(cx, w * 0.07), Offset(cx, cy - r), line); // haste
        c.drawLine(Offset(cx - w * 0.1, w * 0.07), Offset(cx + w * 0.1, w * 0.07), line);
        final a = -math.pi / 4;
        c.drawLine(
          Offset(cx + (r + w * 0.03) * math.cos(a), cy + (r + w * 0.03) * math.sin(a)),
          Offset(cx + (r + w * 0.11) * math.cos(a), cy + (r + w * 0.11) * math.sin(a)),
          line,
        );
        c.drawCircle(Offset(cx, cy), w * 0.045, fill);

      case TipoIcone.chama:
        c.save();
        c.scale(w);
        final fogo = Path()
          ..moveTo(.56, .02)
          ..cubicTo(.62, .28, .92, .40, .88, .68)
          ..cubicTo(.85, .88, .68, 1.0, .5, 1.0)
          ..cubicTo(.3, 1.0, .12, .86, .12, .64)
          ..cubicTo(.12, .46, .26, .36, .30, .20)
          ..cubicTo(.40, .28, .42, .34, .42, .40)
          ..cubicTo(.50, .30, .54, .16, .56, .02)
          ..close();
        c.drawPath(fogo, fill);
        final miolo = Path()
          ..moveTo(.5, .58)
          ..cubicTo(.66, .70, .70, .82, .62, .90)
          ..cubicTo(.57, .95, .43, .95, .38, .90)
          ..cubicTo(.30, .82, .36, .70, .5, .58)
          ..close();
        c.drawPath(miolo, Paint()..color = Colors.white.withValues(alpha: 0.4));
        c.restore();

      case TipoIcone.livro:
        c.save();
        c.scale(w);
        c.drawPath(
          Path()
            ..moveTo(.05, .27)
            ..lineTo(.05, .80)
            ..cubicTo(.20, .76, .40, .80, .50, .93)
            ..cubicTo(.60, .80, .80, .76, .95, .80)
            ..lineTo(.95, .27)
            ..close(),
          fill,
        );
        final pagina = Paint()..color = const Color(0xFFEDEDED);
        c.drawPath(
          Path()
            ..moveTo(.11, .21)
            ..cubicTo(.28, .16, .42, .20, .50, .30)
            ..lineTo(.50, .82)
            ..cubicTo(.42, .72, .28, .70, .11, .73)
            ..close(),
          pagina,
        );
        c.drawPath(
          Path()
            ..moveTo(.89, .21)
            ..cubicTo(.72, .16, .58, .20, .50, .30)
            ..lineTo(.50, .82)
            ..cubicTo(.58, .72, .72, .70, .89, .73)
            ..close(),
          pagina,
        );
        final texto = Paint()
          ..color = const Color(0xFF9A9A9A)
          ..style = PaintingStyle.stroke
          ..strokeWidth = .022
          ..strokeCap = StrokeCap.round;
        for (final y in [.34, .44, .54]) {
          c.drawLine(Offset(.19, y), Offset(.42, y + .04), texto);
          c.drawLine(Offset(.58, y + .04), Offset(.72, y + .02), texto);
        }
        c.drawPath(
          Path()
            ..moveTo(.62, .08)
            ..lineTo(.77, .08)
            ..lineTo(.77, .38)
            ..lineTo(.695, .31)
            ..lineTo(.62, .38)
            ..close(),
          fill,
        );
        c.restore();

      case TipoIcone.velocimetro:
        final vx = w / 2, vy = w * 0.58, vr = w * 0.38;
        c.drawArc(
          Rect.fromCircle(center: Offset(vx, vy), radius: vr),
          math.pi * 0.8,
          math.pi * 1.4,
          false,
          line,
        );
        const ang = math.pi * 1.7;
        c.drawLine(
          Offset(vx, vy),
          Offset(vx + vr * 0.72 * math.cos(ang), vy + vr * 0.72 * math.sin(ang)),
          line,
        );
        c.drawCircle(Offset(vx, vy), w * 0.07, fill);
    }
  }

  @override
  bool shouldRepaint(covariant _IconePainter old) => old.tipo != tipo || old.cor != cor;
}


/// "Capinha" de livro: quadradinho com o livrinho desenhado, na cor do app.
class CapaLivro extends StatelessWidget {
  final double tamanho;
  const CapaLivro({super.key, this.tamanho = 56});

  @override
  Widget build(BuildContext context) {
    final cor = context.destaque;
    return Container(
      width: tamanho,
      height: tamanho * 1.25,
      decoration: BoxDecoration(
        color: cor.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: cor, width: 2),
      ),
      child: Center(child: IconeApp(TipoIcone.livro, tamanho: tamanho * 0.7, cor: cor)),
    );
  }
}
