import 'package:flutter/material.dart';

import '../core/armazenamento.dart';
import '../core/formatos.dart';
import '../core/tema.dart';
import '../modelos/livro.dart';
import '../modelos/sessao_leitura.dart';
import '../widgets/icones_app.dart';
import 'leitura_ativa_tela.dart';

/// Histórico e desempenho de um livro. Daqui você continua de onde parou.
class LivroTela extends StatelessWidget {
  final Livro livro;
  const LivroTela({super.key, required this.livro});

  Future<void> _apagar(BuildContext context) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Apagar livro?'),
        content: const Text('O livro e todo o histórico de leitura dele serão apagados.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancelar')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Apagar')),
        ],
      ),
    );
    if (ok == true) {
      await Armazenamento.removerLivro(livro.id);
      if (context.mounted) Navigator.pop(context);
    }
  }

  Future<void> _apagarSessao(BuildContext context, SessaoLeitura s) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Apagar esta leitura?'),
        content: Text('${formatarData(s.data)}/${s.data.year} · '
            '${formatarHora(s.data)} – ${formatarHora(s.fimEfetivo)} · '
            '${formatarDuracao(s.segundos)}\n\n'
            'Ela sai do histórico e do desempenho do mês. A página atual do livro '
            'volta para a da leitura anterior.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancelar')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Apagar')),
        ],
      ),
    );
    if (ok == true) await Armazenamento.removerLeitura(s);
  }

  @override
  Widget build(BuildContext context) {
    final estilo = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(
        title: Text(livro.titulo),
        actions: [
          PopupMenuButton<int>(
            onSelected: (_) => _apagar(context),
            itemBuilder: (_) => const [PopupMenuItem(value: 0, child: Text('Apagar livro'))],
          ),
        ],
      ),
      body: ValueListenableBuilder<int>(
        valueListenable: Armazenamento.mudou,
        builder: (context, _, __) {
          final agora = DateTime.now();
          final sessoes = Armazenamento.sessoesDoLivro(livro.id); // mais nova primeiro
          final pagina = Armazenamento.paginaAtual(livro.id);
          final total = livro.totalPaginas;
          final pct = total > 0 ? (pagina / total).clamp(0.0, 1.0) : 0.0;

          final doMes = sessoes
              .where((s) => s.data.year == agora.year && s.data.month == agora.month)
              .toList();
          final segMes = doMes.fold<int>(0, (a, s) => a + s.segundos);
          final pagMes = doMes.fold<int>(0, (a, s) => a + s.paginasLidas);
          final diasMes = {for (final s in doMes) s.data.day}.length;
          final segTotal = sessoes.fold<int>(0, (a, s) => a + s.segundos);

          final porDia = <String, int>{};
          for (final s in sessoes) {
            final k = '${formatarData(s.data)}/${s.data.year}';
            porDia[k] = (porDia[k] ?? 0) + s.segundos;
          }

          final itens = <Widget>[];
          String? ultimo;
          for (final s in sessoes) {
            final dia = '${formatarData(s.data)}/${s.data.year}';
            if (dia != ultimo) {
              ultimo = dia;
              itens.add(Padding(
                padding: const EdgeInsets.only(top: 14, bottom: 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(dia, style: const TextStyle(fontWeight: FontWeight.w800)),
                    Text('total do dia: ${formatarDuracao(porDia[dia]!)}'),
                  ],
                ),
              ));
            }
            itens.add(ListTile(
              contentPadding: EdgeInsets.zero,
              leading: CircleAvatar(
                backgroundColor: context.destaque.withValues(alpha: 0.15),
                child: Icon(Icons.menu_book, color: context.destaque),
              ),
              title: Text('${formatarHora(s.data)} – ${formatarHora(s.fimEfetivo)}'
                  '  ·  ${formatarDuracao(s.segundos)}'),
              subtitle: Text('pág. ${s.paginaInicio} → ${s.paginaFim} (+${s.paginasLidas})'
                  '${s.nota.isEmpty ? '' : '\n${s.nota}'}'),
              trailing: IconButton(
                tooltip: 'Apagar leitura',
                icon: const Icon(Icons.delete_outline),
                onPressed: () => _apagarSessao(context, s),
              ),
            ));
          }

          return ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(children: [
                    const CapaLivro(tamanho: 64),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(livro.titulo,
                              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                          if (livro.autor.isNotEmpty) Text(livro.autor),
                          const SizedBox(height: 8),
                          Text(total > 0
                              ? 'Página $pagina de $total · ${(pct * 100).round()}%'
                              : 'Página $pagina'),
                          if (total > 0) ...[
                            const SizedBox(height: 6),
                            LinearProgressIndicator(
                              value: pct,
                              minHeight: 10,
                              borderRadius: BorderRadius.circular(8),
                              color: context.destaque,
                            ),
                          ],
                        ],
                      ),
                    ),
                  ]),
                ),
              ),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => LeituraAtivaTela(livro: livro)),
                ),
                icon: const Icon(Icons.play_arrow),
                label: Text(sessoes.isEmpty
                    ? 'Começar a ler'
                    : 'Continuar de onde parou (pág. $pagina)'),
              ),
              const SizedBox(height: 20),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Desempenho de ${nomesMeses[agora.month - 1]}',
                          style: estilo.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                      const SizedBox(height: 10),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          _Numero(formatarDuracao(segMes), 'lidos'),
                          _Numero('$pagMes', 'páginas'),
                          _Numero('$diasMes', diasMes == 1 ? 'dia' : 'dias'),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text(total > 0
                          ? 'Neste mês você leu ${(pagMes / total * 100).toStringAsFixed(1).replaceAll('.', ',')}% do livro. '
                              'No total: ${formatarDuracao(segTotal)} e $pagina de $total páginas.'
                          : 'No total: ${formatarDuracao(segTotal)} lidos neste livro.'),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text('Histórico',
                  style: estilo.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
              if (sessoes.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 16),
                  child: Text('Nenhuma leitura ainda. Toque em "Começar a ler". 📖'),
                ),
              ...itens,
            ],
          );
        },
      ),
    );
  }
}

class _Numero extends StatelessWidget {
  final String valor, rotulo;
  const _Numero(this.valor, this.rotulo);

  @override
  Widget build(BuildContext context) => Column(children: [
        Text(valor, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
        Text(rotulo),
      ]);
}
