import 'package:flutter/material.dart';

/// Tela provisória para módulos que ainda vão ser construídos.
/// Mostra o que vem por aí, para o app já parecer completo.
class EmBreveTela extends StatelessWidget {
  final String titulo;
  final IconData icone;
  final Color cor;
  final List<String> recursos;

  const EmBreveTela({
    super.key,
    required this.titulo,
    required this.icone,
    required this.cor,
    required this.recursos,
  });

  @override
  Widget build(BuildContext context) {
    final estilo = Theme.of(context).textTheme;

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Text(titulo, style: estilo.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 24),
        Center(
          child: CircleAvatar(
            radius: 48,
            backgroundColor: cor.withValues(alpha: 0.15),
            child: Icon(icone, size: 48, color: cor),
          ),
        ),
        const SizedBox(height: 20),
        Center(
          child: Text(
            'Em breve por aqui',
            style: estilo.titleLarge?.copyWith(fontWeight: FontWeight.w700),
          ),
        ),
        const SizedBox(height: 24),
        for (final r in recursos)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Card(
              child: ListTile(
                leading: Icon(Icons.check_circle_outline, color: cor),
                title: Text(r),
              ),
            ),
          ),
      ],
    );
  }
}
