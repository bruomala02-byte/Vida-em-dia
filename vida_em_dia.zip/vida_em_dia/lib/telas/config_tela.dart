import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/config.dart';
import '../servicos/coracao_servico.dart';
import '../widgets/escolher_cor.dart';
import '../widgets/zoom_tela.dart';
import 'historico_tela.dart';

/// Configurações: aparência (modo escuro, cor) e zoom de cada tela.
class ConfigTela extends StatelessWidget {
  const ConfigTela({super.key});

  void _mostrarValores(BuildContext context) {
    final texto = Config.resumoValores();
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Meus tamanhos'),
        content: SelectableText(texto),
        actions: [
          TextButton(
            onPressed: () async {
              await Clipboard.setData(ClipboardData(text: texto));
              if (ctx.mounted) Navigator.pop(ctx);
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Copiado! É só colar na conversa comigo.')),
                );
              }
            },
            child: const Text('Copiar'),
          ),
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Fechar')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final estilo = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(title: const Text('Configurações')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text('Aparência',
                style: estilo.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            ValueListenableBuilder<ThemeMode>(
              valueListenable: Config.modoTema,
              builder: (context, modo, _) => SizedBox(
                width: double.infinity,
                child: SegmentedButton<ThemeMode>(
                  segments: const [
                    ButtonSegment(value: ThemeMode.system, label: Text('Sistema')),
                    ButtonSegment(value: ThemeMode.light, label: Text('Claro')),
                    ButtonSegment(value: ThemeMode.dark, label: Text('Escuro')),
                  ],
                  selected: {modo},
                  onSelectionChanged: (s) => Config.definirModo(s.first),
                ),
              ),
            ),
            const SizedBox(height: 4),
            Text('O modo escuro é preto, com textos brancos e ícones na cor escolhida.',
                style: estilo.bodySmall),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.palette_outlined),
              title: const Text('Cor do app'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => showModalBottomSheet(
                context: context,
                isScrollControlled: true,
                showDragHandle: true,
                builder: (_) => const EscolherCor(),
              ),
            ),
            const _CoracaoConfig(),
            const Divider(),
            const SizedBox(height: 8),
            Text('Tamanho de cada tela',
                style: estilo.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
            Text('Ajuste textos, ícones e botões de cada tela e veja a prévia logo abaixo. '
                'Quando achar o ideal, toque em "Mostrar meus valores" e me mande.',
                style: estilo.bodySmall),
            for (final t in Config.telas) _AjusteTela(tela: t),
            const SizedBox(height: 8),
            ValueListenableBuilder<int>(
              valueListenable: Config.barra,
              builder: (context, p, _) => Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Barra de baixo: $p%',
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  Slider(
                    value: p.toDouble(),
                    min: Config.zoomMin.toDouble(),
                    max: Config.zoomMax.toDouble(),
                    divisions: Config.zoomMax - Config.zoomMin,
                    label: '$p%',
                    onChanged: (v) => Config.definirBarra(v.round()),
                  ),
                ],
              ),
            ),
            Wrap(
              spacing: 8,
              children: [
                OutlinedButton.icon(
                  onPressed: () => _mostrarValores(context),
                  icon: const Icon(Icons.fact_check_outlined),
                  label: const Text('Mostrar meus valores'),
                ),
                TextButton.icon(
                  onPressed: Config.restaurarZoom,
                  icon: const Icon(Icons.restart_alt),
                  label: const Text('Restaurar padrão'),
                ),
              ],
            ),
            const Divider(),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.history),
              title: const Text('Histórico e check-in'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context)
                  .push(MaterialPageRoute(builder: (_) => const HistoricoTela())),
            ),
          ],
        ),
      ),
    );
  }
}

/// Os três ajustes de uma tela (textos, ícones, botões) com uma prévia.
class _AjusteTela extends StatelessWidget {
  final String tela;
  const _AjusteTela({required this.tela});

  Widget _linha(String nome, ValueNotifier<int> n, Future<void> Function(String, int) definir) {
    return ValueListenableBuilder<int>(
      valueListenable: n,
      builder: (context, p, _) => Row(children: [
        SizedBox(width: 76, child: Text('$nome $p%')),
        Expanded(
          child: Slider(
            value: p.toDouble(),
            min: Config.zoomMin.toDouble(),
            max: Config.zoomMax.toDouble(),
            divisions: Config.zoomMax - Config.zoomMin,
            label: '$p%',
            onChanged: (v) => definir(tela, v.round()),
          ),
        ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 10, 8, 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(Config.rotulos[tela]!,
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
              _linha('Textos', Config.zoom[tela]!, Config.definirZoom),
              _linha('Ícones', Config.icones[tela]!, Config.definirIcone),
              _linha('Botões', Config.botoes[tela]!, Config.definirBotao),
              ZoomTela(
                tela: tela,
                child: Padding(
                  padding: const EdgeInsets.only(right: 6, top: 4),
                  child: Row(children: [
                    const Icon(Icons.directions_run),
                    const Icon(Icons.favorite),
                    const SizedBox(width: 8),
                    const Text('Texto'),
                    const SizedBox(width: 12),
                    SizedBox(
                      width: 140,
                      child: FilledButton(onPressed: () {}, child: const Text('Botão')),
                    ),
                  ]),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Liga ou desliga o coração do ícone e mostra como ele está.
class _CoracaoConfig extends StatefulWidget {
  const _CoracaoConfig();

  @override
  State<_CoracaoConfig> createState() => _CoracaoConfigState();
}

class _CoracaoConfigState extends State<_CoracaoConfig> {
  @override
  Widget build(BuildContext context) {
    final e = CoracaoServico.estado();
    final ligado = CoracaoServico.ligado;
    return SwitchListTile(
      contentPadding: EdgeInsets.zero,
      secondary: const Icon(Icons.favorite),
      title: const Text('Coração no ícone do app'),
      subtitle: Text(
        e.quebrado
            ? 'Seu coração quebrou. Registre algo hoje para consertar.'
            : 'Seu coração está em ${e.percentual}%. Cada dia com registro devolve 10%, '
                'cada dia sem nenhum tira 10%. O ícone troca quando você sai do app.',
      ),
      value: ligado,
      onChanged: (v) async {
        await CoracaoServico.definirLigado(v);
        if (mounted) setState(() {});
      },
    );
  }
}
