import 'package:flutter/material.dart';

import '../core/armazenamento.dart';
import '../core/formatos.dart';
import '../core/tema.dart';
import 'estudo_tela.dart';
import 'leitura_tela.dart';

/// "Estudos - Leitura": no topo o total do dia (leitura + estudo juntos, com
/// os dois separados logo abaixo) e a escolha entre Leitura e Estudo.
/// IndexedStack mantém os cronômetros rodando ao trocar de modo.
class EstudosLeituraTela extends StatefulWidget {
  const EstudosLeituraTela({super.key});

  @override
  State<EstudosLeituraTela> createState() => _EstudosLeituraTelaState();
}

class _EstudosLeituraTelaState extends State<EstudosLeituraTela> {
  int _modo = 0; // 0 = leitura, 1 = estudo

  @override
  Widget build(BuildContext context) {
    final estilo = Theme.of(context).textTheme;

    return Column(
      children: [
        ValueListenableBuilder<int>(
          valueListenable: Armazenamento.mudou,
          builder: (context, _, __) {
            final hoje = DateTime.now();
            final segLeitura = Armazenamento.segLeituraDia(hoje);
            final segEstudo = Armazenamento.segEstudoDia(hoje);
            final total = (segLeitura + segEstudo) ~/ 60;
            final meta = Armazenamento.metaLeitura();
            final seguidos = Armazenamento.diasSeguidos();

            return Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
              child: Card(
                margin: EdgeInsets.zero,
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Total de hoje',
                              style: estilo.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                          Text('$total de $meta min',
                              style: const TextStyle(fontWeight: FontWeight.w800)),
                        ],
                      ),
                      const SizedBox(height: 6),
                      LinearProgressIndicator(
                        value: (total / meta).clamp(0.0, 1.0),
                        minHeight: 10,
                        borderRadius: BorderRadius.circular(8),
                        color: context.destaque,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        total >= meta
                            ? 'Meta batida, parabéns! 🎉 · '
                                'Leitura ${formatarDuracao(segLeitura)} · Estudo ${formatarDuracao(segEstudo)}'
                            : 'Leitura ${formatarDuracao(segLeitura)} · Estudo ${formatarDuracao(segEstudo)}',
                        style: estilo.bodySmall,
                      ),
                      if (seguidos > 0)
                        Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text(
                            '🔥 $seguidos ${seguidos == 1 ? 'dia seguido' : 'dias seguidos'} estudando ou lendo',
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
          child: SizedBox(
            width: double.infinity,
            child: SegmentedButton<int>(
              showSelectedIcon: false,
              segments: const [
                ButtonSegment(value: 0, label: Text('Leitura'), icon: Icon(Icons.menu_book)),
                ButtonSegment(value: 1, label: Text('Estudo'), icon: Icon(Icons.school_outlined)),
              ],
              selected: {_modo},
              onSelectionChanged: (s) => setState(() => _modo = s.first),
            ),
          ),
        ),
        Expanded(
          child: IndexedStack(
            index: _modo,
            children: const [LeituraTela(), EstudoTela()],
          ),
        ),
      ],
    );
  }
}
