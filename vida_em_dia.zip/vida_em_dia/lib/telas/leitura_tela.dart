import 'package:flutter/material.dart';

import '../core/armazenamento.dart';
import '../core/formatos.dart';
import '../core/tema.dart';
import '../modelos/livro.dart';
import '../widgets/icones_app.dart';
import 'livro_tela.dart';

/// Parte "Mente" da aba Saúde: seus livros e o desempenho do mês.
class LeituraTela extends StatelessWidget {
  const LeituraTela({super.key});

  static const metaDiariaMinutos = 30;

  void _cadastrar(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => const _CadastrarLivro(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final estilo = Theme.of(context).textTheme;

    return ValueListenableBuilder<int>(
      valueListenable: Armazenamento.mudou,
      builder: (context, _, __) {
        final agora = DateTime.now();
        final doMes = Armazenamento.leituras()
            .where((s) => s.data.year == agora.year && s.data.month == agora.month)
            .toList();
        final segundos = doMes.fold<int>(0, (a, s) => a + s.segundos);
        final paginas = doMes.fold<int>(0, (a, s) => a + s.paginasLidas);
        final porDia = <int, int>{};
        for (final s in doMes) {
          porDia[s.data.day] = (porDia[s.data.day] ?? 0) + s.segundos;
        }
        final diasMeta = porDia.values.where((v) => v >= metaDiariaMinutos * 60).length;
        final minHoje = (porDia[agora.day] ?? 0) ~/ 60;
        final livros = Armazenamento.livros();

        return ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Text('Meta de hoje',
                style: estilo.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            LinearProgressIndicator(
              value: (minHoje / metaDiariaMinutos).clamp(0.0, 1.0),
              minHeight: 12,
              borderRadius: BorderRadius.circular(8),
              color: context.destaque,
            ),
            const SizedBox(height: 6),
            Text(minHoje >= metaDiariaMinutos
                ? 'Meta batida! $minHoje min lidos 🎉'
                : '$minHoje de $metaDiariaMinutos min'),
            const SizedBox(height: 20),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Desempenho de ${nomesMeses[agora.month - 1]}',
                        style: estilo.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _Numero(formatarDuracao(segundos), 'lidos'),
                        _Numero('$paginas', 'páginas'),
                        _Numero('${porDia.length}/${agora.day}', 'dias lendo'),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Text('Meta de $metaDiariaMinutos min batida em $diasMeta '
                        '${diasMeta == 1 ? 'dia' : 'dias'} · '
                        'sem ler em ${agora.day - porDia.length} '
                        '${agora.day - porDia.length == 1 ? 'dia' : 'dias'}.'),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: () => _cadastrar(context),
              icon: const Icon(Icons.add),
              label: const Text('Cadastrar livro'),
            ),
            const SizedBox(height: 24),
            Text('Meus livros',
                style: estilo.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            if (livros.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 16),
                child: Text('Nenhum livro ainda. Cadastre o primeiro e comece a ler! 📖'),
              ),
            for (final l in livros) _CartaoLivro(livro: l),
          ],
        );
      },
    );
  }
}

class _Numero extends StatelessWidget {
  final String valor, rotulo;
  const _Numero(this.valor, this.rotulo);

  @override
  Widget build(BuildContext context) => Column(children: [
        Text(valor, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
        Text(rotulo),
      ]);
}

class _CartaoLivro extends StatelessWidget {
  final Livro livro;
  const _CartaoLivro({required this.livro});

  @override
  Widget build(BuildContext context) {
    final pagina = Armazenamento.paginaAtual(livro.id);
    final total = livro.totalPaginas;
    final pct = total > 0 ? (pagina / total).clamp(0.0, 1.0) : 0.0;

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Card(
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => LivroTela(livro: livro)),
          ),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              const CapaLivro(tamanho: 52),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(livro.titulo,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
                    if (livro.autor.isNotEmpty) Text(livro.autor),
                    const SizedBox(height: 4),
                    Text(total > 0
                        ? 'Página $pagina de $total · ${(pct * 100).round()}%'
                        : 'Página $pagina'),
                    if (total > 0) ...[
                      const SizedBox(height: 6),
                      LinearProgressIndicator(
                        value: pct,
                        minHeight: 8,
                        borderRadius: BorderRadius.circular(8),
                        color: context.destaque,
                      ),
                    ],
                  ],
                ),
              ),
              const Icon(Icons.chevron_right),
            ]),
          ),
        ),
      ),
    );
  }
}

class _CadastrarLivro extends StatefulWidget {
  const _CadastrarLivro();

  @override
  State<_CadastrarLivro> createState() => _CadastrarLivroState();
}

class _CadastrarLivroState extends State<_CadastrarLivro> {
  final _titulo = TextEditingController();
  final _autor = TextEditingController();
  final _paginas = TextEditingController();

  @override
  void dispose() {
    _titulo.dispose();
    _autor.dispose();
    _paginas.dispose();
    super.dispose();
  }

  Future<void> _salvar() async {
    if (_titulo.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Escreva o nome do livro primeiro 📖')),
      );
      return;
    }
    await Armazenamento.salvarLivro(Livro(
      id: DateTime.now().millisecondsSinceEpoch,
      titulo: _titulo.text.trim(),
      autor: _autor.text.trim(),
      totalPaginas: int.tryParse(_paginas.text.trim()) ?? 0,
      criado: DateTime.now(),
    ));
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 0, 20, MediaQuery.of(context).viewInsets.bottom + 20),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _titulo,
              autofocus: true,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(
                labelText: 'Nome do livro',
                prefixIcon: Icon(Icons.menu_book),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _autor,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(labelText: 'Autor (opcional)'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _paginas,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Total de páginas (opcional)',
                helperText: 'Com o total, o app mostra a porcentagem lida.',
              ),
            ),
            const SizedBox(height: 16),
            FilledButton(onPressed: _salvar, child: const Text('Salvar livro')),
          ],
        ),
      ),
    );
  }
}
