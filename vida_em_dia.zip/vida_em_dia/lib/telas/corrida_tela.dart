import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';

import '../core/armazenamento.dart';
import '../core/formatos.dart';
import '../core/tema.dart';
import '../modelos/marca.dart';
import '../modelos/treino.dart';
import '../servicos/gps_servico.dart';
import '../servicos/notificacao_servico.dart';
import '../widgets/icones_app.dart';
import '../widgets/mapa_percurso.dart';
import 'resumo_corrida_tela.dart';

enum _Estado { parado, buscando, correndo, pausado }

/// Uma queda de sinal do GPS durante a corrida.
class _Queda {
  final int iniSeg; // segundo da corrida em que o sinal caiu
  final LatLng? ref; // última posição conhecida
  final int grupo;
  double manual = 0; // metros somados à mão nesta queda
  _Queda(this.iniSeg, this.ref, this.grupo);
}

class CorridaTela extends StatefulWidget {
  const CorridaTela({super.key});

  @override
  State<CorridaTela> createState() => _CorridaTelaState();
}

class _CorridaTelaState extends State<CorridaTela> {
  final _gps = GpsServico();
  _Estado _estado = _Estado.parado;
  double _metros = 0;
  // Stopwatch conta o tempo real, mesmo se o celular travar ou apagar a tela.
  final _cron = Stopwatch();
  int _base = 0; // segundos já contados antes (corrida recuperada)
  int _descontado = 0; // segundos parados descontados pela pausa automática
  int get _segundos => math.max(0, _base + _cron.elapsed.inSeconds - _descontado);

  Position? _ultima;
  DateTime _ultimaHora = DateTime.now(); // quando a última posição aceita chegou
  final List<Ponto> _pontos = [];
  final List<Marca> _marcas = [];
  _Queda? _queda;
  int _grupos = 0;
  bool _seguirMapa = true;
  bool _marcarRetorno = false;
  bool _alerta = false;

  double _velMax = 0;
  int _ignorados = 0; // leituras acima do limite de velocidade
  DateTime _ultimaRecepcao = DateTime.now();
  double _ultimaVel = 0; // m/s
  double _precisao = -1;
  bool _autoPausa = Armazenamento.lerBool('auto_pausa') ?? true;
  bool _autoPausado = false;
  final List<(int, double)> _amostras = []; // (segundo, metros) para o ritmo atual
  int _kmFeito = 0;
  int _ticks = 0;
  ModoPercurso _modo = ModoPercurso.de(Armazenamento.lerTexto('modo_percurso') ?? 'corrida');
  Timer? _timer;
  String? _erro;

  // Distância mostrada: inclui o que ainda falta o GPS confirmar.
  double get _km => _metros / 1000;
  double get _naoConfirmados =>
      _marcas.where((m) => !m.verificada).fold<double>(0, (s, m) => s + m.metros);
  // Distância que vale de verdade ao salvar (sem trechos marcados e não confirmados).
  double get _kmFinal => math.max(0.0, _metros - _naoConfirmados) / 1000;

  // Estimativa: calorias por kg por km (muda entre corrida e ciclismo).
  int _caloriasDe(double km) => (_modo.kcalKgKm * Armazenamento.pesoAtual() * km).round();
  int get _calorias => _caloriasDe(_km);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _verificarRascunho());
  }

  void _aviso(String texto) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(texto)));
  }

  void _zerar() {
    _metros = 0;
    _ultima = null;
    _pontos.clear();
    _marcas.clear();
    _queda = null;
    _grupos = 0;
    _velMax = 0;
    _ignorados = 0;
    _base = 0;
    _descontado = 0;
    _autoPausado = false;
    _amostras.clear();
    _kmFeito = 0;
    _alerta = false;
    _seguirMapa = true;
    _marcarRetorno = false;
    _ticks = 0;
    _cron.reset();
  }

  // ------------------------------------------------------------------
  // Começar: primeiro espera o GPS ficar preciso
  // ------------------------------------------------------------------
  Future<void> _iniciar() async {
    final erro = await _gps.pedirPermissao();
    if (erro != null) {
      setState(() => _erro = erro);
      return;
    }
    setState(() {
      _erro = null;
      _zerar();
      _estado = _Estado.buscando;
      _precisao = -1;
    });
    _gps.iniciar(_aoReceber);
    _gps.ouvirStatus(_aoMudarStatusGps);
  }

  void _comecar() {
    _ultimaRecepcao = DateTime.now();
    _ultimaVel = 0;
    _cron
      ..reset()
      ..start();
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
    setState(() => _estado = _Estado.correndo);
  }

  void _cancelarBusca() {
    _gps.parar();
    setState(() => _estado = _Estado.parado);
  }

  // ------------------------------------------------------------------
  // A cada segundo: queda de sinal, pausa automática e rascunho
  // ------------------------------------------------------------------
  void _tick() {
    if (!mounted || _estado != _Estado.correndo) return;
    _ticks++;
    final sem = DateTime.now().difference(_ultimaRecepcao).inSeconds;
    if (_queda == null && sem >= 15) {
      if (_ultimaVel >= 1.2) {
        _iniciarQueda(); // estava em movimento e o GPS parou de responder
      } else if (_autoPausa && !_autoPausado) {
        _pausarAuto(sem); // estava parado
      }
    }
    if (_ticks % 15 == 0) _salvarRascunho();
    setState(() {});
  }

  void _aoMudarStatusGps(bool ligado) {
    if (!ligado && _estado == _Estado.correndo && _queda == null) _iniciarQueda();
  }

  // ------------------------------------------------------------------
  // Posição nova do GPS
  // ------------------------------------------------------------------
  void _aoReceber(Position p) {
    _precisao = p.accuracy;

    if (_estado == _Estado.buscando) {
      if (p.accuracy <= 20) {
        _comecar();
      } else {
        setState(() {});
      }
      return;
    }
    if (_estado == _Estado.pausado && _autoPausado) {
      if (p.accuracy <= 30 && p.speed > 1.2) {
        _retomar(); // voltou a andar
      } else {
        return;
      }
    }
    if (_estado != _Estado.correndo) return;
    // Ignora leituras ruins do GPS (muito imprecisas).
    if (p.accuracy > 30) return;

    _ultimaRecepcao = DateTime.now();
    _ultimaVel = p.speed;

    final limite = _modo.limiteKmh;
    // 1) velocidade informada pelo GPS acima do limite do modo
    if (p.speed * 3.6 > limite) {
      _ignorados++;
      setState(() {});
      return;
    }

    // O sinal voltou depois de uma queda
    if (_queda != null) _fecharQueda(p);

    if (_ultima != null) {
      final trecho = Geolocator.distanceBetween(
        _ultima!.latitude,
        _ultima!.longitude,
        p.latitude,
        p.longitude,
      );
      // 2) velocidade média do trecho entre as duas últimas posições
      final dt = DateTime.now().difference(_ultimaHora).inMilliseconds / 1000;
      if (dt > 0 && (trecho / dt) * 3.6 > limite) {
        _ignorados++;
        setState(() {});
        return;
      }
      // 3) tremor do GPS com a pessoa parada: não soma
      if (p.speed < 0.5 && trecho < math.max(3.0, p.accuracy * 0.5)) {
        _verificarMarcas(p);
        return;
      }
      _metros += trecho;
    }
    _ultima = p;
    _ultimaHora = DateTime.now();
    _pontos.add(Ponto(p.latitude, p.longitude, p.altitude, _segundos));
    final v = p.speed * 3.6;
    if (v > _velMax) _velMax = v;

    _amostras.add((_segundos, _metros));
    while (_amostras.isNotEmpty && _segundos - _amostras.first.$1 > 120) {
      _amostras.removeAt(0);
    }
    _verificarMarcas(p);
    _parcialKm();
    setState(() {});
  }

  void _parcialKm() {
    final k = _km.floor();
    if (k > _kmFeito) {
      _kmFeito = k;
      HapticFeedback.heavyImpact();
      _aviso('$k km concluídos · ${formatarTempo(_segundos)} 🎉');
    }
  }

  // ------------------------------------------------------------------
  // Queda de sinal, marcação à mão e alerta de percurso
  // ------------------------------------------------------------------
  void _iniciarQueda() {
    final ref = _ultima == null ? null : LatLng(_ultima!.latitude, _ultima!.longitude);
    _queda = _Queda(_segundos, ref, _grupos++);
    _seguirMapa = false;
    _marcarRetorno = false;
    NotificacaoServico.avisoCorrida(
      'Sinal do GPS perdido 📡',
      'Continue o percurso por um caminho seguro. O tempo continua contando; '
          'marque no mapa por onde você passou. Não volte ao percurso até o sinal voltar.',
    );
    HapticFeedback.heavyImpact();
    setState(() {});
  }

  void _fecharQueda(Position p) {
    final q = _queda!;
    _queda = null;
    final marcas = _marcas.where((m) => m.grupo == q.grupo).toList();
    final rota = marcas.where((m) => !m.retorno).toList();
    final retorno = marcas.where((m) => m.retorno).toList();
    final fim = retorno.isNotEmpty ? retorno.last : (rota.isNotEmpty ? rota.last : null);

    // Chegou onde disse que chegaria (ou não marcou nada)?
    final chegou = fim == null ||
        Geolocator.distanceBetween(p.latitude, p.longitude, fim.lat, fim.lng) <= 60;

    if (chegou) {
      for (final m in marcas) {
        m.verificada = true;
      }
      LatLng? de = rota.isNotEmpty ? LatLng(rota.last.lat, rota.last.lng) : q.ref;
      if (de != null) {
        final fecho = Geolocator.distanceBetween(
            de.latitude, de.longitude, p.latitude, p.longitude);
        _metros += fecho;
        q.manual += fecho;
      }
      // O trecho sem sinal não pode passar do limite de velocidade do modo.
      final seg = math.max(1, _segundos - q.iniSeg);
      final maximo = _modo.limiteKmh / 3.6 * seg;
      if (q.manual > maximo) {
        _metros -= (q.manual - maximo);
        _aviso('Trecho sem sinal ajustado ao limite de ${_modo.limiteKmh.round()} km/h.');
      }
      _alerta = false;
      NotificacaoServico.alertaDesvio(false);
      NotificacaoServico.avisoCorrida(
        'Sinal do GPS de volta ✅',
        'O trecho sem sinal foi somado. Se quiser, já pode voltar ao percurso normal.',
      );
    } else {
      // Marcou pontos à frente e o GPS voltou longe deles: alerta vibrando.
      _alerta = true;
      NotificacaoServico.alertaDesvio(true);
      NotificacaoServico.avisoCorrida(
        'Sinal de volta, mas fora do percurso ⚠️',
        'Você não chegou aos pontos marcados. Siga o percurso marcado, ou '
            'desative o alerta no app.',
      );
    }
    _ultima = null; // a distância do trecho já foi somada acima
    _seguirMapa = true;
  }

  /// Confirma os pontos marcados que o GPS viu a pessoa passar (até 40 m).
  /// A direção não importa: dar a volta ao contrário no mesmo percurso vale.
  void _verificarMarcas(Position p) {
    var mudou = false;
    for (final m in _marcas) {
      if (!m.verificada &&
          Geolocator.distanceBetween(p.latitude, p.longitude, m.lat, m.lng) <= 40) {
        m.verificada = true;
        mudou = true;
      }
    }
    if (mudou && _alerta) {
      _alerta = false;
      NotificacaoServico.alertaDesvio(false);
      _aviso('Você voltou ao percurso marcado ✅');
    }
  }

  void _desativarAlerta() {
    NotificacaoServico.alertaDesvio(false);
    setState(() => _alerta = false);
    _aviso('Alerta desativado. Pontos não confirmados não entram na distância.');
  }

  void _marcarNoMapa(LatLng ll) {
    final q = _queda;
    if (q == null) return;
    if (_marcarRetorno) {
      _marcas.removeWhere((m) => m.grupo == q.grupo && m.retorno);
      _marcas.add(Marca(ll.latitude, ll.longitude, retorno: true, grupo: q.grupo));
    } else {
      final rota = _marcas.where((m) => m.grupo == q.grupo && !m.retorno).toList();
      final LatLng? de = rota.isNotEmpty ? LatLng(rota.last.lat, rota.last.lng) : q.ref;
      final seg = de == null
          ? 0.0
          : Geolocator.distanceBetween(de.latitude, de.longitude, ll.latitude, ll.longitude);
      _metros += seg;
      q.manual += seg;
      _marcas.add(Marca(ll.latitude, ll.longitude, metros: seg, grupo: q.grupo));
    }
    HapticFeedback.selectionClick();
    setState(() {});
  }

  void _desfazerMarca() {
    final q = _queda;
    if (q == null) return;
    final i = _marcas.lastIndexWhere((m) => m.grupo == q.grupo);
    if (i < 0) return;
    final m = _marcas.removeAt(i);
    _metros -= m.metros;
    q.manual -= m.metros;
    setState(() {});
  }

  // ------------------------------------------------------------------
  // Pausar, retomar
  // ------------------------------------------------------------------
  void _pausar() {
    _cron.stop();
    _autoPausado = false;
    setState(() => _estado = _Estado.pausado);
    _salvarRascunho();
  }

  void _pausarAuto(int semMovimento) {
    _cron.stop();
    _descontado += semMovimento; // não conta o tempo em que ficou parado
    _autoPausado = true;
    HapticFeedback.lightImpact();
    setState(() => _estado = _Estado.pausado);
  }

  void _retomar() {
    // Zera a última posição para não "pular" a distância percorrida na pausa.
    _ultima = null;
    _ultimaRecepcao = DateTime.now();
    _autoPausado = false;
    _cron.start();
    setState(() => _estado = _Estado.correndo);
  }

  // ------------------------------------------------------------------
  // Rascunho: se o app fechar, dá para continuar de onde parou
  // ------------------------------------------------------------------
  void _salvarRascunho() {
    if (_estado == _Estado.parado || _estado == _Estado.buscando) return;
    final passo = (_pontos.length / 400).ceil().clamp(1, 1000);
    final pts = [for (var i = 0; i < _pontos.length; i += passo) _pontos[i]];
    if (_pontos.isNotEmpty && (_pontos.length - 1) % passo != 0) pts.add(_pontos.last);
    Armazenamento.salvarTextoSilencioso(
      'corrida_rascunho',
      jsonEncode({
        'modo': _modo.id,
        'm': _metros,
        's': _segundos,
        'vmax': _velMax,
        'p': pts.map((p) => p.toJson()).toList(),
        'marcas': _marcas.map((m) => m.toJson()).toList(),
        'grupos': _grupos,
        'quando': DateTime.now().toIso8601String(),
      }),
    );
  }

  void _carregarRascunho(Map<String, dynamic> d) {
    _zerar();
    _modo = ModoPercurso.de(d['modo'] as String? ?? 'corrida');
    _metros = (d['m'] as num).toDouble();
    _base = (d['s'] as num).toInt();
    _velMax = (d['vmax'] as num?)?.toDouble() ?? 0;
    _pontos.addAll(((d['p'] as List?) ?? []).map((e) => Ponto.fromJson(e as List)));
    _marcas.addAll(((d['marcas'] as List?) ?? []).map((e) => Marca.fromJson(e as List)));
    _grupos = (d['grupos'] as num?)?.toInt() ?? 0;
    if (_pontos.isNotEmpty) {
      final u = _pontos.last;
      _ultima = null;
      _queda = null;
      _refRascunho = LatLng(u.lat, u.lng);
    }
  }

  LatLng? _refRascunho;

  Future<void> _verificarRascunho() async {
    final texto = Armazenamento.lerTexto('corrida_rascunho');
    if (texto == null || _estado != _Estado.parado) return;
    Map<String, dynamic> d;
    try {
      d = jsonDecode(texto) as Map<String, dynamic>;
    } catch (_) {
      await Armazenamento.removerChave('corrida_rascunho');
      return;
    }
    final quando = DateTime.parse(d['quando'] as String);
    final metros = (d['m'] as num).toDouble();
    final seg = (d['s'] as num).toInt();
    if (!mounted) return;

    final escolha = await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text('Corrida interrompida'),
        content: Text(
          'O app parou às ${formatarHora(quando)} com ${decimal(metros / 1000)} km '
          'e ${formatarTempo(seg)}.\n\nQuer continuar de onde parou? O tempo e a '
          'distância até o GPS voltar serão somados.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, 'descartar'), child: const Text('Descartar')),
          TextButton(onPressed: () => Navigator.pop(ctx, 'salvar'), child: const Text('Salvar assim')),
          TextButton(onPressed: () => Navigator.pop(ctx, 'continuar'), child: const Text('Continuar')),
        ],
      ),
    );
    if (!mounted || escolha == null) return;

    if (escolha == 'descartar') {
      await Armazenamento.removerChave('corrida_rascunho');
      return;
    }
    _carregarRascunho(d);
    if (escolha == 'salvar') {
      setState(() => _estado = _Estado.pausado);
      await _finalizar();
      return;
    }

    // Continuar: o tempo que passou entra na conta e o trecho sem sinal
    // é somado quando o GPS voltar (respeitando o limite de velocidade).
    final gap = DateTime.now().difference(quando).inSeconds;
    final antes = _base;
    _base += math.max(0, gap);
    final erro = await _gps.pedirPermissao();
    if (erro != null) {
      setState(() => _erro = erro);
    }
    _queda = _Queda(antes, _refRascunho, _grupos++);
    _seguirMapa = false;
    _gps.iniciar(_aoReceber);
    _gps.ouvirStatus(_aoMudarStatusGps);
    _comecar();
    _aviso('Corrida recuperada. Quando o GPS voltar, o trecho é somado.');
  }

  // ------------------------------------------------------------------
  // Finalizar
  // ------------------------------------------------------------------
  Future<void> _finalizar() async {
    _timer?.cancel();
    _gps.parar();
    _cron.stop();
    NotificacaoServico.limparAvisosCorrida();

    final km = _kmFinal;
    final segundos = _segundos;
    final calorias = _caloriasDe(km);
    final velMax = _velMax;
    final pontos = List<Ponto>.from(_pontos);
    final marcas = List<Marca>.from(_marcas);
    final modo = _modo.id;

    await Armazenamento.removerChave('corrida_rascunho');
    setState(() {
      _zerar();
      _estado = _Estado.parado;
    });

    if (km < 0.01) {
      _aviso('Percurso muito curto, não foi salvo.');
      return;
    }

    // Altitude subida (ignora oscilações menores que 0,5 m do GPS).
    var subida = 0.0;
    for (var i = 1; i < pontos.length; i++) {
      final d = pontos[i].alt - pontos[i - 1].alt;
      if (d > 0.5) subida += d;
    }
    // Guarda no máximo ~300 pontos para não pesar no celular.
    final passo = (pontos.length / 300).ceil().clamp(1, 1000);
    final reduzidos = [
      for (var i = 0; i < pontos.length; i += passo) pontos[i],
      if (pontos.isNotEmpty && (pontos.length - 1) % passo != 0) pontos.last,
    ];

    final treino = Treino(
      data: DateTime.now(),
      km: km,
      segundos: segundos,
      calorias: calorias,
      elevacao: subida,
      velMaxKmh: velMax,
      pontos: reduzidos,
      modo: modo,
      marcas: marcas,
    );
    await Armazenamento.salvarTreino(treino);
    if (!mounted) return;
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => ResumoCorridaTela(treino: treino)),
    );
  }

  Future<void> _apagarTreino(Treino t) async {
    final apagar = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Apagar este treino?'),
        content: Text(
            '${decimal(t.km)} km em ${formatarData(t.data)}. Não dá para desfazer.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Apagar')),
        ],
      ),
    );
    if (apagar == true) await Armazenamento.removerTreino(t);
  }

  @override
  void dispose() {
    _timer?.cancel();
    _gps.parar();
    NotificacaoServico.limparAvisosCorrida();
    super.dispose();
  }

  /// Ritmo (ou velocidade) dos últimos ~20 a 120 segundos.
  String get _atual {
    if (_amostras.length < 2) return '--';
    final fim = _amostras.last;
    (int, double)? ini;
    for (final a in _amostras.reversed) {
      if (fim.$1 - a.$1 >= 20) {
        ini = a;
        break;
      }
    }
    if (ini == null) return '--';
    final dm = fim.$2 - ini.$2;
    final ds = fim.$1 - ini.$1;
    if (dm < 10 || ds <= 0) return '--';
    if (_modo.id == 'bike') return decimal(dm / ds * 3.6, 1);
    final pace = (ds / (dm / 1000)).round();
    return '${pace ~/ 60}:${(pace % 60).toString().padLeft(2, '0')}';
  }

  // ------------------------------------------------------------------
  // Tela
  // ------------------------------------------------------------------
  Widget _faixa(BuildContext context, {required Color cor, required Widget filho}) => Card(
        color: cor.withValues(alpha: 0.18),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: BorderSide(color: cor, width: 1.2),
        ),
        child: Padding(padding: const EdgeInsets.all(12), child: filho),
      );

  @override
  Widget build(BuildContext context) {
    final estilo = Theme.of(context).textTheme;
    final emQueda = _queda != null;
    final bike = _modo.id == 'bike';
    final pendente = _naoConfirmados;

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Text('Corrida', style: estilo.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          child: SegmentedButton<String>(
            segments: [
              for (final m in ModoPercurso.todos)
                ButtonSegment(
                  value: m.id,
                  label: Text(m.nome),
                  icon: Icon(m.id == 'bike' ? Icons.directions_bike : Icons.directions_run),
                ),
            ],
            selected: {_modo.id},
            onSelectionChanged: _estado != _Estado.parado
                ? null
                : (s) {
                    setState(() => _modo = ModoPercurso.de(s.first));
                    Armazenamento.salvarTexto('modo_percurso', _modo.id);
                  },
          ),
        ),
        const SizedBox(height: 4),
        Text(
          'Limite: ${_modo.limiteKmh.round()} km/h'
          '${_precisao >= 0 && _estado != _Estado.parado ? ' · GPS ±${_precisao.round()} m' : ''}'
          '${_ignorados > 0 ? ' · $_ignorados leitura(s) acima do limite ignorada(s)' : ''}',
          style: estilo.bodySmall,
        ),
        SwitchListTile(
          dense: true,
          contentPadding: EdgeInsets.zero,
          title: const Text('Pausa automática ao parar'),
          value: _autoPausa,
          onChanged: (v) {
            setState(() => _autoPausa = v);
            Armazenamento.salvarBool('auto_pausa', v);
          },
        ),

        // Painel principal: km em destaque, tempo e ritmo embaixo.
        Card(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 20),
            child: Column(
              children: [
                Text(
                  _km.toStringAsFixed(2),
                  style: TextStyle(
                    fontSize: 72,
                    fontWeight: FontWeight.w900,
                    color: context.destaque,
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconeApp(TipoIcone.pes, tamanho: 20, cor: context.destaque),
                    const SizedBox(width: 6),
                    const Text('quilômetros'),
                  ],
                ),
                if (pendente > 0)
                  Text('inclui ${pendente.round()} m a confirmar pelo GPS',
                      style: estilo.bodySmall),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _Dado(icone: TipoIcone.relogio, titulo: 'Tempo', valor: formatarTempo(_segundos)),
                    bike
                        ? _Dado(
                            icone: TipoIcone.velocimetro,
                            titulo: 'km/h',
                            valor: velocidadeMedia(_km, _segundos))
                        : _Dado(
                            icone: TipoIcone.velocimetro,
                            titulo: 'Ritmo /km',
                            valor: formatarRitmo(_km, _segundos)),
                    _Dado(icone: TipoIcone.chama, titulo: 'kcal', valor: '$_calorias'),
                  ],
                ),
                if (_estado == _Estado.correndo || _estado == _Estado.pausado) ...[
                  const SizedBox(height: 8),
                  Text('Agora: $_atual ${bike ? 'km/h' : '/km'}', style: estilo.bodySmall),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),

        if (_alerta)
          _faixa(
            context,
            cor: const Color(0xFFE74C3C),
            filho: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('⚠️ Siga o percurso marcado',
                    style: TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                const Text('O celular vai vibrar até você passar pelos pontos marcados. '
                    'Se desativar, os pontos não confirmados não entram na distância.'),
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton(
                    onPressed: _desativarAlerta,
                    child: const Text('Desativar alerta'),
                  ),
                ),
              ],
            ),
          ),
        if (_autoPausado && _estado == _Estado.pausado)
          _faixa(
            context,
            cor: const Color(0xFF0984E3),
            filho: const Text('⏸ Pausa automática. Volte a andar que a corrida continua sozinha.'),
          ),
        if (emQueda)
          _faixa(
            context,
            cor: const Color(0xFFFF9F0A),
            filho: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('📡 Sem sinal de GPS',
                    style: TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                const Text('Siga por um caminho seguro; o tempo continua contando. '
                    'Toque no mapa nos pontos por onde você passa (cada quadra). '
                    'Marque também um ponto de retorno, onde vai voltar ao percurso.'),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: SegmentedButton<bool>(
                    showSelectedIcon: false,
                    segments: const [
                      ButtonSegment(value: false, label: Text('Marcar rota'), icon: Icon(Icons.timeline)),
                      ButtonSegment(value: true, label: Text('Ponto de retorno'), icon: Icon(Icons.flag)),
                    ],
                    selected: {_marcarRetorno},
                    onSelectionChanged: (s) => setState(() => _marcarRetorno = s.first),
                  ),
                ),
                Wrap(
                  children: [
                    TextButton.icon(
                      onPressed: _desfazerMarca,
                      icon: const Icon(Icons.undo),
                      label: const Text('Desfazer'),
                    ),
                    TextButton.icon(
                      onPressed: () => setState(() => _seguirMapa = true),
                      icon: const Icon(Icons.my_location),
                      label: const Text('Seguir rota'),
                    ),
                  ],
                ),
              ],
            ),
          ),

        Card(
          clipBehavior: Clip.antiAlias,
          child: SizedBox(
            height: emQueda ? 340 : 260,
            child: MapaPercurso(
              pontos: _pontos,
              seguir: _seguirMapa,
              marcas: _marcas,
              aoToque: emQueda ? _marcarNoMapa : null,
            ),
          ),
        ),
        const SizedBox(height: 16),

        if (_erro != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Text(
              _erro!,
              style: TextStyle(color: Theme.of(context).colorScheme.error),
            ),
          ),

        // Botões mudam conforme o estado da corrida.
        if (_estado == _Estado.parado)
          FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: context.destaque),
            onPressed: _iniciar,
            icon: const Icon(Icons.play_arrow),
            label: const Text('Começar corrida'),
          )
        else if (_estado == _Estado.buscando)
          Column(
            children: [
              Row(
                children: [
                  const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      _precisao < 0
                          ? 'Buscando sinal do GPS…'
                          : 'Buscando sinal do GPS… precisão de ${_precisao.round()} m '
                              '(a corrida começa com até 20 m)',
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _cancelarBusca,
                      child: const Text('Cancelar'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton.tonal(
                      onPressed: _comecar,
                      child: const Text('Começar assim'),
                    ),
                  ),
                ],
              ),
            ],
          )
        else
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(backgroundColor: context.destaque),
                  onPressed: _estado == _Estado.correndo ? _pausar : _retomar,
                  icon: Icon(_estado == _Estado.correndo ? Icons.pause : Icons.play_arrow),
                  label: Text(_estado == _Estado.correndo ? 'Pausar' : 'Retomar'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton.tonalIcon(
                  onPressed: _finalizar,
                  icon: const Icon(Icons.stop),
                  label: const Text('Finalizar'),
                ),
              ),
            ],
          ),

        const SizedBox(height: 28),
        Text('Seus treinos', style: estilo.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 2),
        Text('Toque para ver os detalhes · segure para apagar', style: estilo.bodySmall),
        const SizedBox(height: 8),

        // Histórico: se atualiza sozinho quando um treino é salvo.
        ValueListenableBuilder<int>(
          valueListenable: Armazenamento.mudou,
          builder: (context, _, __) {
            final treinos = Armazenamento.treinos();
            if (treinos.isEmpty) {
              return const Padding(
                padding: EdgeInsets.symmetric(vertical: 16),
                child: Text('Nenhum treino ainda. Bora fazer o primeiro? 🏃'),
              );
            }
            return Column(
              children: [
                for (final t in treinos.take(20))
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: CircleAvatar(
                      backgroundColor: context.destaque.withValues(alpha: 0.15),
                      child: Icon(t.ehBike ? Icons.directions_bike : Icons.directions_run, color: context.destaque),
                    ),
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => ResumoCorridaTela(treino: t)),
                    ),
                    onLongPress: () => _apagarTreino(t),
                    trailing: const Icon(Icons.chevron_right),
                    title: Text('${decimal(t.km)} km · ${t.calorias} kcal'),
                    subtitle: Text(
                      '${formatarData(t.data)} às ${formatarHora(t.data)} · '
                      '${formatarTempo(t.segundos)} · ${t.ehBike ? '${velocidadeMedia(t.km, t.segundos)} km/h' : '${formatarRitmo(t.km, t.segundos)} /km'}',
                    ),
                  ),
              ],
            );
          },
        ),
      ],
    );
  }
}

class _Dado extends StatelessWidget {
  final TipoIcone icone;
  final String titulo;
  final String valor;
  const _Dado({required this.icone, required this.titulo, required this.valor});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        IconeApp(icone, tamanho: 24, cor: context.destaque),
        const SizedBox(height: 4),
        Text(valor, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
        Text(titulo),
      ],
    );
  }
}
