import 'dart:async';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

import '../core/armazenamento.dart';
import '../core/formatos.dart';
import '../core/tema.dart';
import '../modelos/treino.dart';
import '../servicos/gps_servico.dart';
import '../widgets/icones_app.dart';
import '../widgets/mapa_percurso.dart';
import 'resumo_corrida_tela.dart';

enum _Estado { parado, correndo, pausado }

class CorridaTela extends StatefulWidget {
  const CorridaTela({super.key});

  @override
  State<CorridaTela> createState() => _CorridaTelaState();
}

class _CorridaTelaState extends State<CorridaTela> {
  final _gps = GpsServico();
  _Estado _estado = _Estado.parado;
  double _metros = 0;
  int _segundos = 0;
  Position? _ultima;
  final List<Ponto> _pontos = [];
  double _velMax = 0;
  Timer? _timer;
  String? _erro;

  double get _km => _metros / 1000;

  // Estimativa: ~1,036 kcal por kg por km (peso vem da aba Saúde).
  int get _calorias => (1.036 * Armazenamento.pesoAtual() * _km).round();

  Future<void> _iniciar() async {
    final erro = await _gps.pedirPermissao();
    if (erro != null) {
      setState(() => _erro = erro);
      return;
    }
    setState(() {
      _erro = null;
      _estado = _Estado.correndo;
      _metros = 0;
      _segundos = 0;
      _ultima = null;
      _pontos.clear();
      _velMax = 0;
    });
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_estado == _Estado.correndo) setState(() => _segundos++);
    });
    _gps.iniciar(_aoReceberPosicao);
  }

  void _aoReceberPosicao(Position p) {
    if (_estado != _Estado.correndo) return;
    // Ignora leituras ruins do GPS (muito imprecisas).
    if (p.accuracy > 30) return;
    if (_ultima != null) {
      _metros += Geolocator.distanceBetween(
        _ultima!.latitude,
        _ultima!.longitude,
        p.latitude,
        p.longitude,
      );
    }
    _ultima = p;
    _pontos.add(Ponto(p.latitude, p.longitude, p.altitude, _segundos));
    if (p.speed * 3.6 > _velMax && p.speed * 3.6 < 25) _velMax = p.speed * 3.6;
    setState(() {});
  }

  void _pausar() => setState(() => _estado = _Estado.pausado);

  void _retomar() {
    // Zera a última posição para não "pular" a distância percorrida na pausa.
    _ultima = null;
    setState(() => _estado = _Estado.correndo);
  }

  Future<void> _finalizar() async {
    _timer?.cancel();
    _gps.parar();

    final km = _km;
    final segundos = _segundos;
    final calorias = _calorias;
    final velMax = _velMax;
    final pontos = List<Ponto>.from(_pontos);

    setState(() {
      _estado = _Estado.parado;
      _metros = 0;
      _segundos = 0;
      _ultima = null;
      _pontos.clear();
      _velMax = 0;
    });

    if (km < 0.01) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Percurso muito curto, não foi salvo.')),
      );
      return;
    }

    // Altitude subida (ignora oscilações menores que 0,5 m do GPS).
    var subida = 0.0;
    for (var i = 1; i < pontos.length; i++) {
      final d = pontos[i].alt - pontos[i - 1].alt;
      if (d > 0.5) subida += d;
    }
    // Guarda no máximo ~300 pontos para não pesar no celular.
    final passo = (pontos.length / 300).ceil().clamp(1, 1000);
    final reduzidos = [
      for (var i = 0; i < pontos.length; i += passo) pontos[i],
      if (pontos.isNotEmpty && (pontos.length - 1) % passo != 0) pontos.last,
    ];

    final treino = Treino(
      data: DateTime.now(),
      km: km,
      segundos: segundos,
      calorias: calorias,
      elevacao: subida,
      velMaxKmh: velMax,
      pontos: reduzidos,
    );
    await Armazenamento.salvarTreino(treino);
    if (!mounted) return;
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => ResumoCorridaTela(treino: treino)),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    _gps.parar();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final estilo = Theme.of(context).textTheme;

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Text('Corrida', style: estilo.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 16),

        // Painel principal: km em destaque, tempo e ritmo embaixo.
        Card(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 20),
            child: Column(
              children: [
                Text(
                  _km.toStringAsFixed(2),
                  style: TextStyle(
                    fontSize: 72,
                    fontWeight: FontWeight.w900,
                    color: context.destaque,
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconeApp(TipoIcone.pes, tamanho: 20, cor: context.destaque),
                    SizedBox(width: 6),
                    Text('quilômetros'),
                  ],
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _Dado(icone: TipoIcone.relogio, titulo: 'Tempo', valor: formatarTempo(_segundos)),
                    _Dado(icone: TipoIcone.velocimetro, titulo: 'Ritmo /km', valor: formatarRitmo(_km, _segundos)),
                    _Dado(icone: TipoIcone.chama, titulo: 'kcal', valor: '$_calorias'),
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        Card(
          clipBehavior: Clip.antiAlias,
          child: SizedBox(
            height: 260,
            child: MapaPercurso(pontos: _pontos, seguir: true),
          ),
        ),
        const SizedBox(height: 16),

        if (_erro != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Text(
              _erro!,
              style: TextStyle(color: Theme.of(context).colorScheme.error),
            ),
          ),

        // Botões mudam conforme o estado da corrida.
        if (_estado == _Estado.parado)
          FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: context.destaque),
            onPressed: _iniciar,
            icon: const Icon(Icons.play_arrow),
            label: const Text('Começar corrida'),
          )
        else
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(backgroundColor: context.destaque),
                  onPressed: _estado == _Estado.correndo ? _pausar : _retomar,
                  icon: Icon(_estado == _Estado.correndo ? Icons.pause : Icons.play_arrow),
                  label: Text(_estado == _Estado.correndo ? 'Pausar' : 'Retomar'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton.tonalIcon(
                  onPressed: _finalizar,
                  icon: const Icon(Icons.stop),
                  label: const Text('Finalizar'),
                ),
              ),
            ],
          ),

        const SizedBox(height: 28),
        Text('Seus treinos', style: estilo.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),

        // Histórico: se atualiza sozinho quando um treino é salvo.
        ValueListenableBuilder<int>(
          valueListenable: Armazenamento.mudou,
          builder: (context, _, __) {
            final treinos = Armazenamento.treinos();
            if (treinos.isEmpty) {
              return const Padding(
                padding: EdgeInsets.symmetric(vertical: 16),
                child: Text('Nenhum treino ainda. Bora fazer o primeiro? 🏃'),
              );
            }
            return Column(
              children: [
                for (final t in treinos.take(20))
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: CircleAvatar(
                      backgroundColor: context.destaque.withValues(alpha: 0.15),
                      child: Icon(Icons.directions_run, color: context.destaque),
                    ),
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => ResumoCorridaTela(treino: t)),
                    ),
                    trailing: const Icon(Icons.chevron_right),
                    title: Text('${decimal(t.km)} km · ${t.calorias} kcal'),
                    subtitle: Text(
                      '${formatarData(t.data)} às ${formatarHora(t.data)} · '
                      '${formatarTempo(t.segundos)} · ${formatarRitmo(t.km, t.segundos)} /km',
                    ),
                  ),
              ],
            );
          },
        ),
      ],
    );
  }
}

class _Dado extends StatelessWidget {
  final TipoIcone icone;
  final String titulo;
  final String valor;
  const _Dado({required this.icone, required this.titulo, required this.valor});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        IconeApp(icone, tamanho: 24, cor: context.destaque),
        const SizedBox(height: 4),
        Text(valor, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
        Text(titulo),
      ],
    );
  }
}
