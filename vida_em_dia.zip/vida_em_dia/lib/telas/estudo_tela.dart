import 'dart:async';

import 'package:flutter/material.dart';

import '../core/armazenamento.dart';
import '../core/formatos.dart';
import '../core/tema.dart';
import '../servicos/notificacao_servico.dart';
import '../widgets/observacao.dart';

const tiposDeEstudo = [
  'Videoaula', 'Curso', 'Apostila / PDF', 'Exercícios', 'Revisão', 'Outro',
];

/// Parte "Estudo" de Estudos - Leitura: cronômetro com tipo, matéria e
/// anotação (tudo opcional) e o histórico de tudo que foi estudado.
class EstudoTela extends StatefulWidget {
  const EstudoTela({super.key});

  @override
  State<EstudoTela> createState() => _EstudoTelaState();
}

enum _Cron { parado, correndo, pausado }

class _EstudoTelaState extends State<EstudoTela> {
  final _materia = TextEditingController();
  final _nota = TextEditingController();
  String _tipo = tiposDeEstudo.first;

  // Stopwatch continua certo mesmo com a tela apagada.
  final _cron = Stopwatch();
  Timer? _timer;
  DateTime? _inicio;
  _Cron _estado = _Cron.parado;

  String? _filtroMateria; // histórico
  String? _filtroTipo;

  @override
  void dispose() {
    _timer?.cancel();
    _materia.dispose();
    _nota.dispose();
    super.dispose();
  }

  int get _segundos => _cron.elapsed.inSeconds;

  void _iniciar() {
    _inicio = DateTime.now();
    _cron
      ..reset()
      ..start();
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && _estado == _Cron.correndo) setState(() {});
    });
    setState(() => _estado = _Cron.correndo);
  }

  void _pausarOuContinuar() {
    setState(() {
      if (_estado == _Cron.correndo) {
        _cron.stop();
        _estado = _Cron.pausado;
      } else {
        _cron.start();
        _estado = _Cron.correndo;
      }
    });
  }

  Future<void> _finalizar() async {
    _cron.stop();
    final seg = _segundos;
    final msg = ScaffoldMessenger.of(context);
    if (seg < 10) {
      msg.showSnackBar(const SnackBar(content: Text('Menos de 10 segundos, não foi salvo.')));
    } else {
      await Armazenamento.adicionar('estudos', {
        'data': (_inicio ?? DateTime.now()).toIso8601String(),
        'fim': DateTime.now().toIso8601String(),
        's': seg,
        'tipo': _tipo,
        'materia': _materia.text.trim(),
        'nota': _nota.text.trim(),
      });
      NotificacaoServico.reagendarEstudo(); // já estudou hoje: aviso fica para amanhã
      msg.showSnackBar(SnackBar(content: Text('Estudo salvo: ${formatarDuracao(seg)} ✅')));
    }
    _timer?.cancel();
    _cron.reset();
    _nota.clear();
    if (!mounted) return;
    setState(() => _estado = _Cron.parado);
  }

  Future<void> _descartar() async {
    final sim = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Descartar este estudo?'),
        content: const Text('O tempo contado não será salvo.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Continuar')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Descartar')),
        ],
      ),
    );
    if (sim != true) return;
    _timer?.cancel();
    _cron
      ..stop()
      ..reset();
    setState(() => _estado = _Cron.parado);
  }

  Future<void> _apagar(int indice) async {
    final sim = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Apagar este estudo?'),
        content: const Text('Não dá para desfazer.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Apagar')),
        ],
      ),
    );
    if (sim == true) await Armazenamento.remover('estudos', indice);
  }

  Widget _titulo(String t) => Padding(
        padding: const EdgeInsets.only(top: 18, bottom: 6),
        child: Text(t,
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(fontWeight: FontWeight.w700)),
      );

  @override
  Widget build(BuildContext context) {
    final ativo = _estado != _Cron.parado;

    return ValueListenableBuilder<int>(
      valueListenable: Armazenamento.mudou,
      builder: (context, _, __) {
        final todos = Armazenamento.lista('estudos'); // mais novo primeiro
        final materias = <String>[];
        for (final e in todos) {
          final m = ((e['materia'] as String?) ?? '').trim();
          if (m.isNotEmpty && !materias.contains(m)) materias.add(m);
        }

        // Quais itens aparecem no histórico (guarda a posição na lista completa).
        final visiveis = <int>[
          for (var i = 0; i < todos.length; i++)
            if ((_filtroMateria == null ||
                    ((todos[i]['materia'] as String?) ?? '') == _filtroMateria) &&
                (_filtroTipo == null || ((todos[i]['tipo'] as String?) ?? '') == _filtroTipo))
              i,
        ];

        // Total do mês por matéria
        final agora = DateTime.now();
        final porMateria = <String, int>{};
        var totalMes = 0;
        for (final e in todos) {
          final d = DateTime.parse(e['data'] as String);
          if (d.year != agora.year || d.month != agora.month) continue;
          final m = ((e['materia'] as String?) ?? '').trim();
          final nome = m.isEmpty ? 'Sem matéria' : m;
          final seg = e['s'] as int;
          porMateria[nome] = (porMateria[nome] ?? 0) + seg;
          totalMes += seg;
        }
        final ordenadas = porMateria.entries.toList()..sort((a, b) => b.value.compareTo(a.value));

        return ListView(
          padding: const EdgeInsets.all(20),
          children: [
            if (ativo)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      Text(
                        '$_tipo${_materia.text.trim().isEmpty ? '' : ' · ${_materia.text.trim()}'}',
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        formatarHMS(_segundos),
                        style: TextStyle(
                          fontSize: 48,
                          fontWeight: FontWeight.w900,
                          color: context.destaque,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Expanded(
                            child: FilledButton.icon(
                              style: FilledButton.styleFrom(
                                  backgroundColor: context.destaque,
                                  minimumSize: const Size.fromHeight(46)),
                              onPressed: _pausarOuContinuar,
                              icon: Icon(_estado == _Cron.correndo ? Icons.pause : Icons.play_arrow),
                              label: Text(_estado == _Cron.correndo ? 'Pausar' : 'Continuar'),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: FilledButton.tonalIcon(
                              style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(46)),
                              onPressed: _finalizar,
                              icon: const Icon(Icons.stop),
                              label: const Text('Finalizar'),
                            ),
                          ),
                        ],
                      ),
                      TextButton(onPressed: _descartar, child: const Text('Descartar')),
                    ],
                  ),
                ),
              ),

            // ---- O que vai estudar (tudo opcional) ----
            _titulo(ativo ? 'Detalhes do estudo' : 'Novo estudo'),
            const Text('Tipo de estudo (opcional)', style: TextStyle(fontSize: 12)),
            const SizedBox(height: 4),
            Wrap(
              spacing: 8,
              children: [
                for (final t in tiposDeEstudo)
                  ChoiceChip(
                    label: Text(t),
                    selected: _tipo == t,
                    onSelected: (_) => setState(() => _tipo = t),
                  ),
              ],
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _materia,
              onChanged: (_) => setState(() {}),
              textCapitalization: TextCapitalization.sentences,
              decoration: const InputDecoration(
                labelText: 'Matéria (opcional)',
                hintText: 'Ex.: Matemática, Inglês, Programação',
              ),
            ),
            if (materias.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Wrap(
                  spacing: 8,
                  children: [
                    for (final m in materias.take(8))
                      ActionChip(
                        label: Text(m),
                        onPressed: () => setState(() => _materia.text = m),
                      ),
                  ],
                ),
              ),
            const SizedBox(height: 10),
            TextField(
              controller: _nota,
              textCapitalization: TextCapitalization.sentences,
              decoration: const InputDecoration(
                labelText: 'Anotação (opcional)',
                hintText: 'Ex.: aula 12, módulo 3',
              ),
            ),
            if (!ativo) ...[
              const SizedBox(height: 12),
              FilledButton.icon(
                style: FilledButton.styleFrom(backgroundColor: context.destaque),
                onPressed: _iniciar,
                icon: const Icon(Icons.play_arrow),
                label: const Text('Iniciar estudo'),
              ),
            ],

            // ---- Observações (ficam na planilha de observações de estudo) ----
            _titulo('Observações'),
            CampoObservacao(
              key: const ValueKey('obs_estudo'),
              modo: 'estudo',
              ref: () => _materia.text.trim(),
              dica: 'Ex.: Em Python, a variável vem sempre antes do igual',
            ),
            const SizedBox(height: 14),
            const PlanilhaObservacoes(modo: 'estudo', titulo: 'Observações de estudo'),

            // ---- Resumo do mês por matéria ----
            if (ordenadas.isNotEmpty) ...[
              _titulo('${nomesMeses[agora.month - 1]}: ${formatarDuracao(totalMes)} de estudo'),
              Card(
                child: Column(
                  children: [
                    for (final e in ordenadas)
                      ListTile(
                        dense: true,
                        title: Text(e.key),
                        trailing: Text(formatarDuracao(e.value),
                            style: const TextStyle(fontWeight: FontWeight.w700)),
                      ),
                  ],
                ),
              ),
            ],

            // ---- Histórico de estudos ----
            _titulo('Histórico de estudos'),
            if (todos.isNotEmpty) ...[
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    FilterChip(
                      label: const Text('Todas as matérias'),
                      selected: _filtroMateria == null,
                      onSelected: (_) => setState(() => _filtroMateria = null),
                    ),
                    for (final m in materias) ...[
                      const SizedBox(width: 8),
                      FilterChip(
                        label: Text(m),
                        selected: _filtroMateria == m,
                        onSelected: (v) => setState(() => _filtroMateria = v ? m : null),
                      ),
                    ],
                  ],
                ),
              ),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    FilterChip(
                      label: const Text('Todos os tipos'),
                      selected: _filtroTipo == null,
                      onSelected: (_) => setState(() => _filtroTipo = null),
                    ),
                    for (final t in tiposDeEstudo) ...[
                      const SizedBox(width: 8),
                      FilterChip(
                        label: Text(t),
                        selected: _filtroTipo == t,
                        onSelected: (v) => setState(() => _filtroTipo = v ? t : null),
                      ),
                    ],
                  ],
                ),
              ),
            ],
            if (visiveis.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 16),
                child: Text('Nenhum estudo registrado ainda. Bora começar? 📚'),
              ),
            ..._itensDoHistorico(todos, visiveis),
          ],
        );
      },
    );
  }

  List<Widget> _itensDoHistorico(List<Map<String, dynamic>> todos, List<int> visiveis) {
    // total de cada dia (só dos itens que estão aparecendo)
    final porDia = <String, int>{};
    String chave(DateTime d) => '${formatarData(d)}/${d.year}';
    for (final i in visiveis) {
      final k = chave(DateTime.parse(todos[i]['data'] as String));
      porDia[k] = (porDia[k] ?? 0) + (todos[i]['s'] as int);
    }

    final itens = <Widget>[];
    String? ultimo;
    for (final i in visiveis.take(150)) {
      final e = todos[i];
      final d = DateTime.parse(e['data'] as String);
      final dia = chave(d);
      if (dia != ultimo) {
        ultimo = dia;
        itens.add(Padding(
          padding: const EdgeInsets.only(top: 14, bottom: 4),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(dia, style: const TextStyle(fontWeight: FontWeight.w800)),
              Text('total do dia: ${formatarDuracao(porDia[dia]!)}'),
            ],
          ),
        ));
      }
      final materia = ((e['materia'] as String?) ?? '').trim();
      final nota = ((e['nota'] as String?) ?? '').trim();
      final fim = e['fim'] == null ? null : DateTime.parse(e['fim'] as String);
      itens.add(ListTile(
        contentPadding: EdgeInsets.zero,
        leading: CircleAvatar(
          backgroundColor: context.destaque.withValues(alpha: 0.15),
          child: Icon(Icons.school_outlined, color: context.destaque),
        ),
        title: Text('${materia.isEmpty ? 'Sem matéria' : materia} · ${e['tipo'] ?? 'Estudo'}'),
        subtitle: Text(
          '${formatarHora(d)}${fim == null ? '' : ' → ${formatarHora(fim)}'} · '
          '${formatarDuracao(e['s'] as int)}${nota.isEmpty ? '' : '\n$nota'}',
        ),
        isThreeLine: nota.isNotEmpty,
        trailing: IconButton(
          icon: const Icon(Icons.delete_outline, size: 20),
          onPressed: () => _apagar(i),
        ),
      ));
    }
    return itens;
  }
}
