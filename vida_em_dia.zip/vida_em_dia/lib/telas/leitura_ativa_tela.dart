import 'dart:async';

import 'package:flutter/material.dart';

import '../core/armazenamento.dart';
import '../core/formatos.dart';
import '../core/tema.dart';
import '../modelos/livro.dart';
import '../modelos/sessao_leitura.dart';
import '../widgets/icones_app.dart';

/// Tela "Marcador de Livros": cronômetro de uma leitura em andamento.
class LeituraAtivaTela extends StatefulWidget {
  final Livro livro;
  const LeituraAtivaTela({super.key, required this.livro});

  @override
  State<LeituraAtivaTela> createState() => _LeituraAtivaTelaState();
}

class _LeituraAtivaTelaState extends State<LeituraAtivaTela> {
  // Stopwatch continua certo mesmo com a tela apagada.
  final _cron = Stopwatch()..start();
  Timer? _timer;
  final _inicio = DateTime.now();
  late final int _paginaInicio = Armazenamento.paginaAtual(widget.livro.id);

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  int get _segundos => _cron.elapsed.inSeconds;

  void _pausarOuContinuar() {
    setState(() => _cron.isRunning ? _cron.stop() : _cron.start());
  }

  Future<void> _finalizar() async {
    _cron.stop();
    setState(() {});
    final r = await showDialog<(int, String)>(
      context: context,
      barrierDismissible: false,
      builder: (_) => _DialogoPagina(paginaAtual: _paginaInicio, total: widget.livro.totalPaginas),
    );
    if (!mounted) return;
    if (r == null) {
      _cron.start(); // cancelou: volta a contar
      setState(() {});
      return;
    }

    final seg = _segundos;
    final msg = ScaffoldMessenger.of(context);
    if (seg < 10) {
      msg.showSnackBar(const SnackBar(content: Text('Menos de 10 segundos, não foi salva.')));
    } else {
      await Armazenamento.salvarLeitura(SessaoLeitura(
        data: _inicio,
        fim: DateTime.now(),
        livro: widget.livro.titulo,
        livroId: widget.livro.id,
        segundos: seg,
        paginaInicio: _paginaInicio,
        paginaFim: r.$1,
        nota: r.$2,
      ));
      msg.showSnackBar(SnackBar(content: Text('Leitura salva: ${formatarDuracao(seg)} 📚')));
    }
    if (mounted) Navigator.pop(context);
  }

  Future<bool> _confirmarSaida() async {
    if (_segundos < 5) return true;
    final sair = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Sair sem salvar?'),
        content: const Text('Esta leitura será descartada.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Continuar lendo')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Sair')),
        ],
      ),
    );
    return sair == true;
  }

  @override
  Widget build(BuildContext context) {
    final cor = context.destaque;
    final estilo = Theme.of(context).textTheme;
    final l = widget.livro;
    final total = l.totalPaginas;
    final pct = total > 0 ? (_paginaInicio / total).clamp(0.0, 1.0) : 0.0;
    final correndo = _cron.isRunning;

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        if (await _confirmarSaida() && context.mounted) Navigator.pop(context);
      },
      child: Scaffold(
        appBar: AppBar(title: const Text('Marcador de Livros')),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Center(child: IconeApp(TipoIcone.livro, tamanho: 80, cor: cor)),
            const SizedBox(height: 8),
            Center(
              child: Text('Tempo de Leitura',
                  style: estilo.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
            ),
            const SizedBox(height: 4),
            FittedBox(
              child: Text(
                formatarHMS(_segundos),
                style: TextStyle(
                  fontSize: 76,
                  fontWeight: FontWeight.w900,
                  color: cor,
                  fontFeatures: const [FontFeature.tabularFigures()],
                ),
              ),
            ),
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [Text('Horas'), Text('Minutos'), Text('Segundos')],
            ),
            const SizedBox(height: 20),
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
                side: BorderSide(color: cor.withValues(alpha: 0.6)),
              ),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Row(children: [
                  const CapaLivro(tamanho: 72),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(l.titulo,
                            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                        if (l.autor.isNotEmpty) Text(l.autor),
                        const SizedBox(height: 8),
                        Row(children: [
                          Icon(Icons.bookmark, color: cor, size: 20),
                          const SizedBox(width: 4),
                          Flexible(
                            child: Text(
                              total > 0
                                  ? 'Página atual: $_paginaInicio de $total'
                                  : 'Página atual: $_paginaInicio',
                            ),
                          ),
                        ]),
                        if (total > 0) ...[
                          const SizedBox(height: 8),
                          Row(children: [
                            Expanded(
                              child: LinearProgressIndicator(
                                value: pct,
                                minHeight: 10,
                                borderRadius: BorderRadius.circular(8),
                                color: cor,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text('${(pct * 100).round()}%',
                                style: const TextStyle(fontWeight: FontWeight.w700)),
                          ]),
                        ],
                      ],
                    ),
                  ),
                ]),
              ),
            ),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 14),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _Info(Icons.schedule, 'Tempo total', formatarDuracao(_segundos), cor),
                    _Info(Icons.menu_book, 'Páginas lidas', '$_paginaInicio', cor),
                    _Info(Icons.calendar_month, 'Início',
                        '${formatarData(_inicio)}\n${formatarHora(_inicio)}', cor),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            Row(children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: _pausarOuContinuar,
                  icon: Icon(correndo ? Icons.pause : Icons.play_arrow),
                  label: Text(correndo ? 'Pausar' : 'Continuar'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size.fromHeight(56),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                    textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                  ),
                  onPressed: _finalizar,
                  icon: const Icon(Icons.stop),
                  label: const Text('Finalizar'),
                ),
              ),
            ]),
          ],
        ),
      ),
    );
  }
}

class _Info extends StatelessWidget {
  final IconData icone;
  final String titulo, valor;
  final Color cor;
  const _Info(this.icone, this.titulo, this.valor, this.cor);

  @override
  Widget build(BuildContext context) => Column(children: [
        Icon(icone, color: cor),
        const SizedBox(height: 4),
        Text(titulo, style: const TextStyle(fontSize: 12)),
        Text(valor,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
      ]);
}

/// Pergunta em que página você parou (e uma anotação opcional).
class _DialogoPagina extends StatefulWidget {
  final int paginaAtual, total;
  const _DialogoPagina({required this.paginaAtual, required this.total});

  @override
  State<_DialogoPagina> createState() => _DialogoPaginaState();
}

class _DialogoPaginaState extends State<_DialogoPagina> {
  late final _pag = TextEditingController(
      text: widget.paginaAtual > 0 ? '${widget.paginaAtual}' : '');
  final _nota = TextEditingController();
  String? _erro;

  @override
  void dispose() {
    _pag.dispose();
    _nota.dispose();
    super.dispose();
  }

  void _salvar() {
    final p = int.tryParse(_pag.text.trim()) ?? widget.paginaAtual;
    if (widget.total > 0 && p > widget.total) {
      setState(() => _erro = 'O livro tem ${widget.total} páginas.');
      return;
    }
    Navigator.pop(context, (p < 0 ? 0 : p, _nota.text.trim()));
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Em que página você parou?'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _pag,
            autofocus: true,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: 'Página', errorText: _erro),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _nota,
            decoration: const InputDecoration(
              labelText: 'Anotação (opcional)',
              hintText: 'ex.: 3 capítulos',
            ),
          ),
        ],
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Voltar')),
        FilledButton(
          style: FilledButton.styleFrom(minimumSize: const Size(0, 44)),
          onPressed: _salvar,
          child: const Text('Salvar'),
        ),
      ],
    );
  }
}
