import 'dart:async';

import 'package:flutter/material.dart';

import '../servicos/notificacao_servico.dart';
import '../core/armazenamento.dart';
import '../core/formatos.dart';
import '../core/tema.dart';
import '../modelos/livro.dart';
import '../core/biblia.dart';
import '../core/texto.dart';
import '../modelos/sessao_leitura.dart';
import '../modelos/trecho.dart';
import '../widgets/observacao.dart';
import '../widgets/icones_app.dart';
import '../widgets/zoom_tela.dart';

/// Tela "Marcador de Livros": cronômetro de uma leitura em andamento.
class LeituraAtivaTela extends StatefulWidget {
  final Livro livro;
  const LeituraAtivaTela({super.key, required this.livro});

  @override
  State<LeituraAtivaTela> createState() => _LeituraAtivaTelaState();
}

/// Os campos de um trecho lido (páginas, ou parte + capítulo + versículo).
class _TrechoEd {
  final parte = TextEditingController();
  final ci = TextEditingController();
  final vi = TextEditingController();
  final cf = TextEditingController();
  final vf = TextEditingController();
  final pi = TextEditingController();
  final pf = TextEditingController();

  void dispose() {
    for (final c in [parte, ci, vi, cf, vf, pi, pf]) {
      c.dispose();
    }
  }
}

class _LeituraAtivaTelaState extends State<LeituraAtivaTela> {
  // Stopwatch continua certo mesmo com a tela apagada.
  final _cron = Stopwatch()..start();
  Timer? _timer;
  final _inicio = DateTime.now();
  late final int _paginaInicio = Armazenamento.paginaAtual(widget.livro.id);
  late final Trecho? _posicao =
      widget.livro.comDivisoes ? Armazenamento.posicaoLivro(widget.livro.id) : null;
  final List<_TrechoEd> _trechos = [];

  @override
  void initState() {
    super.initState();
    // O primeiro trecho já começa de onde você parou da última vez.
    final e = _TrechoEd();
    if (widget.livro.comDivisoes) {
      final p = _posicao;
      if (p != null) {
        e.parte.text = p.parte;
        final cap = p.capFim > 0 ? p.capFim : p.capIni;
        final vers = p.capFim > 0 ? p.versFim : p.versIni;
        if (cap > 0) e.ci.text = '$cap';
        if (vers > 0) e.vi.text = '$vers';
      }
    } else if (_paginaInicio > 0) {
      e.pi.text = '$_paginaInicio';
    }
    _trechos.add(e);
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    for (final t in _trechos) {
      t.dispose();
    }
    super.dispose();
  }

  int get _segundos => _cron.elapsed.inSeconds;

  void _pausarOuContinuar() {
    setState(() => _cron.isRunning ? _cron.stop() : _cron.start());
  }

  void _erro(String texto) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(texto)));
  }

  /// Lê os campos e devolve os trechos (ou null se algo estiver errado).
  List<Trecho>? _montar() {
    final l = widget.livro;
    int n(TextEditingController c) => int.tryParse(c.text.trim()) ?? 0;
    final out = <Trecho>[];
    for (final e in _trechos) {
      if (l.comDivisoes) {
        var parte = e.parte.text.trim();
        final certo = l.ehBiblia ? nomeBiblia(parte) : null;
        if (certo != null) parte = certo;
        final t = Trecho(
          parte: parte,
          capIni: n(e.ci),
          versIni: n(e.vi),
          capFim: n(e.cf),
          versFim: n(e.vf),
        );
        if (t.vazio) continue;
        if (l.ehBiblia) {
          final max = capitulosDoLivro(parte);
          if (max != null && (t.capIni > max || t.capFim > max)) {
            _erro('$parte tem $max capítulos.');
            return null;
          }
        }
        if (t.capIni > 0 && t.capFim > 0 && t.capFim < t.capIni) {
          _erro('O capítulo final não pode vir antes do inicial.');
          return null;
        }
        out.add(t);
      } else {
        final t = Trecho(pagIni: n(e.pi), pagFim: n(e.pf));
        if (t.vazio) continue;
        if (l.totalPaginas > 0 && t.pagFim > l.totalPaginas) {
          _erro('O livro tem ${l.totalPaginas} páginas.');
          return null;
        }
        if (t.pagFim > 0 && t.pagIni > 0 && t.pagFim < t.pagIni) {
          _erro('A página final não pode vir antes da inicial.');
          return null;
        }
        out.add(t);
      }
    }
    return out;
  }

  Future<void> _finalizar() async {
    _cron.stop();
    setState(() {});
    final trechos = _montar();
    if (trechos == null) {
      _cron.start(); // arrumou o erro e continua
      setState(() {});
      return;
    }

    final nota = await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const _DialogoNota(),
    );
    if (!mounted) return;
    if (nota == null) {
      _cron.start(); // voltou: continua a contar
      setState(() {});
      return;
    }

    final seg = _segundos;
    final msg = ScaffoldMessenger.of(context);
    if (seg < 10) {
      msg.showSnackBar(const SnackBar(content: Text('Menos de 10 segundos, não foi salva.')));
    } else {
      final principal = trechos.isEmpty ? null : trechos.first;
      final comDiv = widget.livro.comDivisoes;
      await Armazenamento.salvarLeitura(SessaoLeitura(
        data: _inicio,
        fim: DateTime.now(),
        livro: widget.livro.titulo,
        livroId: widget.livro.id,
        segundos: seg,
        paginaInicio: comDiv ? 0 : ((principal?.pagIni ?? 0) > 0 ? principal!.pagIni : _paginaInicio),
        paginaFim: comDiv ? 0 : ((principal?.pagFim ?? 0) > 0 ? principal!.pagFim : _paginaInicio),
        nota: nota,
        trechos: trechos,
      ));
      NotificacaoServico.reagendarEstudo(); // já estudou hoje: aviso fica para amanhã
      msg.showSnackBar(SnackBar(content: Text('Leitura salva: ${formatarDuracao(seg)} 📚')));
    }
    if (mounted) Navigator.pop(context);
  }

  Future<bool> _confirmarSaida() async {
    if (_segundos < 5) return true;
    final sair = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Sair sem salvar?'),
        content: const Text('Esta leitura será descartada.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Continuar lendo')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Sair')),
        ],
      ),
    );
    return sair == true;
  }

  // ------------------------------------------------------------------
  // Peças da tela
  // ------------------------------------------------------------------
  Widget _campoNumero(TextEditingController c, String rotulo) => Expanded(
        child: Padding(
          padding: const EdgeInsets.only(right: 6),
          child: TextField(
            controller: c,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: rotulo, isDense: true),
          ),
        ),
      );

  /// Nomes que combinam com o que a pessoa está digitando em "parte".
  List<String> _sugestoes(String digitado) {
    final l = widget.livro;
    final usadas = <String>[];
    for (final s in Armazenamento.sessoesDoLivro(l.id)) {
      for (final t in s.trechos) {
        if (t.parte.isNotEmpty && !usadas.contains(t.parte)) usadas.add(t.parte);
      }
    }
    final n = normalizar(digitado);
    if (n.isEmpty) return usadas.take(4).toList();
    final r = <String>[];
    if (l.ehBiblia) r.addAll(sugerirBiblia(digitado));
    for (final u in usadas) {
      if (normalizar(u).contains(n) && !r.contains(u)) r.add(u);
    }
    // se já digitou exatamente um nome, não precisa sugerir de novo
    if (r.length == 1 && normalizar(r.first) == n) return const [];
    return r.take(6).toList();
  }

  Widget _editor(int i) {
    final e = _trechos[i];
    final l = widget.livro;
    final sug = l.comDivisoes ? _sugestoes(e.parte.text) : const <String>[];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(i == 0 ? 'Leitura principal' : 'Outro trecho lido',
                  style: const TextStyle(fontWeight: FontWeight.w800)),
            ),
            if (i > 0)
              IconButton(
                tooltip: 'Tirar este trecho',
                icon: const Icon(Icons.close, size: 20),
                onPressed: () => setState(() => _trechos.removeAt(i).dispose()),
              ),
          ],
        ),
        if (l.comDivisoes) ...[
          TextField(
            controller: e.parte,
            onChanged: (_) => setState(() {}),
            textCapitalization: TextCapitalization.words,
            decoration: InputDecoration(
              labelText: l.ehBiblia ? 'Livro da Bíblia' : 'Parte, livro ou seção',
              hintText: l.ehBiblia ? 'Ex.: Gênesis' : 'Ex.: Parte 1',
              isDense: true,
            ),
          ),
          if (sug.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Wrap(
                spacing: 6,
                children: [
                  for (final s in sug)
                    ActionChip(
                      label: Text(s),
                      visualDensity: VisualDensity.compact,
                      onPressed: () => setState(() => e.parte.text = s),
                    ),
                ],
              ),
            ),
          const SizedBox(height: 8),
          const Text('Começou em', style: TextStyle(fontSize: 12)),
          Row(children: [
            _campoNumero(e.ci, 'Capítulo'),
            _campoNumero(e.vi, 'Versículo'),
          ]),
          const SizedBox(height: 8),
          const Text('Parou em', style: TextStyle(fontSize: 12)),
          Row(children: [
            _campoNumero(e.cf, 'Capítulo'),
            _campoNumero(e.vf, 'Versículo'),
          ]),
        ] else ...[
          Row(children: [
            _campoNumero(e.pi, 'Página inicial'),
            _campoNumero(e.pf, 'Parou na página'),
          ]),
        ],
      ],
    );
  }

  /// Texto de "onde parou" para o cabeçalho do livro.
  String get _ondeParou {
    final l = widget.livro;
    if (!l.comDivisoes) {
      return l.totalPaginas > 0
          ? 'Página atual: $_paginaInicio de ${l.totalPaginas}'
          : 'Página atual: $_paginaInicio';
    }
    final t = _posicao?.ondeParou ?? '';
    return t.isEmpty ? 'Ainda sem marcação' : 'Parou em: $t';
  }

  @override
  Widget build(BuildContext context) {
    final cor = context.destaque;
    final estilo = Theme.of(context).textTheme;
    final l = widget.livro;
    final total = l.totalPaginas;
    final pct = (!l.comDivisoes && total > 0) ? (_paginaInicio / total).clamp(0.0, 1.0) : 0.0;
    final correndo = _cron.isRunning;

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        if (await _confirmarSaida() && context.mounted) Navigator.pop(context);
      },
      child: Scaffold(
        appBar: AppBar(title: const Text('Marcador de Livros')),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Center(child: IconeApp(TipoIcone.livro, tamanho: 80, cor: cor)),
            const SizedBox(height: 8),
            Center(
              child: Text('Tempo de Leitura',
                  style: estilo.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
            ),
            const SizedBox(height: 4),
            FittedBox(
              child: Text(
                formatarHMS(_segundos),
                style: TextStyle(
                  fontSize: 76,
                  fontWeight: FontWeight.w900,
                  color: cor,
                  fontFeatures: const [FontFeature.tabularFigures()],
                ),
              ),
            ),
            const Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [Text('Horas'), Text('Minutos'), Text('Segundos')],
            ),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: _pausarOuContinuar,
                  icon: Icon(correndo ? Icons.pause : Icons.play_arrow),
                  label: Text(correndo ? 'Pausar' : 'Continuar'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                    minimumSize: Size.fromHeight(context.altSec(44)),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                    textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                  ),
                  onPressed: _finalizar,
                  icon: const Icon(Icons.stop),
                  label: const Text('Finalizar'),
                ),
              ),
            ]),
            const SizedBox(height: 16),
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
                side: BorderSide(color: cor.withValues(alpha: 0.6)),
              ),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Row(children: [
                  const CapaLivro(tamanho: 64),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(l.titulo,
                            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                        if (l.autor.isNotEmpty) Text(l.autor),
                        const SizedBox(height: 8),
                        Row(children: [
                          Icon(Icons.bookmark, color: cor, size: 20),
                          const SizedBox(width: 4),
                          Flexible(child: Text(_ondeParou)),
                        ]),
                        if (!l.comDivisoes && total > 0) ...[
                          const SizedBox(height: 8),
                          Row(children: [
                            Expanded(
                              child: LinearProgressIndicator(
                                value: pct,
                                minHeight: 10,
                                borderRadius: BorderRadius.circular(8),
                                color: cor,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text('${(pct * 100).round()}%',
                                style: const TextStyle(fontWeight: FontWeight.w700)),
                          ]),
                        ],
                      ],
                    ),
                  ),
                ]),
              ),
            ),
            const SizedBox(height: 12),

            // ---- Onde você está lendo ----
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Onde você está lendo',
                        style: estilo.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 8),
                    for (var i = 0; i < _trechos.length; i++) ...[
                      if (i > 0) const Divider(height: 20),
                      _editor(i),
                    ],
                    const SizedBox(height: 4),
                    TextButton.icon(
                      onPressed: () => setState(() => _trechos.add(_TrechoEd())),
                      icon: const Icon(Icons.add),
                      label: const Text('Adicionar outro trecho lido'),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),

            // ---- Observações ----
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Observações',
                        style: estilo.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 8),
                    CampoObservacao(
                      modo: 'leitura',
                      completo: true,
                      livroId: l.id,
                      ref: () => l.titulo,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 14),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _Info(Icons.schedule, 'Tempo total', formatarDuracao(_segundos), cor),
                    _Info(Icons.calendar_month, 'Início',
                        '${formatarData(_inicio)}\n${formatarHora(_inicio)}', cor),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}

class _Info extends StatelessWidget {
  final IconData icone;
  final String titulo, valor;
  final Color cor;
  const _Info(this.icone, this.titulo, this.valor, this.cor);

  @override
  Widget build(BuildContext context) => Column(children: [
        Icon(icone, color: cor),
        const SizedBox(height: 4),
        Text(titulo, style: const TextStyle(fontSize: 12)),
        Text(valor,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
      ]);
}

/// Anotação opcional ao terminar a leitura.
class _DialogoNota extends StatefulWidget {
  const _DialogoNota();

  @override
  State<_DialogoNota> createState() => _DialogoNotaState();
}

class _DialogoNotaState extends State<_DialogoNota> {
  final _nota = TextEditingController();

  @override
  void dispose() {
    _nota.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Terminar a leitura'),
      content: TextField(
        controller: _nota,
        decoration: const InputDecoration(
          labelText: 'Anotação (opcional)',
          hintText: 'ex.: 3 capítulos',
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Voltar')),
        TextButton(
          onPressed: () => Navigator.pop(context, _nota.text.trim()),
          child: const Text('Salvar'),
        ),
      ],
    );
  }
}
