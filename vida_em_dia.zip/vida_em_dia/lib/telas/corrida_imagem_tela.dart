import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart' hide Path;

import '../core/armazenamento.dart';
import '../core/exportar.dart';
import '../core/formatos.dart';
import '../core/periodo.dart';
import '../core/tema.dart';
import '../modelos/treino.dart';

enum _Posicao { inferior, superior, laterais, cantos, livre }

enum _Fundo { mapa, liso }

class _Stat {
  final String id, rotulo, valor;
  const _Stat(this.id, this.rotulo, this.valor);
}

/// Cria a imagem da corrida: o mapa com o percurso e os resultados por cima.
/// Os resultados podem mudar de lugar (laterais, em cima, embaixo, nas pontas
/// ou arrastando com o dedo), de tamanho e de cor. Só salva como imagem (PNG).
class CorridaImagemTela extends StatefulWidget {
  final PeriodoRel? periodo;
  final Treino? treino; // se vier de um treino específico

  const CorridaImagemTela({super.key, this.periodo, this.treino});

  @override
  State<CorridaImagemTela> createState() => _CorridaImagemTelaState();
}

class _CorridaImagemTelaState extends State<CorridaImagemTela> {
  final _chave = GlobalKey();

  late PeriodoRel _periodo;
  String _filtro = 'todos'; // todos | corrida | bike
  int? _selTreino; // no modo diário: posição na lista do dia (null = todos do dia)

  double _aspecto = 0.8; // largura / altura
  _Fundo _fundo = _Fundo.mapa;
  _Posicao _posicao = _Posicao.inferior;
  double _escala = 1.0;
  Color? _corTexto; // null = branco
  Color? _corRota; // null = cor de destaque do app
  bool _fundoNosNumeros = true;
  bool _travarRolagem = false;
  bool _salvando = false;

  late Set<String> _ativos;
  final Map<String, Offset> _pos = {};

  static const _ordem = [
    'dist', 'tempo', 'ritmo', 'cal', 'data', 'dias', 'treinos', 'vmax', 'elev', 'modo',
  ];

  @override
  void initState() {
    super.initState();
    if (widget.treino != null) {
      _periodo = PeriodoRel(TipoPeriodo.dia, widget.treino!.data);
      final doDia = _treinosDoPeriodo(somenteFiltro: false);
      final i = doDia.indexWhere((t) => t.data == widget.treino!.data);
      _selTreino = i < 0 ? null : i;
    } else {
      _periodo = widget.periodo ?? PeriodoRel.hoje(TipoPeriodo.dia);
    }
    _ativos = _padraoDoPeriodo();
    _aplicarPosicao();
  }

  Set<String> _padraoDoPeriodo() => _periodo.tipo == TipoPeriodo.dia
      ? {'dist', 'tempo', 'ritmo', 'cal', 'data'}
      : {'dist', 'tempo', 'dias', 'cal', 'treinos'};

  // ------------------------------------------------------------------
  // Dados
  // ------------------------------------------------------------------
  List<Treino> _treinosDoPeriodo({bool somenteFiltro = true}) {
    final l = Armazenamento.treinos().where((t) => _periodo.contem(t.data)).toList()
      ..sort((a, b) => a.data.compareTo(b.data));
    if (!somenteFiltro || _filtro == 'todos') return l;
    return l.where((t) => t.modo == _filtro).toList();
  }

  List<Treino> _selecionados() {
    final l = _treinosDoPeriodo();
    if (_periodo.tipo == TipoPeriodo.dia && _selTreino != null && _selTreino! < l.length) {
      return [l[_selTreino!]];
    }
    return l;
  }

  List<_Stat> _calcular(List<Treino> ts) {
    if (ts.isEmpty) return const [];
    final km = ts.fold<double>(0, (s, t) => s + t.km);
    final seg = ts.fold<int>(0, (s, t) => s + t.segundos);
    final cal = ts.fold<int>(0, (s, t) => s + t.calorias);
    final elev = ts.fold<double>(0, (s, t) => s + t.elevacao);
    final vmax = ts.fold<double>(0, (s, t) => math.max(s, t.velMaxKmh));
    final dias = ts.map((t) => '${t.data.year}-${t.data.month}-${t.data.day}').toSet().length;
    final todosCorrida = ts.every((t) => !t.ehBike);
    final unico = ts.length == 1;
    final modoTxt = ts.every((t) => t.ehBike)
        ? 'Ciclismo'
        : (todosCorrida ? 'Corrida' : 'Corrida e ciclismo');

    return [
      _Stat('dist', 'Distância', '${decimal(km)} km'),
      _Stat('tempo', 'Tempo', formatarTempo(seg)),
      todosCorrida
          ? _Stat('ritmo', 'Ritmo médio', '${formatarRitmo(km, seg)} /km')
          : _Stat('ritmo', 'Vel. média', '${velocidadeMedia(km, seg)} km/h'),
      _Stat('cal', 'Calorias', '$cal kcal'),
      _Stat('data', 'Data',
          unico ? '${formatarData(ts.first.data)}/${ts.first.data.year}'
                : '${formatarData(_periodo.ref)}/${_periodo.ref.year}'),
      _Stat('dias', 'Dias percorridos', '$dias de ${_periodo.dias}'),
      _Stat('treinos', 'Treinos', '${ts.length}'),
      _Stat('vmax', 'Vel. máxima', '${decimal(vmax, 1)} km/h'),
      _Stat('elev', 'Elevação', '+${elev.round()} m'),
      _Stat('modo', 'Modo', modoTxt),
    ];
  }

  // ------------------------------------------------------------------
  // Posições dos resultados
  // ------------------------------------------------------------------
  /// Calcula onde cada resultado fica (em frações da imagem) conforme a
  /// opção escolhida. "Livre" não mexe: vale o que a pessoa arrastou.
  void _aplicarPosicao() {
    if (_posicao == _Posicao.livre) return;
    final ids = [for (final id in _ordem) if (_ativos.contains(id)) id];
    final n = ids.length;
    if (n == 0) return;

    final wRel = 0.30 * _escala; // largura de cada resultado / largura da imagem
    final hRel = 0.15 * _escala * _aspecto; // altura / altura da imagem
    final porLinha = math.max(1, math.min(n, (1 / (wRel * 1.04)).floor()));
    final linhas = (n / porLinha).ceil();
    final passo = (hRel * 1.1) / math.max(0.05, 1 - hRel);
    const m = 0.03;

    double clamp01(double v) => v.clamp(0.0, 1.0);

    switch (_posicao) {
      case _Posicao.inferior:
      case _Posicao.superior:
        for (var i = 0; i < n; i++) {
          final r = i ~/ porLinha, c = i % porLinha;
          final naLinha = math.min(porLinha, n - r * porLinha);
          final fx = naLinha == 1 ? 0.5 : m + c * (1 - 2 * m) / (naLinha - 1);
          final fy = _posicao == _Posicao.superior
              ? m + r * passo
              : 1 - m - (linhas - 1 - r) * passo;
          _pos[ids[i]] = Offset(clamp01(fx), clamp01(fy));
        }
      case _Posicao.laterais:
        final esq = (n / 2).ceil();
        for (var i = 0; i < n; i++) {
          final naEsq = i < esq;
          final k = naEsq ? i : i - esq;
          final qtd = naEsq ? esq : n - esq;
          final fy = qtd == 1 ? 0.5 : 0.10 + k * (0.80 / (qtd - 1));
          _pos[ids[i]] = Offset(naEsq ? m : 1 - m, clamp01(fy));
        }
      case _Posicao.cantos:
        const ancoras = [
          Offset(m, m), Offset(1 - m, m), Offset(m, 1 - m), Offset(1 - m, 1 - m),
          Offset(0.5, m), Offset(0.5, 1 - m), Offset(m, 0.5), Offset(1 - m, 0.5),
        ];
        for (var i = 0; i < n; i++) {
          _pos[ids[i]] = ancoras[i % ancoras.length];
        }
      case _Posicao.livre:
        break;
    }
  }

  void _mudar(VoidCallback f) {
    setState(() {
      f();
      _aplicarPosicao();
      for (final id in _ordem) {
        _pos.putIfAbsent(id, () => const Offset(0.5, 0.5));
      }
    });
  }

  void _mudarPeriodo(PeriodoRel novo) {
    final tipoMudou = novo.tipo != _periodo.tipo;
    _mudar(() {
      _periodo = novo;
      _selTreino = null;
      if (tipoMudou) _ativos = _padraoDoPeriodo();
    });
  }

  Future<void> _escolherData() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _periodo.ref,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (d != null) _mudarPeriodo(_periodo.comData(d));
  }

  Future<void> _salvar() async {
    setState(() => _salvando = true);
    final ok = await compartilharRelatorio(
      chave: _chave,
      nomeBase: 'alvo-vita-corrida-${_periodo.nomeArquivo}',
      pdf: false,
      assunto: 'Corrida ${_periodo.rotulo} · Alvo Vita',
    );
    if (!mounted) return;
    setState(() => _salvando = false);
    if (!ok) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Não consegui criar a imagem. Tente de novo.')),
      );
    }
  }

  // ------------------------------------------------------------------
  // Desenho
  // ------------------------------------------------------------------
  Widget _fundoMapa(List<Treino> ts, Color corRota) {
    final rotas = [for (final t in ts) if (t.pontos.length >= 2) t.pontos];
    final todos = [for (final r in rotas) ...r.map((p) => LatLng(p.lat, p.lng))];

    if (_fundo == _Fundo.liso || todos.isEmpty) {
      return Container(
        color: Colors.black,
        child: CustomPaint(
          painter: _RotaPainter(rotas: rotas, cor: corRota, marcadores: ts.length == 1),
          size: Size.infinite,
        ),
      );
    }

    return FlutterMap(
      key: ValueKey('${ts.map((t) => t.data.toIso8601String()).join()}|$_aspecto'),
      options: MapOptions(
        initialCenter: todos.first,
        initialZoom: 15,
        initialCameraFit: CameraFit.coordinates(
          coordinates: todos,
          padding: const EdgeInsets.all(56),
          maxZoom: 17,
        ),
        interactionOptions: const InteractionOptions(flags: InteractiveFlag.none),
      ),
      children: [
        TileLayer(
          urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
          userAgentPackageName: 'com.alvovita.alvo_vita',
        ),
        PolylineLayer(
          polylines: [
            for (final r in rotas)
              Polyline(
                points: [for (final p in r) LatLng(p.lat, p.lng)],
                strokeWidth: 5,
                color: corRota,
                borderStrokeWidth: 2,
                borderColor: Colors.white,
              ),
          ],
        ),
        // trechos marcados à mão (sem sinal de GPS): linha laranja
        PolylineLayer(
          polylines: [
            for (final t in ts)
              for (final g in {for (final m in t.marcas) m.grupo})
                if (t.marcas.where((m) => m.grupo == g && !m.retorno).length >= 2)
                  Polyline(
                    points: [
                      for (final m in t.marcas)
                        if (m.grupo == g && !m.retorno) LatLng(m.lat, m.lng),
                    ],
                    strokeWidth: 5,
                    color: const Color(0xFFFF9F0A),
                    borderStrokeWidth: 2,
                    borderColor: Colors.white,
                  ),
          ],
        ),
        if (ts.length == 1 && rotas.isNotEmpty)
          MarkerLayer(markers: [
            Marker(
              point: LatLng(rotas.first.first.lat, rotas.first.first.lng),
              width: 20,
              height: 20,
              child: _bolinha(const Color(0xFF2ECC71)),
            ),
            Marker(
              point: LatLng(rotas.first.last.lat, rotas.first.last.lng),
              width: 20,
              height: 20,
              child: _bolinha(const Color(0xFFE74C3C)),
            ),
          ]),
      ],
    );
  }

  Widget _bolinha(Color c) => Container(
        decoration: BoxDecoration(
          color: c,
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white, width: 3),
        ),
      );

  Widget _resultado(_Stat s, double w, double h, Color cor) {
    final cw = 0.30 * _escala * w;
    final ch = cw * 0.5;
    final p = _pos[s.id] ?? const Offset(0.5, 0.5);
    final livreX = math.max(1.0, w - cw);
    final livreY = math.max(1.0, h - ch);

    return Positioned(
      left: p.dx * livreX,
      top: p.dy * livreY,
      width: cw,
      height: ch,
      child: Listener(
        onPointerDown: (_) => setState(() => _travarRolagem = true),
        onPointerUp: (_) => setState(() => _travarRolagem = false),
        onPointerCancel: (_) => setState(() => _travarRolagem = false),
        child: GestureDetector(
          onPanUpdate: (d) => setState(() {
            _pos[s.id] = Offset(
              (p.dx + d.delta.dx / livreX).clamp(0.0, 1.0),
              (p.dy + d.delta.dy / livreY).clamp(0.0, 1.0),
            );
            _posicao = _Posicao.livre;
          }),
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: cw * 0.06),
            decoration: BoxDecoration(
              color: _fundoNosNumeros ? Colors.black.withValues(alpha: 0.55) : Colors.transparent,
              borderRadius: BorderRadius.circular(ch * 0.22),
            ),
            alignment: Alignment.center,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Expanded(
                  flex: 6,
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(
                      s.valor,
                      style: TextStyle(
                        color: cor,
                        fontSize: ch * 0.42,
                        fontWeight: FontWeight.w900,
                        shadows: const [Shadow(blurRadius: 5, color: Colors.black87)],
                      ),
                    ),
                  ),
                ),
                Expanded(
                  flex: 3,
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(
                      s.rotulo,
                      style: TextStyle(
                        color: cor.withValues(alpha: 0.9),
                        fontSize: ch * 0.2,
                        fontWeight: FontWeight.w600,
                        shadows: const [Shadow(blurRadius: 4, color: Colors.black87)],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _tela(List<Treino> ts, List<_Stat> stats, Color corRota, Color corTexto) {
    return LayoutBuilder(builder: (context, c) {
      final w = c.maxWidth, h = c.maxHeight;
      return Stack(
        clipBehavior: Clip.hardEdge,
        children: [
          Positioned.fill(child: _fundoMapa(ts, corRota)),
          if (ts.isEmpty)
            const Center(
              child: Text('Nenhum treino neste período',
                  style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w700)),
            ),
          for (final s in stats)
            if (_ativos.contains(s.id)) _resultado(s, w, h, corTexto),
          Positioned(
            right: 6,
            bottom: 3,
            child: Text(
              _fundo == _Fundo.mapa ? '© OpenStreetMap · Alvo Vita' : 'Alvo Vita',
              style: const TextStyle(
                fontSize: 9,
                color: Colors.white70,
                shadows: [Shadow(blurRadius: 3, color: Colors.black)],
              ),
            ),
          ),
        ],
      );
    });
  }

  // ------------------------------------------------------------------
  // Controles
  // ------------------------------------------------------------------
  Widget _titulo(String t) => Padding(
        padding: const EdgeInsets.only(top: 16, bottom: 6),
        child: Text(t, style: const TextStyle(fontWeight: FontWeight.w800)),
      );

  Widget _cores(Color? atual, void Function(Color?) aoEscolher, {required Color padrao}) {
    final lista = <Color>[
      Colors.white,
      const Color(0xFF111111),
      const Color(0xFFFFD60A),
      const Color(0xFFFF453A),
      const Color(0xFF30D158),
      const Color(0xFF0A84FF),
      const Color(0xFFFF9F0A),
      context.destaque,
    ];
    final sel = atual ?? padrao;
    return Wrap(
      spacing: 10,
      runSpacing: 8,
      children: [
        for (final c in lista)
          GestureDetector(
            onTap: () => aoEscolher(c),
            child: Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: c,
                shape: BoxShape.circle,
                border: Border.all(
                  color: sel.toARGB32() == c.toARGB32()
                      ? Theme.of(context).colorScheme.primary
                      : Colors.grey,
                  width: sel.toARGB32() == c.toARGB32() ? 3 : 1,
                ),
              ),
            ),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final selecionados = _selecionados();
    final stats = _calcular(selecionados);
    final corRota = _corRota ?? context.destaque;
    final corTexto = _corTexto ?? Colors.white;
    final doDia = _periodo.tipo == TipoPeriodo.dia ? _treinosDoPeriodo() : const <Treino>[];

    return Scaffold(
      appBar: AppBar(title: const Text('Imagem da corrida')),
      body: SafeArea(
        child: ListView(
          physics: _travarRolagem ? const NeverScrollableScrollPhysics() : null,
          padding: const EdgeInsets.all(16),
          children: [
            // ---- A imagem (é isto que vai ser salva) ----
            Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 480),
                child: AspectRatio(
                  aspectRatio: _aspecto,
                  child: RepaintBoundary(
                    key: _chave,
                    child: ClipRect(child: _tela(selecionados, stats, corRota, corTexto)),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 4),
            const Text(
              'Arraste os resultados com o dedo. Espere o mapa carregar antes de salvar.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12),
            ),
            const SizedBox(height: 10),
            FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: context.destaque,
                minimumSize: const Size.fromHeight(48),
              ),
              onPressed: (_salvando || selecionados.isEmpty) ? null : _salvar,
              icon: const Icon(Icons.save_alt),
              label: Text(_salvando ? 'Gerando...' : 'Salvar imagem (PNG)'),
            ),

            // ---- Período ----
            _titulo('Período'),
            SizedBox(
              width: double.infinity,
              child: SegmentedButton<TipoPeriodo>(
                showSelectedIcon: false,
                segments: const [
                  ButtonSegment(value: TipoPeriodo.dia, label: Text('Diário')),
                  ButtonSegment(value: TipoPeriodo.semana, label: Text('Semanal')),
                  ButtonSegment(value: TipoPeriodo.mes, label: Text('Mensal')),
                ],
                selected: {_periodo.tipo},
                onSelectionChanged: (s) => _mudarPeriodo(_periodo.comTipo(s.first)),
              ),
            ),
            Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.chevron_left),
                  onPressed: () => _mudarPeriodo(_periodo.deslocar(-1)),
                ),
                Expanded(
                  child: TextButton(
                    onPressed: _escolherData,
                    child: Text(_periodo.rotulo, textAlign: TextAlign.center),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.chevron_right),
                  onPressed: () => _mudarPeriodo(_periodo.deslocar(1)),
                ),
              ],
            ),
            if (doDia.length > 1)
              Wrap(
                spacing: 8,
                children: [
                  ChoiceChip(
                    label: const Text('Todos do dia'),
                    selected: _selTreino == null,
                    onSelected: (_) => _mudar(() => _selTreino = null),
                  ),
                  for (var i = 0; i < doDia.length; i++)
                    ChoiceChip(
                      label: Text('${formatarHora(doDia[i].data)} · ${decimal(doDia[i].km)} km'),
                      selected: _selTreino == i,
                      onSelected: (_) => _mudar(() => _selTreino = i),
                    ),
                ],
              ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: SegmentedButton<String>(
                showSelectedIcon: false,
                segments: const [
                  ButtonSegment(value: 'todos', label: Text('Todos')),
                  ButtonSegment(value: 'corrida', label: Text('Corrida')),
                  ButtonSegment(value: 'bike', label: Text('Ciclismo')),
                ],
                selected: {_filtro},
                onSelectionChanged: (s) => _mudar(() {
                  _filtro = s.first;
                  _selTreino = null;
                }),
              ),
            ),

            // ---- Imagem ----
            _titulo('Formato da imagem'),
            SizedBox(
              width: double.infinity,
              child: SegmentedButton<double>(
                showSelectedIcon: false,
                segments: const [
                  ButtonSegment(value: 0.8, label: Text('4:5')),
                  ButtonSegment(value: 1.0, label: Text('Quadrada')),
                  ButtonSegment(value: 0.5625, label: Text('Story 9:16')),
                ],
                selected: {_aspecto},
                onSelectionChanged: (s) => _mudar(() => _aspecto = s.first),
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: SegmentedButton<_Fundo>(
                showSelectedIcon: false,
                segments: const [
                  ButtonSegment(value: _Fundo.mapa, label: Text('Mapa de ruas'), icon: Icon(Icons.map_outlined)),
                  ButtonSegment(value: _Fundo.liso, label: Text('Fundo preto'), icon: Icon(Icons.dark_mode_outlined)),
                ],
                selected: {_fundo},
                onSelectionChanged: (s) => setState(() => _fundo = s.first),
              ),
            ),

            // ---- Resultados ----
            _titulo('Onde ficam os resultados'),
            Wrap(
              spacing: 8,
              children: [
                for (final (p, nome) in const [
                  (_Posicao.inferior, 'Embaixo'),
                  (_Posicao.superior, 'Em cima'),
                  (_Posicao.laterais, 'Nas laterais'),
                  (_Posicao.cantos, 'Nas pontas'),
                  (_Posicao.livre, 'Livre (arrastar)'),
                ])
                  ChoiceChip(
                    label: Text(nome),
                    selected: _posicao == p,
                    onSelected: (_) => _mudar(() => _posicao = p),
                  ),
              ],
            ),
            _titulo('Tamanho: ${(_escala * 100).round()}%'),
            Slider(
              value: _escala,
              min: 0.6,
              max: 1.5,
              onChanged: (v) => _mudar(() => _escala = v),
            ),
            _titulo('Cor dos resultados'),
            _cores(_corTexto, (c) => setState(() => _corTexto = c), padrao: Colors.white),
            _titulo('Cor do percurso'),
            _cores(_corRota, (c) => setState(() => _corRota = c), padrao: context.destaque),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Fundo escuro atrás dos números'),
              value: _fundoNosNumeros,
              onChanged: (v) => setState(() => _fundoNosNumeros = v),
            ),
            _titulo('O que mostrar'),
            Wrap(
              spacing: 8,
              children: [
                for (final s in stats)
                  if (!(s.id == 'data' && _periodo.tipo != TipoPeriodo.dia) &&
                      !(s.id == 'dias' && _periodo.tipo == TipoPeriodo.dia))
                    FilterChip(
                      label: Text(s.rotulo),
                      selected: _ativos.contains(s.id),
                      onSelected: (v) => _mudar(() {
                        v ? _ativos.add(s.id) : _ativos.remove(s.id);
                      }),
                    ),
              ],
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}

/// Desenha o percurso sobre fundo preto (sem precisar de internet).
class _RotaPainter extends CustomPainter {
  final List<List<Ponto>> rotas;
  final Color cor;
  final bool marcadores;
  _RotaPainter({required this.rotas, required this.cor, required this.marcadores});

  @override
  void paint(Canvas canvas, Size size) {
    final todos = [for (final r in rotas) ...r];
    if (todos.isEmpty) return;
    final latMedia = todos.map((p) => p.lat).reduce((a, b) => a + b) / todos.length;
    final k = math.cos(latMedia * math.pi / 180);
    double x(Ponto p) => p.lng * k;
    double y(Ponto p) => -p.lat;

    var minX = x(todos.first), maxX = minX, minY = y(todos.first), maxY = minY;
    for (final p in todos) {
      minX = math.min(minX, x(p));
      maxX = math.max(maxX, x(p));
      minY = math.min(minY, y(p));
      maxY = math.max(maxY, y(p));
    }
    final margem = size.shortestSide * 0.16;
    final areaW = size.width - 2 * margem, areaH = size.height - 2 * margem;
    final dx = math.max(maxX - minX, 1e-9), dy = math.max(maxY - minY, 1e-9);
    final esc = math.min(areaW / dx, areaH / dy);
    final ox = (size.width - dx * esc) / 2, oy = (size.height - dy * esc) / 2;
    Offset pt(Ponto p) => Offset(ox + (x(p) - minX) * esc, oy + (y(p) - minY) * esc);

    final linha = Paint()
      ..color = cor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    for (final r in rotas) {
      final path = Path()..moveTo(pt(r.first).dx, pt(r.first).dy);
      for (final p in r.skip(1)) {
        final o = pt(p);
        path.lineTo(o.dx, o.dy);
      }
      canvas.drawPath(path, linha);
    }
    if (marcadores && rotas.isNotEmpty) {
      final a = pt(rotas.first.first), b = pt(rotas.first.last);
      canvas.drawCircle(a, 8, Paint()..color = const Color(0xFF2ECC71));
      canvas.drawCircle(b, 8, Paint()..color = const Color(0xFFE74C3C));
    }
  }

  @override
  bool shouldRepaint(covariant _RotaPainter old) => true;
}
