import 'package:flutter/material.dart';

import '../core/armazenamento.dart';
import '../core/formatos.dart';
import '../core/tema.dart';
import '../widgets/escolher_cor.dart';
import '../widgets/cartao_metrica.dart';

/// Tela inicial: o resumo do seu dia em um olhar só.
class HojeTela extends StatelessWidget {
  const HojeTela({super.key});

  static const metaLeituraMinutos = 30;

  @override
  Widget build(BuildContext context) {
    final estilo = Theme.of(context).textTheme;

    // Reconstrói sozinha sempre que um treino ou leitura é salvo.
    return ValueListenableBuilder<int>(
      valueListenable: Armazenamento.mudou,
      builder: (context, _, __) {
        final agora = DateTime.now();

        final treinosHoje =
            Armazenamento.treinos().where((t) => mesmoDia(t.data, agora));
        final kmHoje = treinosHoje.fold<double>(0, (s, t) => s + t.km);

        final segundosLidos = Armazenamento.leituras()
            .where((l) => mesmoDia(l.data, agora))
            .fold<int>(0, (s, l) => s + l.segundos);
        final minutosLidos = segundosLidos ~/ 60;
        final progresso = (minutosLidos / metaLeituraMinutos).clamp(0.0, 1.0);

        return ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    '${saudacao()}! 👋',
                    style: estilo.headlineMedium?.copyWith(fontWeight: FontWeight.w800),
                  ),
                ),
                IconButton(
                  tooltip: 'Cor do app',
                  icon: const Icon(Icons.palette_outlined),
                  onPressed: () => showModalBottomSheet(
                    context: context,
                    isScrollControlled: true,
                    showDragHandle: true,
                    builder: (_) => const EscolherCor(),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text('Veja como está o seu dia.', style: estilo.bodyLarge),
            const SizedBox(height: 20),

            Row(
              children: [
                Expanded(
                  child: CartaoMetrica(
                    icone: Icons.directions_run,
                    titulo: 'Corrida hoje',
                    valor: '${kmHoje.toStringAsFixed(1)} km',
                    cor: context.destaque,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: CartaoMetrica(
                    icone: Icons.menu_book,
                    titulo: 'Leitura hoje',
                    valor: '$minutosLidos min',
                    cor: context.destaque,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Meta de leitura',
                      style: estilo.titleMedium?.copyWith(fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 10),
                    LinearProgressIndicator(
                      value: progresso,
                      minHeight: 12,
                      borderRadius: BorderRadius.circular(8),
                      color: context.destaque,
                    ),
                    const SizedBox(height: 6),
                    Text(
                      minutosLidos >= metaLeituraMinutos
                          ? 'Meta batida, parabéns! 🎉'
                          : '$minutosLidos de $metaLeituraMinutos min',
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),

            Card(
              child: ListTile(
                leading: Icon(Icons.water_drop, color: context.destaque),
                title: const Text('Água hoje'),
                subtitle: Text('${Armazenamento.aguaHoje()} de 2000 ml'),
              ),
            ),
            const SizedBox(height: 12),
            Card(
              child: ListTile(
                leading: Icon(Icons.account_balance_wallet, color: context.destaque),
                title: const Text('Saldo do mês'),
                subtitle: Text(formatarReais(Armazenamento.saldoMes())),
              ),
            ),
          ],
        );
      },
    );
  }
}
