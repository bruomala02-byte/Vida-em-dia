import 'package:flutter/material.dart';

import '../core/armazenamento.dart';
import '../core/formatos.dart';
import '../core/tema.dart';
import '../widgets/aviso_historico.dart';
import '../widgets/cartao_metrica.dart';
import '../widgets/escolher_cor.dart';
import '../widgets/pedir_numero.dart';
import 'historico_tela.dart';

/// Tela inicial: o resumo do seu dia em um olhar só.
class HojeTela extends StatelessWidget {
  const HojeTela({super.key});

  void _abrirHistorico(BuildContext context) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const HistoricoTela()));
  }

  Future<void> _mudarMetaLeitura(BuildContext context) async {
    final v = await pedirNumero(
      context,
      titulo: 'Meta de leitura por dia',
      atual: Armazenamento.metaLeitura(),
      unidade: 'min',
      minimo: 5,
      maximo: 600,
    );
    if (v != null) await Armazenamento.salvarMetaLeitura(v);
  }

  Future<void> _mudarMetaAgua(BuildContext context) async {
    final v = await pedirNumero(
      context,
      titulo: 'Meta de água por dia',
      atual: Armazenamento.metaAgua(),
      unidade: 'ml',
      minimo: 500,
      maximo: 8000,
    );
    if (v != null) await Armazenamento.salvarMetaAgua(v);
  }

  @override
  Widget build(BuildContext context) {
    final estilo = Theme.of(context).textTheme;

    // Reconstrói sozinha sempre que um treino ou leitura é salvo.
    return ValueListenableBuilder<int>(
      valueListenable: Armazenamento.mudou,
      builder: (context, _, __) {
        final agora = DateTime.now();

        final treinosHoje =
            Armazenamento.treinos().where((t) => mesmoDia(t.data, agora));
        final kmHoje = treinosHoje.fold<double>(0, (s, t) => s + t.km);

        final segundosLidos = Armazenamento.leituras()
            .where((l) => mesmoDia(l.data, agora))
            .fold<int>(0, (s, l) => s + l.segundos);
        final minutosLidos = segundosLidos ~/ 60;
        final metaLeitura = Armazenamento.metaLeitura();
        final progresso = (minutosLidos / metaLeitura).clamp(0.0, 1.0);

        return ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    '${saudacao()}! 👋',
                    style: estilo.headlineMedium?.copyWith(fontWeight: FontWeight.w800),
                  ),
                ),
                IconButton(
                  tooltip: 'Histórico e check-in',
                  icon: const Icon(Icons.history),
                  onPressed: () => _abrirHistorico(context),
                ),
                IconButton(
                  tooltip: 'Cor do app',
                  icon: const Icon(Icons.palette_outlined),
                  onPressed: () => showModalBottomSheet(
                    context: context,
                    isScrollControlled: true,
                    showDragHandle: true,
                    builder: (_) => const EscolherCor(),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text('Veja como está o seu dia.', style: estilo.bodyLarge),
            const SizedBox(height: 20),

            // Aparece só quando o histórico está grande.
            if (Armazenamento.historicoGrande()) ...[
              AvisoHistorico(aoAbrir: () => _abrirHistorico(context)),
              const SizedBox(height: 12),
            ],

            Row(
              children: [
                Expanded(
                  child: CartaoMetrica(
                    icone: Icons.directions_run,
                    titulo: 'Corrida hoje',
                    valor: '${kmHoje.toStringAsFixed(1)} km',
                    cor: context.destaque,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: CartaoMetrica(
                    icone: Icons.menu_book,
                    titulo: 'Leitura hoje',
                    valor: '$minutosLidos min',
                    cor: context.destaque,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            Card(
              clipBehavior: Clip.antiAlias,
              child: InkWell(
                onTap: () => _mudarMetaLeitura(context),
                child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            'Meta de leitura',
                            style: estilo.titleMedium?.copyWith(fontWeight: FontWeight.w700),
                          ),
                        ),
                        const Icon(Icons.edit_outlined, size: 18),
                      ],
                    ),
                    const SizedBox(height: 10),
                    LinearProgressIndicator(
                      value: progresso,
                      minHeight: 12,
                      borderRadius: BorderRadius.circular(8),
                      color: context.destaque,
                    ),
                    const SizedBox(height: 6),
                    Text(
                      minutosLidos >= metaLeitura
                          ? 'Meta batida, parabéns! 🎉'
                          : '$minutosLidos de $metaLeitura min',
                    ),
                  ],
                ),
              ),
              ),
            ),
            const SizedBox(height: 12),

            Card(
              child: ListTile(
                onTap: () => _mudarMetaAgua(context),
                leading: Icon(Icons.water_drop, color: context.destaque),
                title: const Text('Água hoje'),
                subtitle: Text('${Armazenamento.aguaHoje()} de ${Armazenamento.metaAgua()} ml'),
                trailing: const Icon(Icons.edit_outlined, size: 18),
              ),
            ),
            const SizedBox(height: 12),
            Card(
              child: ListTile(
                leading: Icon(Icons.account_balance_wallet, color: context.destaque),
                title: const Text('Saldo do mês'),
                subtitle: Text(formatarReais(Armazenamento.saldoMes())),
              ),
            ),
            const SizedBox(height: 12),
            Card(
              child: ListTile(
                onTap: () => _abrirHistorico(context),
                leading: Icon(Icons.history, color: context.destaque),
                title: const Text('Histórico e check-in'),
                subtitle: const Text('Salve o resumo do mês e limpe dados antigos'),
                trailing: const Icon(Icons.chevron_right),
              ),
            ),
          ],
        );
      },
    );
  }
}
