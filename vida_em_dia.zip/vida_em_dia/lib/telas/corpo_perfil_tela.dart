import 'package:flutter/material.dart';

import '../core/armazenamento.dart';
import '../core/corpo.dart';
import '../core/formatos.dart';
import '../core/tema.dart';

/// Página "Peso e corpo": peso, altura e idade (opcional) e o que o app
/// calcula com isso: IMC, faixa de peso saudável e quantidade de água.
class CorpoPerfilTela extends StatefulWidget {
  const CorpoPerfilTela({super.key});

  @override
  State<CorpoPerfilTela> createState() => _CorpoPerfilTelaState();
}

class _CorpoPerfilTelaState extends State<CorpoPerfilTela> {
  late final TextEditingController _peso;
  late final TextEditingController _altura;
  late final TextEditingController _idade;

  @override
  void initState() {
    super.initState();
    final pesos = Armazenamento.lista('pesos');
    final a = Armazenamento.alturaM();
    final i = Armazenamento.idade();
    _peso = TextEditingController(
        text: pesos.isEmpty ? '' : decimal((pesos.first['kg'] as num).toDouble(), 1));
    _altura = TextEditingController(text: a == null ? '' : decimal(a));
    _idade = TextEditingController(text: i == null ? '' : '$i');
  }

  @override
  void dispose() {
    _peso.dispose();
    _altura.dispose();
    _idade.dispose();
    super.dispose();
  }

  void _aviso(String t) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));

  double? get _pesoDigitado =>
      double.tryParse(_peso.text.trim().replaceAll(',', '.'));

  Future<void> _salvar() async {
    final peso = _pesoDigitado;
    if (peso == null || peso < 20 || peso > 400) {
      _aviso('Digite um peso válido, por exemplo 65,5');
      return;
    }
    double? altura;
    if (_altura.text.trim().isNotEmpty) {
      altura = lerAltura(_altura.text);
      if (altura == null) {
        _aviso('Altura inválida. Digite assim: 1,79');
        return;
      }
    }
    int? idade;
    if (_idade.text.trim().isNotEmpty) {
      idade = int.tryParse(_idade.text.trim());
      if (idade == null || idade < 1 || idade > 120) {
        _aviso('Idade inválida. Pode deixar em branco, é opcional.');
        return;
      }
    }

    final pesos = Armazenamento.lista('pesos');
    final igual = pesos.isNotEmpty &&
        ((pesos.first['kg'] as num).toDouble() - peso).abs() < 0.05;
    if (!igual) {
      await Armazenamento.adicionar('pesos', {
        'data': DateTime.now().toIso8601String(),
        'kg': peso,
      });
    }
    await Armazenamento.salvarPerfil(alturaM: altura, idade: idade);
    if (!mounted) return;
    FocusScope.of(context).unfocus();
    _aviso('Salvo! ✅');
  }

  @override
  Widget build(BuildContext context) {
    final estilo = Theme.of(context).textTheme;
    final peso = _pesoDigitado;
    final alturaDigitada = lerAltura(_altura.text);
    final analise = (peso != null && peso >= 20) ? analisarCorpo(peso, alturaDigitada) : null;
    final idade = int.tryParse(_idade.text.trim());

    return Scaffold(
      appBar: AppBar(title: const Text('Peso e corpo')),
      body: SafeArea(
        child: ValueListenableBuilder<int>(
          valueListenable: Armazenamento.mudou,
          builder: (context, _, __) {
            final pesos = Armazenamento.lista('pesos');

            return ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _peso,
                        onChanged: (_) => setState(() {}),
                        keyboardType: const TextInputType.numberWithOptions(decimal: true),
                        decoration: const InputDecoration(labelText: 'Peso', suffixText: 'kg'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: TextField(
                        controller: _altura,
                        onChanged: (_) => setState(() {}),
                        keyboardType: const TextInputType.numberWithOptions(decimal: true),
                        decoration: const InputDecoration(labelText: 'Altura', suffixText: 'm'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _idade,
                  onChanged: (_) => setState(() {}),
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Idade (opcional)',
                    suffixText: 'anos',
                  ),
                ),
                const SizedBox(height: 10),
                FilledButton(
                  style: FilledButton.styleFrom(
                    backgroundColor: context.destaque,
                    minimumSize: const Size.fromHeight(46),
                  ),
                  onPressed: _salvar,
                  child: const Text('Salvar'),
                ),
                const SizedBox(height: 14),

                if (analise != null)
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Seu resultado',
                              style: estilo.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              Text(decimal(analise.imc, 1),
                                  style: TextStyle(
                                      fontSize: 34,
                                      fontWeight: FontWeight.w900,
                                      color: context.destaque)),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text('IMC · ${analise.faixa}',
                                    style: const TextStyle(fontWeight: FontWeight.w700)),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text('Faixa de peso saudável para ${decimal(alturaDigitada!)} m: '
                              '${decimal(analise.pesoMin, 1)} a ${decimal(analise.pesoMax, 1)} kg.'),
                          const SizedBox(height: 4),
                          Text(_diferenca(peso!, analise)),
                          const SizedBox(height: 8),
                          Text('💧 Água sugerida: ${analise.aguaMl} ml por dia '
                              '(35 ml por kg).'),
                          if (idade != null && (idade < 18 || idade >= 65)) ...[
                            const SizedBox(height: 8),
                            Text(
                              'Para a sua idade o IMC tem outras referências. '
                              'Converse com um profissional de saúde.',
                              style: estilo.bodySmall,
                            ),
                          ],
                          const SizedBox(height: 8),
                          Text(
                            'São estimativas gerais e não substituem a avaliação de '
                            'um médico ou nutricionista.',
                            style: estilo.bodySmall,
                          ),
                        ],
                      ),
                    ),
                  )
                else
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(14),
                      child: Text('Informe peso e altura para ver o IMC, a faixa de peso '
                          'saudável e a água sugerida para você.'),
                    ),
                  ),

                const SizedBox(height: 14),
                Text('Histórico de peso',
                    style: estilo.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                if (pesos.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 10),
                    child: Text('Nenhum peso registrado ainda.'),
                  ),
                for (var i = 0; i < pesos.length && i < 10; i++)
                  ListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.monitor_weight_outlined),
                    title: Text('${decimal((pesos[i]['kg'] as num).toDouble(), 1)} kg'),
                    subtitle: Text(formatarData(DateTime.parse(pesos[i]['data'] as String))),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline, size: 20),
                      onPressed: () => Armazenamento.remover('pesos', i),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }

  String _diferenca(double peso, AnaliseCorpo a) {
    if (peso < a.pesoMin) {
      return 'Faltam ${decimal(a.pesoMin - peso, 1)} kg para chegar ao início da faixa.';
    }
    if (peso > a.pesoMax) {
      return 'Para chegar ao fim da faixa: ${decimal(peso - a.pesoMax, 1)} kg a menos.';
    }
    return 'Você está dentro da faixa saudável. 👏';
  }
}
