import 'package:flutter/material.dart';

import '../core/armazenamento.dart';
import '../core/formatos.dart';
import '../core/periodo.dart';
import '../core/tema.dart';
import '../relatorios/folhas.dart';
import 'relatorio_tela.dart';

const _catSaida = ['Mercado', 'Transporte', 'Lazer', 'Contas', 'Saúde', 'Outros'];
const _catEntrada = ['Salário', 'Extra', 'Outros'];

enum _Periodo { dia, semana, mes }

/// Uma linha da tabela (nome + valor).
class _Linha {
  final String nome;
  final double valor;
  const _Linha(this.nome, this.valor);
}

/// Salário base, tabela de entradas e saídas (dia, semana ou mês) e resumo total.
class FinancasTela extends StatefulWidget {
  const FinancasTela({super.key});

  @override
  State<FinancasTela> createState() => _FinancasTelaState();
}

class _FinancasTelaState extends State<FinancasTela> {
  _Periodo _periodo = _Periodo.mes;

  void _novo() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => const _NovoLancamento(),
    );
  }

  Future<void> _editarSalario() async {
    final atual = Armazenamento.salarioBase();
    final c = TextEditingController(
        text: atual > 0 ? decimal(atual).replaceAll('.', '') : '');
    String? erro;
    final resultado = await showDialog<double>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) {
          void salvar() {
            final v = double.tryParse(c.text.trim().replaceAll('.', '').replaceAll(',', '.'));
            if (v == null || v < 0) {
              setLocal(() => erro = 'Digite um valor válido, ex.: 1800,00');
              return;
            }
            Navigator.pop(ctx, v);
          }

          return AlertDialog(
            title: const Text('Salário base'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Fica salvo e só muda se você quiser. Bicos e outras '
                    'entradas você lança em "Novo lançamento".'),
                const SizedBox(height: 12),
                TextField(
                  controller: c,
                  autofocus: true,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: InputDecoration(prefixText: 'R\$ ', errorText: erro),
                  onSubmitted: (_) => salvar(),
                ),
              ],
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
              if (atual > 0)
                TextButton(onPressed: () => Navigator.pop(ctx, 0), child: const Text('Remover')),
              TextButton(onPressed: salvar, child: const Text('Salvar')),
            ],
          );
        },
      ),
    );
    if (resultado != null) await Armazenamento.salvarSalarioBase(resultado);
  }

  /// Início (inclusive) e fim (exclusive) do período escolhido.
  (DateTime, DateTime) _intervalo(DateTime agora) {
    switch (_periodo) {
      case _Periodo.dia:
        return (DateTime(agora.year, agora.month, agora.day),
            DateTime(agora.year, agora.month, agora.day + 1));
      case _Periodo.semana:
        final seg = DateTime(agora.year, agora.month, agora.day - (agora.weekday - 1));
        return (seg, DateTime(seg.year, seg.month, seg.day + 7));
      case _Periodo.mes:
        return (DateTime(agora.year, agora.month, 1),
            DateTime(agora.year, agora.month + 1, 1));
    }
  }

  String _rotuloPeriodo(DateTime agora, DateTime ini, DateTime fim) {
    switch (_periodo) {
      case _Periodo.dia:
        return 'Hoje, ${formatarData(agora)}';
      case _Periodo.semana:
        final ultimo = DateTime(fim.year, fim.month, fim.day - 1);
        return 'Semana de ${formatarData(ini)} a ${formatarData(ultimo)}';
      case _Periodo.mes:
        return '${nomesMeses[agora.month - 1]} de ${agora.year}';
    }
  }

  @override
  Widget build(BuildContext context) {
    final estilo = Theme.of(context).textTheme;

    return ValueListenableBuilder<int>(
      valueListenable: Armazenamento.mudou,
      builder: (context, _, __) {
        final agora = DateTime.now();
        final (ini, fim) = _intervalo(agora);
        final todos = Armazenamento.lista('lancamentos');

        final doPeriodo = <int>[]; // posições na lista completa
        final entradas = <_Linha>[];
        final saidas = <_Linha>[];
        final porCat = <String, double>{};

        // Salário base: no mês inteiro; na semana e no dia, a parte proporcional.
        final base = Armazenamento.salarioBase();
        if (base > 0) {
          final diasMes = DateTime(agora.year, agora.month + 1, 0).day;
          switch (_periodo) {
            case _Periodo.mes:
              entradas.add(_Linha('Salário base', base));
            case _Periodo.semana:
              entradas.add(_Linha('Salário (proporc.)', base * 7 / diasMes));
            case _Periodo.dia:
              entradas.add(_Linha('Salário (proporc.)', base / diasMes));
          }
        }

        for (var i = 0; i < todos.length; i++) {
          final e = todos[i];
          final d = DateTime.parse(e['data'] as String);
          if (d.isBefore(ini) || !d.isBefore(fim)) continue;
          doPeriodo.add(i);
          final v = (e['valor'] as num).toDouble();
          final desc = (e['desc'] as String?) ?? '';
          final nome = desc.isEmpty ? (e['cat'] as String) : desc;
          if (e['tipo'] == 'e') {
            entradas.add(_Linha(nome, v));
          } else {
            saidas.add(_Linha(nome, v));
            porCat[e['cat'] as String] = (porCat[e['cat'] as String] ?? 0) + v;
          }
        }

        final totE = entradas.fold<double>(0, (s, l) => s + l.valor);
        final totS = saidas.fold<double>(0, (s, l) => s + l.valor);
        final saldo = totE - totS;
        final cats = porCat.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
        final cores = Theme.of(context).colorScheme;

        return ListView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 20),
          children: [
            Text('Finanças',
                style: estilo.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
            Text(_rotuloPeriodo(agora, ini, fim), style: estilo.bodySmall),
            const SizedBox(height: 10),

            // ---- Barra do salário ----
            Card(
              clipBehavior: Clip.antiAlias,
              child: InkWell(
                onTap: _editarSalario,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  child: Row(
                    children: [
                      Icon(Icons.payments_outlined, color: context.destaque, size: 22),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Salário', style: estilo.labelMedium),
                            Text(
                              base > 0 ? formatarReais(base) : 'Toque para definir seu salário base',
                              style: TextStyle(
                                fontSize: base > 0 ? 20 : 14,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Icon(Icons.edit_outlined, size: 18),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 10),

            // ---- Dia / Semana / Mês ----
            SizedBox(
              width: double.infinity,
              child: SegmentedButton<_Periodo>(
                showSelectedIcon: false,
                segments: const [
                  ButtonSegment(value: _Periodo.dia, label: Text('Dia')),
                  ButtonSegment(value: _Periodo.semana, label: Text('Semana')),
                  ButtonSegment(value: _Periodo.mes, label: Text('Mês')),
                ],
                selected: {_periodo},
                onSelectionChanged: (s) => setState(() => _periodo = s.first),
              ),
            ),
            const SizedBox(height: 10),

            // ---- Tabela: entradas de um lado, saídas do outro ----
            Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                children: [
                  Container(
                    color: context.destaque.withValues(alpha: 0.15),
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: const Row(
                      children: [
                        Expanded(
                          child: Center(
                            child: Text('⬆ Entradas',
                                style: TextStyle(fontWeight: FontWeight.w800)),
                          ),
                        ),
                        Expanded(
                          child: Center(
                            child: Text('⬇ Saídas',
                                style: TextStyle(fontWeight: FontWeight.w800)),
                          ),
                        ),
                      ],
                    ),
                  ),
                  IntrinsicHeight(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Expanded(child: _coluna(entradas)),
                        VerticalDivider(width: 1, color: cores.outlineVariant),
                        Expanded(child: _coluna(saidas)),
                      ],
                    ),
                  ),
                  Divider(height: 1, color: cores.outlineVariant),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    child: Row(
                      children: [
                        Expanded(child: _total('Total entradas', totE, Cores.saude)),
                        Expanded(child: _total('Total saídas', totS, Cores.saida)),
                      ],
                    ),
                  ),
                  Container(
                    color: cores.surfaceContainerHighest,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Saldo do período',
                            style: TextStyle(fontWeight: FontWeight.w700)),
                        Text(
                          formatarReais(saldo),
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            color: saldo >= 0 ? Cores.saude : cores.error,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: context.destaque,
                minimumSize: const Size.fromHeight(46),
              ),
              onPressed: _novo,
              icon: const Icon(Icons.add),
              label: const Text('Novo lançamento'),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(46)),
              onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                builder: (_) => RelatorioTela(
                  tipo: TipoRelatorio.financas,
                  tipos: const [TipoRelatorio.financas],
                  periodo: switch (_periodo) {
                    _Periodo.dia => TipoPeriodo.dia,
                    _Periodo.semana => TipoPeriodo.semana,
                    _Periodo.mes => TipoPeriodo.mes,
                  },
                ),
              )),
              icon: const Icon(Icons.picture_as_pdf_outlined),
              label: const Text('Baixar extrato (PDF ou PNG)'),
            ),

            if (cats.isNotEmpty) ...[
              const SizedBox(height: 18),
              Text('Gastos por categoria',
                  style: estilo.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              for (final c in cats)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [Text(c.key), Text(formatarReais(c.value))],
                      ),
                      const SizedBox(height: 3),
                      LinearProgressIndicator(
                        value: totS > 0 ? c.value / totS : 0,
                        minHeight: 8,
                        borderRadius: BorderRadius.circular(8),
                        color: context.destaque,
                      ),
                    ],
                  ),
                ),
            ],

            const SizedBox(height: 14),
            Text('Lançamentos',
                style: estilo.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            if (doPeriodo.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text('Nenhum lançamento neste período ainda. 💰'),
              ),
            for (final i in doPeriodo)
              Builder(builder: (context) {
                final e = todos[i];
                final entrada = e['tipo'] == 'e';
                final desc = (e['desc'] as String?) ?? '';
                return ListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  leading: CircleAvatar(
                    radius: 16,
                    backgroundColor:
                        (entrada ? Cores.saude : Cores.saida).withValues(alpha: 0.15),
                    child: Icon(entrada ? Icons.arrow_upward : Icons.arrow_downward,
                        size: 16, color: entrada ? Cores.saude : Cores.saida),
                  ),
                  title: Text(desc.isEmpty ? e['cat'] as String : desc),
                  subtitle: Text(
                      '${e['cat']} · ${formatarData(DateTime.parse(e['data'] as String))}'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        '${entrada ? '+' : '-'}${formatarReais((e['valor'] as num).toDouble())}',
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      IconButton(
                        visualDensity: VisualDensity.compact,
                        icon: const Icon(Icons.delete_outline, size: 20),
                        onPressed: () => Armazenamento.remover('lancamentos', i),
                      ),
                    ],
                  ),
                );
              }),
          ],
        );
      },
    );
  }

  /// Uma coluna da tabela (lista de nome + valor).
  Widget _coluna(List<_Linha> linhas) {
    if (linhas.isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(12),
        child: Center(child: Text('—')),
      );
    }
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      child: Column(
        children: [
          for (final l in linhas)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Text(l.nome,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 13)),
                  ),
                  const SizedBox(width: 6),
                  Text(formatarReais(l.valor),
                      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _total(String rotulo, double valor, Color cor) => Column(
        children: [
          Text(rotulo, style: const TextStyle(fontSize: 12)),
          Text(formatarReais(valor),
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: cor)),
        ],
      );
}

class _NovoLancamento extends StatefulWidget {
  const _NovoLancamento();

  @override
  State<_NovoLancamento> createState() => _NovoLancamentoState();
}

class _NovoLancamentoState extends State<_NovoLancamento> {
  bool _saida = true;
  String _cat = _catSaida.first;
  final _valor = TextEditingController();
  final _desc = TextEditingController();

  @override
  void dispose() {
    _valor.dispose();
    _desc.dispose();
    super.dispose();
  }

  Future<void> _salvar() async {
    final v = double.tryParse(_valor.text.trim().replaceAll(',', '.'));
    if (v == null || v <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Digite um valor válido, ex.: 25,90')),
      );
      return;
    }
    await Armazenamento.adicionar('lancamentos', {
      'data': DateTime.now().toIso8601String(),
      'valor': v,
      'tipo': _saida ? 's' : 'e',
      'cat': _cat,
      'desc': _desc.text.trim(),
    });
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final cats = _saida ? _catSaida : _catEntrada;
    return Padding(
      padding: EdgeInsets.fromLTRB(
          20, 0, 20, MediaQuery.of(context).viewInsets.bottom + 20),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: true, label: Text('Saída'), icon: Icon(Icons.arrow_downward)),
                ButtonSegment(value: false, label: Text('Entrada'), icon: Icon(Icons.arrow_upward)),
              ],
              selected: {_saida},
              onSelectionChanged: (s) => setState(() {
                _saida = s.first;
                _cat = (_saida ? _catSaida : _catEntrada).first;
              }),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _valor,
              autofocus: true,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(labelText: 'Valor', prefixText: 'R\$ '),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              children: [
                for (final c in cats)
                  ChoiceChip(
                    label: Text(c),
                    selected: _cat == c,
                    onSelected: (_) => setState(() => _cat = c),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _desc,
              decoration: const InputDecoration(labelText: 'Descrição (opcional)'),
            ),
            const SizedBox(height: 16),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: context.destaque),
              onPressed: _salvar,
              child: const Text('Salvar'),
            ),
          ],
        ),
      ),
    );
  }
}
