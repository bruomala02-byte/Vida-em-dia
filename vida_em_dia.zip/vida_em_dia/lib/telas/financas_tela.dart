import 'package:flutter/material.dart';

import '../core/armazenamento.dart';
import '../core/formatos.dart';
import '../core/tema.dart';

const _catSaida = ['Mercado', 'Transporte', 'Lazer', 'Contas', 'Saúde', 'Outros'];
const _catEntrada = ['Salário', 'Extra', 'Outros'];
const _meses = [
  'janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho',
  'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro',
];

/// Entradas e saídas, resumo do mês e gastos por categoria.
class FinancasTela extends StatelessWidget {
  const FinancasTela({super.key});

  void _novo(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => const _NovoLancamento(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final estilo = Theme.of(context).textTheme;

    return ValueListenableBuilder<int>(
      valueListenable: Armazenamento.mudou,
      builder: (context, _, __) {
        final agora = DateTime.now();
        final todos = Armazenamento.lista('lancamentos');
        final doMes = <int>[]; // posições na lista completa
        var entradas = 0.0, saidas = 0.0;
        final porCat = <String, double>{};

        for (var i = 0; i < todos.length; i++) {
          final e = todos[i];
          final d = DateTime.parse(e['data'] as String);
          if (d.year != agora.year || d.month != agora.month) continue;
          doMes.add(i);
          final v = (e['valor'] as num).toDouble();
          if (e['tipo'] == 'e') {
            entradas += v;
          } else {
            saidas += v;
            porCat[e['cat'] as String] = (porCat[e['cat'] as String] ?? 0) + v;
          }
        }
        final saldo = entradas - saidas;
        final cats = porCat.entries.toList()..sort((a, b) => b.value.compareTo(a.value));

        return ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Text('Finanças',
                style: estilo.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
            Text('${_meses[agora.month - 1]} de ${agora.year}'),
            const SizedBox(height: 16),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Saldo do mês'),
                    Text(
                      formatarReais(saldo),
                      style: TextStyle(
                        fontSize: 34,
                        fontWeight: FontWeight.w900,
                        color: saldo >= 0 ? Cores.saude : Theme.of(context).colorScheme.error,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('⬆ ${formatarReais(entradas)}'),
                        Text('⬇ ${formatarReais(saidas)}'),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: context.destaque),
              onPressed: () => _novo(context),
              icon: const Icon(Icons.add),
              label: const Text('Novo lançamento'),
            ),
            if (cats.isNotEmpty) ...[
              const SizedBox(height: 24),
              Text('Gastos por categoria',
                  style: estilo.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
              const SizedBox(height: 10),
              for (final c in cats)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [Text(c.key), Text(formatarReais(c.value))],
                      ),
                      const SizedBox(height: 4),
                      LinearProgressIndicator(
                        value: saidas > 0 ? c.value / saidas : 0,
                        minHeight: 10,
                        borderRadius: BorderRadius.circular(8),
                        color: context.destaque,
                      ),
                    ],
                  ),
                ),
            ],
            const SizedBox(height: 16),
            Text('Lançamentos',
                style: estilo.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            if (doMes.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 16),
                child: Text('Nenhum lançamento neste mês ainda. 💰'),
              ),
            for (final i in doMes)
              Builder(builder: (context) {
                final e = todos[i];
                final entrada = e['tipo'] == 'e';
                final desc = (e['desc'] as String?) ?? '';
                return ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: CircleAvatar(
                    backgroundColor:
                        (entrada ? Cores.saude : Cores.saida).withValues(alpha: 0.15),
                    child: Icon(entrada ? Icons.arrow_upward : Icons.arrow_downward,
                        color: entrada ? Cores.saude : Cores.saida),
                  ),
                  title: Text(desc.isEmpty ? e['cat'] as String : desc),
                  subtitle: Text(
                      '${e['cat']} · ${formatarData(DateTime.parse(e['data'] as String))}'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        '${entrada ? '+' : '-'}${formatarReais((e['valor'] as num).toDouble())}',
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () => Armazenamento.remover('lancamentos', i),
                      ),
                    ],
                  ),
                );
              }),
          ],
        );
      },
    );
  }
}

class _NovoLancamento extends StatefulWidget {
  const _NovoLancamento();

  @override
  State<_NovoLancamento> createState() => _NovoLancamentoState();
}

class _NovoLancamentoState extends State<_NovoLancamento> {
  bool _saida = true;
  String _cat = _catSaida.first;
  final _valor = TextEditingController();
  final _desc = TextEditingController();

  @override
  void dispose() {
    _valor.dispose();
    _desc.dispose();
    super.dispose();
  }

  Future<void> _salvar() async {
    final v = double.tryParse(_valor.text.trim().replaceAll(',', '.'));
    if (v == null || v <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Digite um valor válido, ex.: 25,90')),
      );
      return;
    }
    await Armazenamento.adicionar('lancamentos', {
      'data': DateTime.now().toIso8601String(),
      'valor': v,
      'tipo': _saida ? 's' : 'e',
      'cat': _cat,
      'desc': _desc.text.trim(),
    });
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final cats = _saida ? _catSaida : _catEntrada;
    return Padding(
      padding: EdgeInsets.fromLTRB(
          20, 0, 20, MediaQuery.of(context).viewInsets.bottom + 20),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: true, label: Text('Saída'), icon: Icon(Icons.arrow_downward)),
                ButtonSegment(value: false, label: Text('Entrada'), icon: Icon(Icons.arrow_upward)),
              ],
              selected: {_saida},
              onSelectionChanged: (s) => setState(() {
                _saida = s.first;
                _cat = (_saida ? _catSaida : _catEntrada).first;
              }),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _valor,
              autofocus: true,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(labelText: 'Valor', prefixText: 'R\$ '),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              children: [
                for (final c in cats)
                  ChoiceChip(
                    label: Text(c),
                    selected: _cat == c,
                    onSelected: (_) => setState(() => _cat = c),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _desc,
              decoration: const InputDecoration(labelText: 'Descrição (opcional)'),
            ),
            const SizedBox(height: 16),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: context.destaque),
              onPressed: _salvar,
              child: const Text('Salvar'),
            ),
          ],
        ),
      ),
    );
  }
}
