import 'package:flutter/material.dart';

import '../core/exportar.dart';
import '../core/periodo.dart';
import '../core/tema.dart';
import '../relatorios/folhas.dart';

/// Tela "Salvar relatório": escolhe o tipo, o período (diário, semanal ou
/// mensal), o formato (PDF ou PNG), confere a prévia e salva.
class RelatorioTela extends StatefulWidget {
  final TipoRelatorio tipo;
  final TipoPeriodo periodo;
  /// Tipos que a pessoa pode alternar nesta tela (por padrão, todos).
  final List<TipoRelatorio> tipos;
  const RelatorioTela({
    super.key,
    this.tipo = TipoRelatorio.financas,
    this.periodo = TipoPeriodo.mes,
    this.tipos = TipoRelatorio.values,
  });

  @override
  State<RelatorioTela> createState() => _RelatorioTelaState();
}

class _RelatorioTelaState extends State<RelatorioTela> {
  final _chave = GlobalKey();
  late TipoRelatorio _tipo = widget.tipo;
  late PeriodoRel _periodo = PeriodoRel.hoje(widget.periodo);
  bool _pdf = false;
  double _zoom = 1.0;
  bool _salvando = false;

  Future<void> _escolherData() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _periodo.ref,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (d != null) setState(() => _periodo = _periodo.comData(d));
  }

  Future<void> _salvar() async {
    setState(() => _salvando = true);
    final nome = 'alvo-vita-${_tipo.arquivo}-${_periodo.nomeArquivo}';
    final ok = await compartilharRelatorio(
      chave: _chave,
      nomeBase: nome,
      pdf: _pdf,
      assunto: '${_tipo.tituloFolha} ${_periodo.rotulo} · Alvo Vita',
    );
    if (!mounted) return;
    setState(() => _salvando = false);
    if (!ok) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Não consegui criar o arquivo. Tente de novo.')),
      );
    }
  }

  String _nomeCurto(TipoRelatorio t) => switch (t) {
        TipoRelatorio.financas => 'Finanças',
        TipoRelatorio.geral => 'Resumo geral',
        TipoRelatorio.corrida => 'Corrida',
        TipoRelatorio.saude => 'Saúde',
        TipoRelatorio.estudos => 'Estudos - Leitura',
      };

  @override
  Widget build(BuildContext context) {
    final largura = (MediaQuery.of(context).size.width - 32).clamp(300.0, 420.0);

    return Scaffold(
      appBar: AppBar(title: const Text('Salvar relatório')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            if (widget.tipos.length > 1)
              Wrap(
                spacing: 8,
                children: [
                  for (final t in widget.tipos)
                    ChoiceChip(
                      label: Text(_nomeCurto(t)),
                      selected: _tipo == t,
                      onSelected: (_) => setState(() => _tipo = t),
                    ),
                ],
              ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: SegmentedButton<TipoPeriodo>(
                showSelectedIcon: false,
                segments: const [
                  ButtonSegment(value: TipoPeriodo.dia, label: Text('Diário')),
                  ButtonSegment(value: TipoPeriodo.semana, label: Text('Semanal')),
                  ButtonSegment(value: TipoPeriodo.mes, label: Text('Mensal')),
                ],
                selected: {_periodo.tipo},
                onSelectionChanged: (s) =>
                    setState(() => _periodo = _periodo.comTipo(s.first)),
              ),
            ),
            const SizedBox(height: 4),
            Row(
              children: [
                IconButton(
                  tooltip: 'Anterior',
                  icon: const Icon(Icons.chevron_left),
                  onPressed: () => setState(() => _periodo = _periodo.deslocar(-1)),
                ),
                Expanded(
                  child: TextButton(
                    onPressed: _escolherData,
                    child: Text(_periodo.rotulo, textAlign: TextAlign.center),
                  ),
                ),
                IconButton(
                  tooltip: 'Próximo',
                  icon: const Icon(Icons.chevron_right),
                  onPressed: () => setState(() => _periodo = _periodo.deslocar(1)),
                ),
              ],
            ),
            SizedBox(
              width: double.infinity,
              child: SegmentedButton<bool>(
                showSelectedIcon: false,
                segments: const [
                  ButtonSegment(value: false, label: Text('Imagem PNG'), icon: Icon(Icons.image_outlined)),
                  ButtonSegment(value: true, label: Text('PDF'), icon: Icon(Icons.picture_as_pdf_outlined)),
                ],
                selected: {_pdf},
                onSelectionChanged: (s) => setState(() => _pdf = s.first),
              ),
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: context.destaque,
                minimumSize: const Size.fromHeight(48),
              ),
              onPressed: _salvando ? null : _salvar,
              icon: const Icon(Icons.save_alt),
              label: Text(_salvando ? 'Gerando...' : 'Salvar ${_pdf ? 'PDF' : 'PNG'}'),
            ),
            const SizedBox(height: 4),
            const Text(
              'Na janela que abrir, escolha onde guardar (Arquivos, Drive, WhatsApp...).',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12),
            ),
            const SizedBox(height: 8),
            Row(children: [
              const Icon(Icons.zoom_out_map),
              const SizedBox(width: 8),
              Text('Zoom: ${(_zoom * 100).round()}%'),
              Expanded(
                child: Slider(
                  value: _zoom,
                  min: 0.7,
                  max: 1.6,
                  onChanged: (v) => setState(() => _zoom = v),
                ),
              ),
            ]),
            const Text(
              'O zoom muda o tamanho das letras e das tabelas no arquivo salvo.',
              style: TextStyle(fontSize: 12),
            ),
            const SizedBox(height: 12),
            Center(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey.shade600),
                ),
                child: RepaintBoundary(
                  key: _chave,
                  child: FolhaRelatorio(
                    tipo: _tipo,
                    periodo: _periodo,
                    cor: context.destaque,
                    largura: largura,
                    zoom: _zoom,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
