import 'package:flutter/material.dart';

import '../core/config.dart';
import '../core/tema.dart';
import '../widgets/zoom_tela.dart';
import 'corrida_tela.dart';
import 'financas_tela.dart';
import 'hoje_tela.dart';
import 'saude_tela.dart';

/// Barra de navegação de baixo, com as 4 áreas do app.
/// IndexedStack mantém cada tela "viva": se você sair da Corrida
/// no meio de um treino e voltar, o cronômetro continua lá.
class Navegacao extends StatefulWidget {
  const Navegacao({super.key});

  @override
  State<Navegacao> createState() => _NavegacaoState();
}

class _NavegacaoState extends State<Navegacao> {
  int _aba = 0;

  static const _telas = <Widget>[
    ZoomTela(tela: 'hoje', child: HojeTela()),
    ZoomTela(tela: 'corrida', child: CorridaTela()),
    ZoomTela(tela: 'saude', child: SaudeTela()),
    ZoomTela(tela: 'financas', child: FinancasTela()),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: _aba, children: _telas)),
      bottomNavigationBar: _comTamanho(NavigationBar(
        selectedIndex: _aba,
        onDestinationSelected: (i) => setState(() => _aba = i),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'Hoje',
          ),
          NavigationDestination(
            icon: Icon(Icons.directions_run_outlined),
            selectedIcon: Icon(Icons.directions_run),
            label: 'Corrida',
          ),
          NavigationDestination(
            icon: Icon(Icons.favorite_outline),
            selectedIcon: Icon(Icons.favorite),
            label: 'Saúde',
          ),
          NavigationDestination(
            icon: Icon(Icons.account_balance_wallet_outlined),
            selectedIcon: Icon(Icons.account_balance_wallet),
            label: 'Finanças',
          ),
        ],
      )),
    );
  }

  /// Tamanho da barra de baixo, regulável em Configurações.
  Widget _comTamanho(Widget barra) {
    return ValueListenableBuilder<int>(
      valueListenable: Config.barra,
      builder: (context, p, _) {
        final f = p / 100;
        final tema = Theme.of(context);
        return Theme(
          data: tema.copyWith(
            navigationBarTheme: tema.navigationBarTheme.copyWith(
              height: 80 * f,
              iconTheme: WidgetStatePropertyAll(
                IconThemeData(size: 24 * f, color: tema.colorScheme.primary),
              ),
            ),
          ),
          child: barra,
        );
      },
    );
  }
}
