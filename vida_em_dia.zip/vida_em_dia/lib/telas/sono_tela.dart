import 'package:flutter/material.dart';

import '../core/armazenamento.dart';
import '../core/formatos.dart';
import '../core/tema.dart';
import '../servicos/alarme_servico.dart';

/// Página do sono: horários de dormir e acordar, despertador no celular,
/// registro de cada noite (com observação) e histórico editável.
class SonoTela extends StatefulWidget {
  const SonoTela({super.key});

  @override
  State<SonoTela> createState() => _SonoTelaState();
}

class _SonoTelaState extends State<SonoTela> {
  // Horários planejados (ficam salvos) — em minutos desde a meia-noite.
  late int _planoDormir = Armazenamento.lerInt('sono_dormir') ?? 23 * 60;
  late int _planoAcordar = Armazenamento.lerInt('sono_acordar') ?? 7 * 60;

  // Formulário de registro da noite.
  late int _dormiu = _planoDormir;
  late int _acordou = _planoAcordar;
  final _obs = TextEditingController();
  int? _editando; // posição na lista, quando está editando uma noite

  @override
  void dispose() {
    _obs.dispose();
    super.dispose();
  }

  void _aviso(String t) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));

  Future<int?> _escolherHora(int atual) async {
    final t = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: atual ~/ 60, minute: atual % 60),
      builder: (ctx, child) => MediaQuery(
        data: MediaQuery.of(ctx).copyWith(alwaysUse24HourFormat: true),
        child: child!,
      ),
    );
    return t == null ? null : t.hour * 60 + t.minute;
  }

  int get _agoraMin => DateTime.now().hour * 60 + DateTime.now().minute;

  // ---------- Despertador ----------
  bool get _alarmeLigado => Armazenamento.lerBool('sono_alarme') ?? false;

  Future<bool> _criarAlarmes() async {
    final ok1 = await AlarmeServico.criar(
      hora: _planoAcordar ~/ 60,
      minuto: _planoAcordar % 60,
      rotulo: 'Alvo Vita · Acordar',
    );
    final ok2 = await AlarmeServico.criar(
      hora: _planoDormir ~/ 60,
      minuto: _planoDormir % 60,
      rotulo: 'Alvo Vita · Hora de dormir',
    );
    return ok1 && ok2;
  }

  Future<void> _ligarAlarme(bool ligar) async {
    if (!ligar) {
      await Armazenamento.salvarBool('sono_alarme', false);
      if (mounted) {
        _aviso('Para apagar os alarmes, abra o app Relógio do celular e '
            'remova "Alvo Vita".');
      }
      return;
    }
    final ok = await _criarAlarmes();
    if (!mounted) return;
    if (ok) {
      await Armazenamento.salvarBool('sono_alarme', true);
      if (!mounted) return;
      _aviso('Despertador e lembrete de dormir criados no Relógio do celular ⏰');
    } else {
      _aviso('Não consegui criar o alarme. Crie direto no app Relógio.');
    }
  }

  Future<void> _mudarPlano({required bool dormir}) async {
    final nova = await _escolherHora(dormir ? _planoDormir : _planoAcordar);
    if (nova == null) return;
    setState(() => dormir ? _planoDormir = nova : _planoAcordar = nova);
    await Armazenamento.salvarInt(dormir ? 'sono_dormir' : 'sono_acordar', nova);
    if (_alarmeLigado) {
      final ok = await _criarAlarmes();
      if (!mounted) return;
      _aviso(ok
          ? 'Alarme novo criado. Se existir um alarme antigo do Alvo Vita no '
              'Relógio, apague-o por lá.'
          : 'Não consegui atualizar o alarme. Ajuste direto no app Relógio.');
    }
  }

  // ---------- Registro da noite ----------
  Future<void> _salvarNoite() async {
    final minutos = minutosDeSono(_dormiu, _acordou);
    if (minutos == 0) {
      _aviso('Dormiu e acordou no mesmo horário? Confira os horários.');
      return;
    }
    final lista = Armazenamento.lista('sono');
    final antiga = _editando != null && _editando! < lista.length ? lista[_editando!] : null;
    final item = {
      'data': (antiga?['data'] as String?) ?? DateTime.now().toIso8601String(),
      'h': minutos / 60.0,
      'min': minutos,
      'dormiu': horaDeMinutos(_dormiu),
      'acordou': horaDeMinutos(_acordou),
      'obs': _obs.text.trim(),
    };
    if (antiga != null) {
      await Armazenamento.substituir('sono', _editando!, item);
    } else {
      await Armazenamento.adicionar('sono', item);
    }
    if (!mounted) return;
    FocusScope.of(context).unfocus();
    setState(() {
      _editando = null;
      _dormiu = _planoDormir;
      _acordou = _planoAcordar;
      _obs.clear();
    });
    _aviso('Noite salva: ${duracaoMin(minutos)} de sono 😴');
  }

  void _editar(int indice, Map<String, dynamic> e) {
    final d = minutosDeHora(e['dormiu'] as String?);
    final a = minutosDeHora(e['acordou'] as String?);
    setState(() {
      _editando = indice;
      _dormiu = d ?? _planoDormir;
      _acordou = a ?? _planoAcordar;
      _obs.text = (e['obs'] as String?) ?? '';
    });
  }

  void _cancelarEdicao() => setState(() {
        _editando = null;
        _dormiu = _planoDormir;
        _acordou = _planoAcordar;
        _obs.clear();
      });

  @override
  Widget build(BuildContext context) {
    final estilo = Theme.of(context).textTheme;
    final totalPlano = minutosDeSono(_planoDormir, _planoAcordar);
    final totalNoite = minutosDeSono(_dormiu, _acordou);

    return Scaffold(
      appBar: AppBar(title: const Text('Sono')),
      body: SafeArea(
        child: ValueListenableBuilder<int>(
          valueListenable: Armazenamento.mudou,
          builder: (context, _, __) {
            final noites = Armazenamento.lista('sono');

            return ListView(
              padding: const EdgeInsets.all(16),
              children: [
                // ---- Horários e despertador ----
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Meus horários',
                            style: estilo.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            Expanded(
                              child: _BotaoHora(
                                rotulo: 'Dormir às',
                                minutos: _planoDormir,
                                aoTocar: () => _mudarPlano(dormir: true),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: _BotaoHora(
                                rotulo: 'Acordar às',
                                minutos: _planoAcordar,
                                aoTocar: () => _mudarPlano(dormir: false),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text('Isso dá ${duracaoMin(totalPlano)} de sono por noite.'),
                        SwitchListTile(
                          contentPadding: EdgeInsets.zero,
                          title: const Text('Despertador no celular'),
                          subtitle: const Text(
                              'Cria um alarme para acordar e um lembrete de dormir, '
                              'todos os dias, no app Relógio.'),
                          value: _alarmeLigado,
                          onChanged: _ligarAlarme,
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),

                // ---- Registrar a noite ----
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(_editando == null ? 'Como foi sua noite?' : 'Editando a noite',
                            style: estilo.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            Expanded(
                              child: _BotaoHora(
                                rotulo: 'Dormi às',
                                minutos: _dormiu,
                                aoTocar: () async {
                                  final h = await _escolherHora(_dormiu);
                                  if (h != null) setState(() => _dormiu = h);
                                },
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: _BotaoHora(
                                rotulo: 'Acordei às',
                                minutos: _acordou,
                                aoTocar: () async {
                                  final h = await _escolherHora(_acordou);
                                  if (h != null) setState(() => _acordou = h);
                                },
                              ),
                            ),
                          ],
                        ),
                        Wrap(
                          children: [
                            TextButton(
                              onPressed: () => setState(() => _dormiu = _agoraMin),
                              child: const Text('Dormi agora'),
                            ),
                            TextButton(
                              onPressed: () => setState(() => _acordou = _agoraMin),
                              child: const Text('Acordei agora'),
                            ),
                          ],
                        ),
                        Center(
                          child: Text(
                            totalNoite == 0 ? '--' : duracaoMin(totalNoite),
                            style: TextStyle(
                              fontSize: 34,
                              fontWeight: FontWeight.w900,
                              color: context.destaque,
                            ),
                          ),
                        ),
                        const Center(child: Text('total de sono')),
                        const SizedBox(height: 10),
                        TextField(
                          controller: _obs,
                          maxLines: 2,
                          decoration: const InputDecoration(
                            labelText: 'Observação (opcional)',
                            hintText: 'ex.: acordei no meio da noite',
                          ),
                        ),
                        const SizedBox(height: 10),
                        FilledButton(
                          style: FilledButton.styleFrom(
                            backgroundColor: context.destaque,
                            minimumSize: const Size.fromHeight(46),
                          ),
                          onPressed: _salvarNoite,
                          child: Text(_editando == null ? 'Salvar noite' : 'Salvar alterações'),
                        ),
                        if (_editando != null)
                          TextButton(
                            onPressed: _cancelarEdicao,
                            child: const Text('Cancelar edição'),
                          ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 14),

                // ---- Histórico ----
                Text('Últimas noites',
                    style: estilo.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                if (noites.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 10),
                    child: Text('Nenhuma noite registrada ainda. 😴'),
                  ),
                for (var i = 0; i < noites.length && i < 14; i++)
                  Builder(builder: (context) {
                    final e = noites[i];
                    final min = (e['min'] as int?) ?? (((e['h'] as num) * 60).round());
                    final d = e['dormiu'] as String?;
                    final a = e['acordou'] as String?;
                    final obs = (e['obs'] as String?) ?? '';
                    return ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      leading: const Icon(Icons.bedtime_outlined),
                      title: Text(d != null && a != null
                          ? '${duracaoMin(min)} · $d → $a'
                          : duracaoMin(min)),
                      subtitle: Text(
                        '${formatarData(DateTime.parse(e['data'] as String))}'
                        '${obs.isEmpty ? '' : ' · $obs'}',
                      ),
                      onTap: () => _editar(i, e),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline, size: 20),
                        onPressed: () => Armazenamento.remover('sono', i),
                      ),
                    );
                  }),
                if (noites.isNotEmpty)
                  Text('Toque em uma noite para editar.', style: estilo.bodySmall),
              ],
            );
          },
        ),
      ),
    );
  }
}

/// Botão que mostra um rótulo e um horário (ex.: "Dormi às 23:30").
class _BotaoHora extends StatelessWidget {
  final String rotulo;
  final int minutos;
  final VoidCallback aoTocar;
  const _BotaoHora({required this.rotulo, required this.minutos, required this.aoTocar});

  @override
  Widget build(BuildContext context) => OutlinedButton(
        style: OutlinedButton.styleFrom(
          minimumSize: const Size.fromHeight(56),
          padding: const EdgeInsets.symmetric(horizontal: 8),
        ),
        onPressed: aoTocar,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(rotulo, style: const TextStyle(fontSize: 12)),
            Text(horaDeMinutos(minutos),
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
          ],
        ),
      );
}
