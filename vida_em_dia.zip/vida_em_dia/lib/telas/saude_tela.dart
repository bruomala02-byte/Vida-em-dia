import 'package:flutter/material.dart';

import '../core/armazenamento.dart';
import '../core/formatos.dart';
import '../core/tema.dart';
import 'leitura_tela.dart';

/// Água, sono e peso. O peso também é usado para calcular as calorias da corrida.
class CorpoTela extends StatefulWidget {
  const CorpoTela({super.key});

  @override
  State<CorpoTela> createState() => _CorpoTelaState();
}

class _CorpoTelaState extends State<CorpoTela> {
  static const metaAguaMl = 2000;
  double _sono = 7.5;
  final _peso = TextEditingController();

  void _msg(String t) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));

  Future<void> _agua(int ml) => Armazenamento.adicionar(
      'agua', {'data': DateTime.now().toIso8601String(), 'ml': ml});

  Future<void> _salvarSono() async {
    await Armazenamento.adicionar(
        'sono', {'data': DateTime.now().toIso8601String(), 'h': _sono});
    _msg('Sono salvo 😴');
  }

  Future<void> _salvarPeso() async {
    final v = double.tryParse(_peso.text.trim().replaceAll(',', '.'));
    if (v == null || v < 20 || v > 300) {
      _msg('Digite um peso válido, ex.: 72,5');
      return;
    }
    await Armazenamento.adicionar(
        'pesos', {'data': DateTime.now().toIso8601String(), 'kg': v});
    _peso.clear();
    if (mounted) FocusScope.of(context).unfocus();
    _msg('Peso salvo ⚖️');
  }

  @override
  void dispose() {
    _peso.dispose();
    super.dispose();
  }

  Widget _titulo(String t) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Text(t,
            style: Theme.of(context)
                .textTheme
                .titleLarge
                ?.copyWith(fontWeight: FontWeight.w700)),
      );

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: Armazenamento.mudou,
      builder: (context, _, __) {
        final ml = Armazenamento.aguaHoje();
        final sonos = Armazenamento.lista('sono');
        final pesos = Armazenamento.lista('pesos');

        return ListView(
          padding: const EdgeInsets.all(20),
          children: [
            // ---- Água ----
            _titulo('💧 Água'),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '$ml de $metaAguaMl ml',
                      style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 10),
                    LinearProgressIndicator(
                      value: (ml / metaAguaMl).clamp(0.0, 1.0),
                      minHeight: 12,
                      borderRadius: BorderRadius.circular(8),
                      color: context.destaque,
                    ),
                    const SizedBox(height: 14),
                    Row(children: [
                      for (final v in [200, 300, 500]) ...[
                        Expanded(
                          child: FilledButton.tonal(
                            style: FilledButton.styleFrom(
                                minimumSize: const Size.fromHeight(44)),
                            onPressed: () => _agua(v),
                            child: Text('+$v', style: const TextStyle(fontSize: 15)),
                          ),
                        ),
                        if (v != 500) const SizedBox(width: 8),
                      ],
                    ]),
                    if (ml > 0)
                      TextButton(
                        onPressed: () => Armazenamento.remover('agua', 0),
                        child: const Text('Desfazer último'),
                      ),
                    if (ml >= metaAguaMl) const Text('Meta batida! 🎉'),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            // ---- Sono ----
            _titulo('😴 Sono'),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('${decimal(_sono, 1)} horas',
                        style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
                    Slider(
                      value: _sono,
                      min: 3,
                      max: 12,
                      divisions: 18,
                      activeColor: context.destaque,
                      onChanged: (v) => setState(() => _sono = v),
                    ),
                    FilledButton(
                      style: FilledButton.styleFrom(
                          backgroundColor: context.destaque,
                          minimumSize: const Size.fromHeight(48)),
                      onPressed: _salvarSono,
                      child: const Text('Salvar noite', style: TextStyle(fontSize: 16)),
                    ),
                    if (sonos.isNotEmpty) ...[
                      const SizedBox(height: 10),
                      Text(
                        'Última: ${decimal((sonos.first['h'] as num).toDouble(), 1)} h '
                        '(${formatarData(DateTime.parse(sonos.first['data'] as String))})',
                      ),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            // ---- Peso ----
            _titulo('⚖️ Peso'),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (pesos.isNotEmpty)
                      Text(
                        '${decimal((pesos.first['kg'] as num).toDouble(), 1)} kg'
                        '${pesos.length > 1 ? '  (${_variacao(pesos)})' : ''}',
                        style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800),
                      )
                    else
                      const Text('Sem peso registrado (usando 70 kg nas calorias).'),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _peso,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: const InputDecoration(
                        labelText: 'Seu peso hoje (kg)',
                        prefixIcon: Icon(Icons.monitor_weight_outlined),
                      ),
                    ),
                    const SizedBox(height: 12),
                    FilledButton(
                      style: FilledButton.styleFrom(
                          backgroundColor: context.destaque,
                          minimumSize: const Size.fromHeight(48)),
                      onPressed: _salvarPeso,
                      child: const Text('Salvar peso', style: TextStyle(fontSize: 16)),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  String _variacao(List<Map<String, dynamic>> pesos) {
    final d = (pesos[0]['kg'] as num).toDouble() - (pesos[1]['kg'] as num).toDouble();
    return '${d >= 0 ? '+' : ''}${decimal(d, 1)} kg';
  }
}


/// Aba Saúde: "Corpo" (água, sono, peso) e "Mente" (leitura).
/// IndexedStack mantém o cronômetro de leitura rodando ao trocar de parte.
class SaudeTela extends StatefulWidget {
  const SaudeTela({super.key});

  @override
  State<SaudeTela> createState() => _SaudeTelaState();
}

class _SaudeTelaState extends State<SaudeTela> {
  int _parte = 0;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
          child: Row(
            children: [
              Expanded(
                child: Text('Saúde',
                    style: Theme.of(context)
                        .textTheme
                        .headlineMedium
                        ?.copyWith(fontWeight: FontWeight.w800)),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: SizedBox(
            width: double.infinity,
            child: SegmentedButton<int>(
              segments: const [
                ButtonSegment(value: 0, label: Text('Corpo'), icon: Icon(Icons.favorite)),
                ButtonSegment(
                    value: 1, label: Text('Mente · Leitura'), icon: Icon(Icons.menu_book)),
              ],
              selected: {_parte},
              onSelectionChanged: (s) => setState(() => _parte = s.first),
            ),
          ),
        ),
        Expanded(
          child: IndexedStack(
            index: _parte,
            children: const [CorpoTela(), LeituraTela()],
          ),
        ),
      ],
    );
  }
}
