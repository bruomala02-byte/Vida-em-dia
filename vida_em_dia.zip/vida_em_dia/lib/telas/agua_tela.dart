import 'package:flutter/material.dart';

import '../core/armazenamento.dart';
import '../core/formatos.dart';
import '../core/tema.dart';
import '../widgets/pedir_numero.dart';

/// Página da água: quanto bebeu hoje, botões rápidos e a meta do dia.
class AguaTela extends StatelessWidget {
  const AguaTela({super.key});

  Future<void> _beber(BuildContext context, int ml) async {
    await Armazenamento.adicionar('agua', {
      'data': DateTime.now().toIso8601String(),
      'ml': ml,
    });
  }

  Future<void> _outroValor(BuildContext context) async {
    final v = await pedirNumero(
      context,
      titulo: 'Quanto você bebeu?',
      atual: 250,
      unidade: 'ml',
      minimo: 10,
      maximo: 3000,
    );
    if (v != null && context.mounted) await _beber(context, v);
  }

  Future<void> _mudarMeta(BuildContext context) async {
    final v = await pedirNumero(
      context,
      titulo: 'Meta de água por dia',
      atual: Armazenamento.metaAgua(),
      unidade: 'ml',
      minimo: 500,
      maximo: 8000,
    );
    if (v != null) await Armazenamento.salvarMetaAgua(v);
  }

  @override
  Widget build(BuildContext context) {
    final estilo = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(title: const Text('Água')),
      body: SafeArea(
        child: ValueListenableBuilder<int>(
          valueListenable: Armazenamento.mudou,
          builder: (context, _, __) {
            final meta = Armazenamento.metaAgua();
            final ml = Armazenamento.aguaHoje();
            final manual = Armazenamento.metaAguaManual();
            final pesos = Armazenamento.lista('pesos');
            final hoje = <int>[];
            final todos = Armazenamento.lista('agua');
            for (var i = 0; i < todos.length; i++) {
              if (mesmoDia(DateTime.parse(todos[i]['data'] as String), DateTime.now())) {
                hoje.add(i);
              }
            }

            return ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Hoje', style: estilo.labelMedium),
                        Text('$ml de $meta ml',
                            style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 8),
                        LinearProgressIndicator(
                          value: (ml / meta).clamp(0.0, 1.0),
                          minHeight: 10,
                          borderRadius: BorderRadius.circular(8),
                          color: context.destaque,
                        ),
                        const SizedBox(height: 6),
                        Text(ml >= meta
                            ? 'Meta batida, parabéns! 🎉'
                            : 'Faltam ${meta - ml} ml para a meta 💧'),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    for (final q in const [200, 300, 500]) ...[
                      Expanded(
                        child: FilledButton.tonal(
                          style: FilledButton.styleFrom(
                            minimumSize: const Size.fromHeight(46),
                            padding: EdgeInsets.zero,
                            textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                          ),
                          onPressed: () => _beber(context, q),
                          child: Text('+$q ml'),
                        ),
                      ),
                      const SizedBox(width: 8),
                    ],
                    Expanded(
                      child: OutlinedButton(
                        style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(46)),
                        onPressed: () => _outroValor(context),
                        child: const Text('Outro'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Sua meta',
                            style: estilo.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                        const SizedBox(height: 4),
                        Text(
                          manual
                              ? 'Meta definida por você: $meta ml por dia.'
                              : pesos.isNotEmpty
                                  ? 'Calculada pelo seu peso '
                                      '(${decimal((pesos.first['kg'] as num).toDouble(), 1)} kg): '
                                      '$meta ml por dia (35 ml por kg).'
                                  : 'Meta padrão de $meta ml. Informe seu peso em '
                                      '"Peso e corpo" para o app calcular a sua.',
                        ),
                        Wrap(
                          children: [
                            TextButton(
                              onPressed: () => _mudarMeta(context),
                              child: const Text('Definir meta'),
                            ),
                            if (manual && pesos.isNotEmpty)
                              TextButton(
                                onPressed: Armazenamento.usarMetaAguaAutomatica,
                                child: const Text('Usar a automática'),
                              ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                Text('Registros de hoje',
                    style: estilo.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                if (hoje.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 10),
                    child: Text('Nenhum registro ainda. Bora beber uma água? 💧'),
                  ),
                for (final i in hoje)
                  ListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.water_drop_outlined),
                    title: Text('${todos[i]['ml']} ml'),
                    subtitle: Text(formatarHora(DateTime.parse(todos[i]['data'] as String))),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline, size: 20),
                      onPressed: () => Armazenamento.remover('agua', i),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }
}
