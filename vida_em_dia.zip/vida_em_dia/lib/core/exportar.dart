import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';

/// Uma imagem PNG tirada de um widget da tela.
class ImagemCapturada {
  final Uint8List bytes;
  final int largura, altura;
  const ImagemCapturada(this.bytes, this.largura, this.altura);
}

/// Tira uma "foto" do widget que está dentro de um RepaintBoundary com [chave].
/// A qualidade é reduzida automaticamente se a imagem for gigante.
Future<ImagemCapturada?> capturarImagem(GlobalKey chave, {double pixelRatio = 3}) async {
  final ctx = chave.currentContext;
  if (ctx == null) return null;
  final obj = ctx.findRenderObject();
  if (obj is! RenderRepaintBoundary) return null;
  final maior = obj.size.longestSide;
  final ratio = maior * pixelRatio > 8000 ? 8000 / maior : pixelRatio;
  final img = await obj.toImage(pixelRatio: ratio);
  final dados = await img.toByteData(format: ui.ImageByteFormat.png);
  if (dados == null) return null;
  return ImagemCapturada(dados.buffer.asUint8List(), img.width, img.height);
}

/// Coloca a imagem numa página de PDF do mesmo formato (sem cortar nada).
Future<Uint8List> imagemParaPdf(ImagemCapturada img) async {
  final doc = pw.Document();
  const larguraPagina = 595.0; // largura de uma folha A4, em pontos
  final altura = larguraPagina * img.altura / img.largura;
  final figura = pw.MemoryImage(img.bytes);
  doc.addPage(pw.Page(
    pageFormat: PdfPageFormat(larguraPagina, altura),
    margin: pw.EdgeInsets.zero,
    build: (_) => pw.Image(figura, fit: pw.BoxFit.fill),
  ));
  return doc.save();
}

/// Gera o arquivo (PNG ou PDF) e abre a janela de compartilhar do celular,
/// onde a pessoa escolhe onde guardar. Devolve false se algo falhou.
Future<bool> compartilharRelatorio({
  required GlobalKey chave,
  required String nomeBase,
  required bool pdf,
  String assunto = 'Alvo Vita',
}) async {
  try {
    final img = await capturarImagem(chave);
    if (img == null) return false;
    final Uint8List bytes = pdf ? await imagemParaPdf(img) : img.bytes;
    final pasta = await getTemporaryDirectory();
    final arquivo = File('${pasta.path}/$nomeBase.${pdf ? 'pdf' : 'png'}');
    await arquivo.writeAsBytes(bytes);
    await Share.shareXFiles(
      [XFile(arquivo.path, mimeType: pdf ? 'application/pdf' : 'image/png')],
      subject: assunto,
    );
    return true;
  } catch (_) {
    return false;
  }
}
