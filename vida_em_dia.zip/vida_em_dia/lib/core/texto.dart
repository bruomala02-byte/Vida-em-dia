/// Tira os acentos para comparar textos ("Gênesis" = "genesis").
String semAcento(String t) {
  const de = 'áàâãäéèêëíìîïóòôõöúùûüçñÁÀÂÃÄÉÈÊËÍÌÎÏÓÒÔÕÖÚÙÛÜÇÑ';
  const para = 'aaaaaeeeeiiiiooooouuuucnAAAAAEEEEIIIIOOOOOUUUUCN';
  final b = StringBuffer();
  for (final c in t.split('')) {
    final i = de.indexOf(c);
    b.write(i < 0 ? c : para[i]);
  }
  return b.toString();
}

/// Comparação sem acento e sem diferença de maiúsculas.
String normalizar(String t) => semAcento(t).toLowerCase().trim();
