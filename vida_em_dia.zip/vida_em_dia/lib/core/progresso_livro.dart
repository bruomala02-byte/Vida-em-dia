import '../modelos/livro.dart';
import 'armazenamento.dart';
import 'biblia.dart';

/// Resumo de onde a pessoa está em um livro (para o cartão e a tela do livro).
class ProgressoLivro {
  final String ondeParou; // "Gênesis 5:6" ou "pág. 120" (vazio se ainda não começou)
  final String resumo; // frase pronta para mostrar
  final double? fracao; // 0 a 1 (null se não dá para calcular)
  final String rotuloBotao; // texto do botão de continuar

  const ProgressoLivro(this.ondeParou, this.resumo, this.fracao, this.rotuloBotao);
}

ProgressoLivro progressoDoLivro(Livro l) {
  if (!l.comDivisoes) {
    final pag = Armazenamento.paginaAtual(l.id);
    final total = l.totalPaginas;
    final fr = total > 0 ? (pag / total).clamp(0.0, 1.0) : null;
    return ProgressoLivro(
      pag > 0 ? 'pág. $pag' : '',
      total > 0 ? 'Página $pag de $total · ${((fr ?? 0) * 100).round()}%' : 'Página $pag',
      fr,
      pag > 0 ? 'Continuar de onde parou (pág. $pag)' : 'Começar a ler',
    );
  }

  final pos = Armazenamento.posicaoLivro(l.id);
  final onde = pos?.ondeParou ?? '';
  final caps = Armazenamento.capitulosLidos(l.id).length;
  double? fr;
  var resumo = onde.isEmpty ? 'Ainda não começou' : 'Parou em $onde';
  if (l.ehBiblia && caps > 0) {
    fr = (caps / capitulosBiblia).clamp(0.0, 1.0);
    resumo += ' · $caps de $capitulosBiblia capítulos · ${(fr * 100).toStringAsFixed(1).replaceAll('.', ',')}%';
  } else if (caps > 0) {
    resumo += ' · $caps ${caps == 1 ? 'capítulo' : 'capítulos'} lidos';
  }
  return ProgressoLivro(
    onde,
    resumo,
    fr,
    onde.isEmpty ? 'Começar a ler' : 'Continuar de onde parou ($onde)',
  );
}
