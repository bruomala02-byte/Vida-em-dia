/// Funções pequenas para mostrar tempo, ritmo e datas de forma bonita.

String _doisDigitos(int n) => n.toString().padLeft(2, '0');

/// 3725 segundos -> "1:02:05"  |  125 segundos -> "02:05"
String formatarTempo(int segundos) {
  final h = segundos ~/ 3600;
  final m = (segundos % 3600) ~/ 60;
  final s = segundos % 60;
  if (h > 0) return '$h:${_doisDigitos(m)}:${_doisDigitos(s)}';
  return '${_doisDigitos(m)}:${_doisDigitos(s)}';
}

/// Ritmo = minutos por km. Ex.: 5:30 /km
String formatarRitmo(double km, int segundos) {
  if (km < 0.05 || segundos == 0) return '--:--';
  final total = (segundos / km).round();
  return '${total ~/ 60}:${_doisDigitos(total % 60)}';
}

/// 17/11
String formatarData(DateTime d) => '${_doisDigitos(d.day)}/${_doisDigitos(d.month)}';

/// 23:41
String formatarHora(DateTime d) => '${_doisDigitos(d.hour)}:${_doisDigitos(d.minute)}';

bool mesmoDia(DateTime a, DateTime b) =>
    a.year == b.year && a.month == b.month && a.day == b.day;

/// "Boa madrugada", "Bom dia", "Boa tarde" ou "Boa noite"
String saudacao() {
  final h = DateTime.now().hour;
  if (h < 5) return 'Boa madrugada';
  if (h < 12) return 'Bom dia';
  if (h < 18) return 'Boa tarde';
  return 'Boa noite';
}

/// 5.2 -> "5,20"  (vírgula, como no Brasil)
String decimal(double v, [int casas = 2]) =>
    v.toStringAsFixed(casas).replaceAll('.', ',');

/// 1234.5 -> "R$ 1.234,50"
String formatarReais(double v) {
  final centavos = (v.abs() * 100).round();
  final s = (centavos ~/ 100).toString();
  final b = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) b.write('.');
    b.write(s[i]);
  }
  return '${v < 0 ? '-' : ''}R\$ $b,${_doisDigitos(centavos % 100)}';
}

const nomesMeses = [
  'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
  'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro',
];

/// 3725 -> "01:02:05" (sempre com horas)
String formatarHMS(int s) =>
    '${_doisDigitos(s ~/ 3600)}:${_doisDigitos((s % 3600) ~/ 60)}:${_doisDigitos(s % 60)}';

/// 5400 -> "1h30"  |  1500 -> "25 min"
String formatarDuracao(int s) {
  final h = s ~/ 3600, m = (s % 3600) ~/ 60;
  return h > 0 ? '${h}h${_doisDigitos(m)}' : '$m min';
}
