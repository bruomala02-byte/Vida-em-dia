import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import 'armazenamento.dart';
import 'formatos.dart';
import 'texto_rico.dart' show textoPuroObs;

/// Monta o texto do check-in de um mês: um resumo fácil de ler de
/// corrida, leitura, saúde e finanças.
String montarCheckin(int ano, int mes) {
  final b = StringBuffer();
  final agora = DateTime.now();
  bool noMes(DateTime d) => d.year == ano && d.month == mes;
  String dia(DateTime d) => formatarData(d);

  b.writeln('ALVO VITA · Check-in de ${nomesMeses[mes - 1]} de $ano');
  b.writeln('Gerado em ${formatarData(agora)}/${agora.year} às ${formatarHora(agora)}');
  b.writeln();

  // ---------- Corrida ----------
  final treinos = Armazenamento.treinos().where((t) => noMes(t.data)).toList()
    ..sort((a, b) => a.data.compareTo(b.data));
  b.writeln('🏃 CORRIDA');
  if (treinos.isEmpty) {
    b.writeln('Nenhum treino neste mês.');
  } else {
    final km = treinos.fold<double>(0, (s, t) => s + t.km);
    final seg = treinos.fold<int>(0, (s, t) => s + t.segundos);
    final kcal = treinos.fold<int>(0, (s, t) => s + t.calorias);
    b.writeln('${treinos.length} treino(s) · ${decimal(km)} km · '
        '${formatarDuracao(seg)} · $kcal kcal');
    for (final t in treinos) {
      b.writeln('- ${dia(t.data)} ${formatarHora(t.data)} · ${decimal(t.km)} km · '
          '${formatarTempo(t.segundos)} · ${formatarRitmo(t.km, t.segundos)} /km');
    }
  }
  b.writeln();

  // ---------- Estudos - Leitura ----------
  final leituras = Armazenamento.leituras().where((l) => noMes(l.data)).toList()
    ..sort((a, b) => a.data.compareTo(b.data));
  final estudos = Armazenamento.doMes('estudos', ano, mes)
    ..sort((a, b) => (a['data'] as String).compareTo(b['data'] as String));
  final segLeitura = leituras.fold<int>(0, (s, l) => s + l.segundos);
  final segEstudo = estudos.fold<int>(0, (s, e) => s + (e['s'] as int));
  b.writeln('📖 ESTUDOS - LEITURA');
  if (leituras.isEmpty && estudos.isEmpty) {
    b.writeln('Nenhum estudo ou leitura neste mês.');
  } else {
    b.writeln('Total (estudo + leitura): ${formatarDuracao(segLeitura + segEstudo)}');
    b.writeln('Leitura: ${formatarDuracao(segLeitura)} · Estudo: ${formatarDuracao(segEstudo)}');
    if (leituras.isNotEmpty) {
      final pags = leituras.fold<int>(0, (s, l) => s + l.paginasLidas);
      b.writeln();
      b.writeln('Leitura: ${leituras.length} sessão(ões)${pags > 0 ? ' · $pags páginas' : ''}');
      for (final l in leituras) {
        final paginas = l.paginaFim > 0 ? ' · págs ${l.paginaInicio} → ${l.paginaFim}' : '';
        b.writeln('- ${dia(l.data)} · ${l.livro} · ${formatarDuracao(l.segundos)}$paginas');
        if (l.nota.isNotEmpty) b.writeln('    Nota: ${l.nota}');
      }
    }
    if (estudos.isNotEmpty) {
      b.writeln();
      b.writeln('Estudo: ${estudos.length} sessão(ões)');
      for (final e in estudos) {
        final d = DateTime.parse(e['data'] as String);
        final materia = ((e['materia'] as String?) ?? '').trim();
        final nota = ((e['nota'] as String?) ?? '').trim();
        b.writeln('- ${dia(d)} ${formatarHora(d)} · ${materia.isEmpty ? 'Sem matéria' : materia}'
            ' · ${e['tipo'] ?? 'Estudo'} · ${formatarDuracao(e['s'] as int)}'
            '${nota.isEmpty ? '' : ' · $nota'}');
      }
    }
  }
  b.writeln();

  // ---------- Observações ----------
  final obs = Armazenamento.doMes('observacoes', ano, mes)
    ..sort((a, b) => (a['data'] as String).compareTo(b['data'] as String));
  if (obs.isNotEmpty) {
    b.writeln('📝 OBSERVAÇÕES');
    for (final e in obs) {
      final d = DateTime.parse(e['data'] as String);
      b.writeln('- ${dia(d)} · ${e['ref'] ?? ''}: ${textoPuroObs(e)}');
    }
    b.writeln();
  }

  // ---------- Saúde ----------
  b.writeln('💚 SAÚDE');
  final agua = Armazenamento.doMes('agua', ano, mes);
  if (agua.isEmpty) {
    b.writeln('Água: sem registros.');
  } else {
    final porDia = <int, int>{};
    for (final e in agua) {
      final d = DateTime.parse(e['data'] as String).day;
      porDia[d] = (porDia[d] ?? 0) + (e['ml'] as int);
    }
    final total = porDia.values.fold<int>(0, (s, v) => s + v);
    b.writeln('Água: média de ${(total / porDia.length).round()} ml por dia '
        '(${porDia.length} dia(s) com registro).');
  }
  final sono = Armazenamento.doMes('sono', ano, mes);
  if (sono.isEmpty) {
    b.writeln('Sono: sem registros.');
  } else {
    final media = sono.fold<double>(0, (s, e) => s + (e['h'] as num).toDouble()) / sono.length;
    b.writeln('Sono: média de ${decimal(media, 1)} h por noite (${sono.length} noite(s)).');
  }
  final pesos = Armazenamento.doMes('pesos', ano, mes)
    ..sort((a, b) => (a['data'] as String).compareTo(b['data'] as String));
  if (pesos.isEmpty) {
    b.writeln('Peso: sem registros.');
  } else {
    final primeiro = (pesos.first['kg'] as num).toDouble();
    final ultimo = (pesos.last['kg'] as num).toDouble();
    final dif = ultimo - primeiro;
    b.writeln('Peso: ${decimal(primeiro, 1)} kg → ${decimal(ultimo, 1)} kg '
        '(${dif >= 0 ? '+' : ''}${decimal(dif, 1)} kg).');
  }
  b.writeln();

  // ---------- Finanças ----------
  final lanc = Armazenamento.doMes('lancamentos', ano, mes)
    ..sort((a, b) => (a['data'] as String).compareTo(b['data'] as String));
  b.writeln('💰 FINANÇAS');
  final salario = Armazenamento.salarioBase();
  if (salario > 0) b.writeln('Salário base mensal: ${formatarReais(salario)}');
  if (lanc.isEmpty) {
    b.writeln('Nenhum lançamento neste mês.');
  } else {
    var entradas = 0.0, saidas = 0.0;
    final porCat = <String, double>{};
    for (final e in lanc) {
      final v = (e['valor'] as num).toDouble();
      if (e['tipo'] == 'e') {
        entradas += v;
      } else {
        saidas += v;
        final c = (e['cat'] as String?) ?? 'Outros';
        porCat[c] = (porCat[c] ?? 0) + v;
      }
    }
    b.writeln('Entradas: ${formatarReais(entradas)}');
    b.writeln('Saídas: ${formatarReais(saidas)}');
    b.writeln('Saldo: ${formatarReais(entradas - saidas)}');
    if (porCat.isNotEmpty) {
      b.writeln();
      b.writeln('Gastos por categoria:');
      final cats = porCat.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
      for (final c in cats) {
        b.writeln('- ${c.key}: ${formatarReais(c.value)}');
      }
    }
    b.writeln();
    b.writeln('Lançamentos:');
    for (final e in lanc) {
      final d = DateTime.parse(e['data'] as String);
      final tipo = e['tipo'] == 'e' ? 'Entrada' : 'Saída';
      final desc = (e['desc'] as String?) ?? '';
      b.writeln('- ${dia(d)} · $tipo · ${e['cat']} · '
          '${formatarReais((e['valor'] as num).toDouble())}'
          '${desc.isNotEmpty ? ' · $desc' : ''}');
    }
  }
  return b.toString();
}

/// Cria o arquivo do check-in e abre a janela de compartilhar do celular,
/// onde a pessoa escolhe onde guardar (Arquivos, Drive, WhatsApp, e-mail...).
/// Devolve false se não conseguiu criar o arquivo.
Future<bool> compartilharCheckin(int ano, int mes) async {
  try {
    final texto = montarCheckin(ano, mes);
    final pasta = await getTemporaryDirectory();
    final nome = 'alvo-vita-checkin-$ano-${mes.toString().padLeft(2, '0')}.txt';
    final arquivo = File('${pasta.path}/$nome');
    await arquivo.writeAsString(texto);
    await Share.shareXFiles(
      [XFile(arquivo.path, mimeType: 'text/plain')],
      subject: 'Check-in ${nomesMeses[mes - 1]} de $ano · Alvo Vita',
    );
    return true;
  } catch (_) {
    return false;
  }
}
