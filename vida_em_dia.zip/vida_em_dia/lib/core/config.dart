import 'package:flutter/material.dart';

import 'armazenamento.dart';

/// Configurações do app: modo escuro e zoom de cada tela.
/// Tudo fica salvo no celular.
class Config {
  /// Telas que têm zoom próprio.
  static const telas = ['hoje', 'corrida', 'saude', 'financas'];

  static const rotulos = {
    'hoje': 'Hoje',
    'corrida': 'Corrida',
    'saude': 'Saúde',
    'financas': 'Finanças',
  };

  /// Zoom padrão de cada tela, em %. É aqui que fica a "alteração fixa":
  /// depois de testar, é só dizer os valores que ficaram bons.
  static const zoomPadrao = {
    'hoje': 100,
    'corrida': 90,
    'saude': 100,
    'financas': 94,
  };

  /// Ícones e botões de cada tela, em % (100 = como o app já vinha).
  /// Aqui também fica a "alteração fixa" depois que você escolher os valores.
  static const iconePadrao = {'hoje': 100, 'corrida': 100, 'saude': 100, 'financas': 100};
  static const botaoPadrao = {'hoje': 100, 'corrida': 100, 'saude': 100, 'financas': 100};
  static const barraPadrao = 100;
  /// Botões secundários (baixar extrato, compartilhar, abrir planilha...).
  static const botao2Padrao = {'hoje': 100, 'corrida': 100, 'saude': 100, 'financas': 100};
  /// "Zoom da tela": aumenta ou diminui tudo de uma vez.
  static const geralPadrao = {'hoje': 100, 'corrida': 100, 'saude': 100, 'financas': 100};

  static const zoomMin = 60;
  static const zoomMax = 120;

  static final ValueNotifier<ThemeMode> modoTema = ValueNotifier(ThemeMode.system);

  static final Map<String, ValueNotifier<int>> zoom = {
    for (final t in telas) t: ValueNotifier<int>(zoomPadrao[t]!),
  };

  static final Map<String, ValueNotifier<int>> icones = {
    for (final t in telas) t: ValueNotifier<int>(iconePadrao[t]!),
  };
  static final Map<String, ValueNotifier<int>> botoes = {
    for (final t in telas) t: ValueNotifier<int>(botaoPadrao[t]!),
  };

  static final Map<String, ValueNotifier<int>> botoes2 = {
    for (final t in telas) t: ValueNotifier<int>(botao2Padrao[t]!),
  };
  static final Map<String, ValueNotifier<int>> geral = {
    for (final t in telas) t: ValueNotifier<int>(geralPadrao[t]!),
  };

  /// Tamanho da barra de baixo (Hoje, Corrida, Saúde, Finanças).
  static final ValueNotifier<int> barra = ValueNotifier<int>(barraPadrao);

  static void carregar() {
    final m = Armazenamento.lerInt('modo_tema');
    if (m != null && m >= 0 && m < ThemeMode.values.length) {
      modoTema.value = ThemeMode.values[m];
    }
    for (final t in telas) {
      final z = Armazenamento.lerInt('zoom_$t');
      if (z != null) zoom[t]!.value = z.clamp(zoomMin, zoomMax);
      final i = Armazenamento.lerInt('icone_$t');
      if (i != null) icones[t]!.value = i.clamp(zoomMin, zoomMax);
      final b = Armazenamento.lerInt('botao_$t');
      if (b != null) botoes[t]!.value = b.clamp(zoomMin, zoomMax);
      final b2 = Armazenamento.lerInt('botao2_$t');
      if (b2 != null) botoes2[t]!.value = b2.clamp(zoomMin, zoomMax);
      final g = Armazenamento.lerInt('tudo_$t');
      if (g != null) geral[t]!.value = g.clamp(zoomMin, zoomMax);
    }
    final br = Armazenamento.lerInt('barra_baixo');
    if (br != null) barra.value = br.clamp(zoomMin, zoomMax);
  }

  static Future<void> definirIcone(String tela, int percentual) async {
    final p = percentual.clamp(zoomMin, zoomMax);
    icones[tela]!.value = p;
    await Armazenamento.salvarInt('icone_$tela', p, avisar: false);
  }

  static Future<void> definirBotao(String tela, int percentual) async {
    final p = percentual.clamp(zoomMin, zoomMax);
    botoes[tela]!.value = p;
    await Armazenamento.salvarInt('botao_$tela', p, avisar: false);
  }

  static Future<void> definirBotao2(String tela, int percentual) async {
    final p = percentual.clamp(zoomMin, zoomMax);
    botoes2[tela]!.value = p;
    await Armazenamento.salvarInt('botao2_$tela', p, avisar: false);
  }

  static Future<void> definirGeral(String tela, int percentual) async {
    final p = percentual.clamp(zoomMin, zoomMax);
    geral[tela]!.value = p;
    await Armazenamento.salvarInt('tudo_$tela', p, avisar: false);
  }

  static Future<void> definirBarra(int percentual) async {
    final p = percentual.clamp(zoomMin, zoomMax);
    barra.value = p;
    await Armazenamento.salvarInt('barra_baixo', p, avisar: false);
  }

  /// Todos os valores em texto, para a pessoa me mandar quando achar o ideal.
  static String resumoValores() {
    final b = StringBuffer();
    for (final t in telas) {
      b.writeln('${rotulos[t]}: zoom da tela ${geral[t]!.value}% · textos ${zoom[t]!.value}% · '
          'ícones ${icones[t]!.value}% · botões de ação ${botoes[t]!.value}% · '
          'botões secundários ${botoes2[t]!.value}%');
    }
    b.write('Barra de baixo: ${barra.value}%');
    return b.toString();
  }

  static Future<void> definirModo(ThemeMode modo) async {
    modoTema.value = modo;
    await Armazenamento.salvarInt('modo_tema', modo.index, avisar: false);
  }

  static Future<void> definirZoom(String tela, int percentual) async {
    final p = percentual.clamp(zoomMin, zoomMax);
    zoom[tela]!.value = p;
    await Armazenamento.salvarInt('zoom_$tela', p, avisar: false);
  }

  static Future<void> restaurarZoom() async {
    for (final t in telas) {
      await definirZoom(t, zoomPadrao[t]!);
      await definirIcone(t, iconePadrao[t]!);
      await definirBotao(t, botaoPadrao[t]!);
      await definirBotao2(t, botao2Padrao[t]!);
      await definirGeral(t, geralPadrao[t]!);
    }
    await definirBarra(barraPadrao);
  }
}
