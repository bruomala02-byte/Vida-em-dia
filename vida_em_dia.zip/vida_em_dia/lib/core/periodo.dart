import 'armazenamento.dart';
import 'formatos.dart';

enum TipoPeriodo { dia, semana, mes }

const _diasSemana = [
  'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira',
  'Sexta-feira', 'Sábado', 'Domingo',
];

String _dd(int n) => n.toString().padLeft(2, '0');

/// Um período para relatórios: um dia, uma semana (segunda a domingo) ou um mês.
class PeriodoRel {
  final TipoPeriodo tipo;
  final DateTime ref; // um dia qualquer dentro do período

  PeriodoRel(this.tipo, DateTime ref) : ref = DateTime(ref.year, ref.month, ref.day);

  factory PeriodoRel.hoje(TipoPeriodo tipo) => PeriodoRel(tipo, DateTime.now());

  /// Primeiro dia (inclusive).
  DateTime get ini {
    switch (tipo) {
      case TipoPeriodo.dia:
        return ref;
      case TipoPeriodo.semana:
        return DateTime(ref.year, ref.month, ref.day - (ref.weekday - 1));
      case TipoPeriodo.mes:
        return DateTime(ref.year, ref.month, 1);
    }
  }

  /// Dia seguinte ao último (exclusive).
  DateTime get fim {
    switch (tipo) {
      case TipoPeriodo.dia:
        return DateTime(ref.year, ref.month, ref.day + 1);
      case TipoPeriodo.semana:
        final i = ini;
        return DateTime(i.year, i.month, i.day + 7);
      case TipoPeriodo.mes:
        return DateTime(ref.year, ref.month + 1, 1);
    }
  }

  /// Último dia (inclusive).
  DateTime get ultimo => DateTime(fim.year, fim.month, fim.day - 1);

  /// Quantos dias tem o período.
  int get dias {
    switch (tipo) {
      case TipoPeriodo.dia:
        return 1;
      case TipoPeriodo.semana:
        return 7;
      case TipoPeriodo.mes:
        return DateTime(ref.year, ref.month + 1, 0).day;
    }
  }

  bool contem(DateTime d) => !d.isBefore(ini) && d.isBefore(fim);

  PeriodoRel deslocar(int n) {
    switch (tipo) {
      case TipoPeriodo.dia:
        return PeriodoRel(tipo, DateTime(ref.year, ref.month, ref.day + n));
      case TipoPeriodo.semana:
        return PeriodoRel(tipo, DateTime(ref.year, ref.month, ref.day + 7 * n));
      case TipoPeriodo.mes:
        return PeriodoRel(tipo, DateTime(ref.year, ref.month + n, 1));
    }
  }

  PeriodoRel comTipo(TipoPeriodo t) => PeriodoRel(t, ref);
  PeriodoRel comData(DateTime d) => PeriodoRel(tipo, d);

  String get nomeTipo =>
      const {TipoPeriodo.dia: 'Diário', TipoPeriodo.semana: 'Semanal', TipoPeriodo.mes: 'Mensal'}[tipo]!;

  String get rotulo {
    switch (tipo) {
      case TipoPeriodo.dia:
        return '${_diasSemana[ref.weekday - 1]}, ${_dd(ref.day)}/${_dd(ref.month)}/${ref.year}';
      case TipoPeriodo.semana:
        final u = ultimo;
        return 'Semana de ${formatarData(ini)} a ${formatarData(u)}/${u.year}';
      case TipoPeriodo.mes:
        return '${nomesMeses[ref.month - 1]} de ${ref.year}';
    }
  }

  /// Parte do nome do arquivo: 2026-11-20, semana-2026-11-16 ou 2026-11.
  String get nomeArquivo {
    switch (tipo) {
      case TipoPeriodo.dia:
        return '${ref.year}-${_dd(ref.month)}-${_dd(ref.day)}';
      case TipoPeriodo.semana:
        final i = ini;
        return 'semana-${i.year}-${_dd(i.month)}-${_dd(i.day)}';
      case TipoPeriodo.mes:
        return '${ref.year}-${_dd(ref.month)}';
    }
  }

  /// Salário base do período: o mês inteiro, ou a parte proporcional
  /// (7 dias ou 1 dia do mês) na semana e no dia.
  double get salario {
    final base = Armazenamento.salarioBase();
    if (base <= 0) return 0;
    final diasMes = DateTime(ref.year, ref.month + 1, 0).day;
    switch (tipo) {
      case TipoPeriodo.mes:
        return base;
      case TipoPeriodo.semana:
        return base * 7 / diasMes;
      case TipoPeriodo.dia:
        return base / diasMes;
    }
  }
}
