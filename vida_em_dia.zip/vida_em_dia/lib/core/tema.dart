import 'package:flutter/material.dart';

/// Cores de cada módulo do app. Cada área tem a sua cor,
/// assim a pessoa sabe onde está só de olhar.
class Cores {
  static const corrida = Color(0xFFFF6B35);
  static const leitura = Color(0xFF6C5CE7);
  static const saude = Color(0xFF00B894);
  static const financas = Color(0xFF0984E3);
  static const saida = Color(0xFFE17055);
}

/// Cor de destaque do app, escolhida pelo usuário (salva no celular).
class TemaApp {
  static final ValueNotifier<Color> destaque = ValueNotifier(Cores.corrida);
}

/// Use `context.destaque` nas telas: assim elas se atualizam quando a cor muda.
extension DestaqueContext on BuildContext {
  Color get destaque => Theme.of(this).colorScheme.primary;
}

ThemeData criarTema(Brightness brilho, Color destaque) {
  final escuro = brilho == Brightness.dark;
  final base = ColorScheme.fromSeed(seedColor: destaque, brightness: brilho);
  final textoSobreDestaque =
      ThemeData.estimateBrightnessForColor(destaque) == Brightness.dark
          ? Colors.white
          : Colors.black;

  // Modo escuro = preto de verdade (bom para tela OLED e bateria),
  // textos brancos e ícones na cor que a pessoa escolheu.
  const bordaEscura = Color(0xFF2A2A2A);
  final esquema = base.copyWith(
    primary: destaque,
    onPrimary: textoSobreDestaque,
    surface: escuro ? Colors.black : base.surface,
    onSurface: escuro ? Colors.white : base.onSurface,
    onSurfaceVariant: escuro ? const Color(0xFFD9D9D9) : base.onSurfaceVariant,
    surfaceContainerHighest:
        escuro ? const Color(0xFF161616) : base.surfaceContainerHighest,
    outlineVariant: escuro ? bordaEscura : base.outlineVariant,
  );
  final fundoJanelas = escuro ? const Color(0xFF0B0B0B) : null;

  return ThemeData(
    useMaterial3: true,
    colorScheme: esquema,
    scaffoldBackgroundColor: esquema.surface,
    // Ícones sempre na cor escolhida pela pessoa.
    iconTheme: IconThemeData(color: destaque),
    listTileTheme: ListTileThemeData(iconColor: destaque),
    appBarTheme: AppBarTheme(
      centerTitle: false,
      backgroundColor: esquema.surface,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      iconTheme: IconThemeData(color: destaque),
      titleTextStyle: TextStyle(
        fontSize: 22,
        fontWeight: FontWeight.w700,
        color: esquema.onSurface,
      ),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: escuro ? Colors.black : null,
      surfaceTintColor: Colors.transparent,
      indicatorColor: destaque.withValues(alpha: 0.22),
      iconTheme: WidgetStatePropertyAll(IconThemeData(color: destaque)),
    ),
    cardTheme: CardThemeData(
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      color: escuro
          ? const Color(0xFF0A0A0A)
          : esquema.surfaceContainerHighest.withValues(alpha: 0.5),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: escuro ? const BorderSide(color: bordaEscura) : BorderSide.none,
      ),
      margin: EdgeInsets.zero,
    ),
    dialogTheme: DialogThemeData(
      backgroundColor: fundoJanelas,
      surfaceTintColor: Colors.transparent,
    ),
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: fundoJanelas,
      surfaceTintColor: Colors.transparent,
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        minimumSize: const Size.fromHeight(56),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
    ),
  );
}
