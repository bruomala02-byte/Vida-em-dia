import 'package:flutter/material.dart';

/// Cores de cada módulo do app. Cada área tem a sua cor,
/// assim a pessoa sabe onde está só de olhar.
class Cores {
  static const corrida = Color(0xFFFF6B35);
  static const leitura = Color(0xFF6C5CE7);
  static const saude = Color(0xFF00B894);
  static const financas = Color(0xFF0984E3);
  static const saida = Color(0xFFE17055);
}

/// Cor de destaque do app, escolhida pelo usuário (salva no celular).
class TemaApp {
  static final ValueNotifier<Color> destaque = ValueNotifier(Cores.corrida);
}

/// Use `context.destaque` nas telas: assim elas se atualizam quando a cor muda.
extension DestaqueContext on BuildContext {
  Color get destaque => Theme.of(this).colorScheme.primary;
}

ThemeData criarTema(Brightness brilho, Color destaque) {
  final base = ColorScheme.fromSeed(seedColor: destaque, brightness: brilho);
  final esquema = base.copyWith(
    primary: destaque,
    onPrimary: ThemeData.estimateBrightnessForColor(destaque) == Brightness.dark
        ? Colors.white
        : Colors.black,
  );

  return ThemeData(
    useMaterial3: true,
    colorScheme: esquema,
    scaffoldBackgroundColor: esquema.surface,
    appBarTheme: AppBarTheme(
      centerTitle: false,
      backgroundColor: esquema.surface,
      elevation: 0,
      titleTextStyle: TextStyle(
        fontSize: 22,
        fontWeight: FontWeight.w700,
        color: esquema.onSurface,
      ),
    ),
    cardTheme: CardThemeData(
      elevation: 0,
      color: esquema.surfaceContainerHighest.withValues(alpha: 0.5),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      margin: EdgeInsets.zero,
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        minimumSize: const Size.fromHeight(56),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
    ),
  );
}
