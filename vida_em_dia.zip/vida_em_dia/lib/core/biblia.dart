import 'texto.dart';

/// Modelo opcional "Bíblia": os 66 livros e quantos capítulos cada um tem.
/// Serve para sugerir o nome enquanto a pessoa digita e para avisar se o
/// capítulo não existe. Quem lê outro livro com capítulos usa o mesmo sistema
/// digitando as partes que quiser.
const livrosBiblia = <(String, int)>[
  ('Gênesis', 50), ('Êxodo', 40), ('Levítico', 27), ('Números', 36),
  ('Deuteronômio', 34), ('Josué', 24), ('Juízes', 21), ('Rute', 4),
  ('1 Samuel', 31), ('2 Samuel', 24), ('1 Reis', 22), ('2 Reis', 25),
  ('1 Crônicas', 29), ('2 Crônicas', 36), ('Esdras', 10), ('Neemias', 13),
  ('Ester', 10), ('Jó', 42), ('Salmos', 150), ('Provérbios', 31),
  ('Eclesiastes', 12), ('Cantares', 8), ('Isaías', 66), ('Jeremias', 52),
  ('Lamentações', 5), ('Ezequiel', 48), ('Daniel', 12), ('Oseias', 14),
  ('Joel', 3), ('Amós', 9), ('Obadias', 1), ('Jonas', 4), ('Miqueias', 7),
  ('Naum', 3), ('Habacuque', 3), ('Sofonias', 3), ('Ageu', 2),
  ('Zacarias', 14), ('Malaquias', 4),
  ('Mateus', 28), ('Marcos', 16), ('Lucas', 24), ('João', 21), ('Atos', 28),
  ('Romanos', 16), ('1 Coríntios', 16), ('2 Coríntios', 13), ('Gálatas', 6),
  ('Efésios', 6), ('Filipenses', 4), ('Colossenses', 4),
  ('1 Tessalonicenses', 5), ('2 Tessalonicenses', 3), ('1 Timóteo', 6),
  ('2 Timóteo', 4), ('Tito', 3), ('Filemom', 1), ('Hebreus', 13),
  ('Tiago', 5), ('1 Pedro', 5), ('2 Pedro', 3), ('1 João', 5), ('2 João', 1),
  ('3 João', 1), ('Judas', 1), ('Apocalipse', 22),
];

final int capitulosBiblia = livrosBiblia.fold<int>(0, (s, l) => s + l.$2);

/// Quantos capítulos tem o livro da Bíblia com esse nome (null se não achar).
int? capitulosDoLivro(String nome) {
  final n = normalizar(nome);
  for (final l in livrosBiblia) {
    if (normalizar(l.$1) == n) return l.$2;
  }
  return null;
}

/// Nome certinho (com acento) se o texto bate com um livro da Bíblia.
String? nomeBiblia(String texto) {
  final n = normalizar(texto);
  for (final l in livrosBiblia) {
    if (normalizar(l.$1) == n) return l.$1;
  }
  return null;
}

/// Livros da Bíblia que combinam com o que a pessoa digitou.
List<String> sugerirBiblia(String digitado, {int max = 6}) {
  final n = normalizar(digitado);
  if (n.isEmpty) return const [];
  final achados = [
    for (final l in livrosBiblia)
      if (normalizar(l.$1).contains(n)) l.$1,
  ];
  // os que começam com o texto vêm primeiro
  achados.sort((a, b) {
    final pa = normalizar(a).startsWith(n) ? 0 : 1;
    final pb = normalizar(b).startsWith(n) ? 0 : 1;
    return pa.compareTo(pb);
  });
  return achados.take(max).toList();
}
