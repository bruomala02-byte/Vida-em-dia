import 'package:flutter/material.dart';

/// Texto com negrito e marca-texto, sem nenhum símbolo visível.
///
/// Cada letra do texto tem um "código": o bit 0 diz se está em negrito e o
/// resto (código >> 1) é a cor do marca-texto (0 = sem marca).
/// No armazenamento o texto fica limpo e os estilos vão numa lista de
/// trechos [início, fim, código] (só os trechos que têm algum estilo).

const coresMarca = <Color?>[
  null,
  Color(0xFFFFF59D), // amarelo
  Color(0xFFA5D6A7), // verde
  Color(0xFFF8BBD0), // rosa
  Color(0xFF90CAF9), // azul
  Color(0xFFFFCC80), // laranja
];
const nomesMarca = ['Tirar marca', 'Amarelo', 'Verde', 'Rosa', 'Azul', 'Laranja'];

const coresEtiqueta = <Color?>[
  null,
  Color(0xFFE53935), // vermelho
  Color(0xFFFB8C00), // laranja
  Color(0xFFFDD835), // amarelo
  Color(0xFF43A047), // verde
  Color(0xFF1E88E5), // azul
  Color(0xFF8E24AA), // roxo
];
const nomesEtiqueta = [
  'Sem etiqueta',
  'Vermelho',
  'Laranja',
  'Amarelo',
  'Verde',
  'Azul',
  'Roxo',
];

/// Estilo de uma letra a partir do código.
TextStyle estiloDoCodigo(int cod, TextStyle? base) {
  final cor = cod >> 1;
  final fundo = (cor > 0 && cor < coresMarca.length) ? coresMarca[cor] : null;
  return (base ?? const TextStyle()).copyWith(
    fontWeight: (cod & 1) == 1 ? FontWeight.w800 : null,
    backgroundColor: fundo,
    color: fundo != null ? Colors.black87 : null,
  );
}

/// Junta letras vizinhas de mesmo estilo em pedaços de texto.
List<InlineSpan> spansRicos(String t, List<int> c, TextStyle? base) {
  final out = <InlineSpan>[];
  var i = 0;
  while (i < t.length) {
    final cod = i < c.length ? c[i] : 0;
    var j = i + 1;
    while (j < t.length && (j < c.length ? c[j] : 0) == cod) {
      j++;
    }
    out.add(TextSpan(text: t.substring(i, j), style: estiloDoCodigo(cod, base)));
    i = j;
  }
  return out;
}

/// Lista de trechos [início, fim, código] para guardar.
List<List<int>> trechosDe(List<int> c) {
  final out = <List<int>>[];
  var i = 0;
  while (i < c.length) {
    final cod = c[i];
    var j = i + 1;
    while (j < c.length && c[j] == cod) {
      j++;
    }
    if (cod != 0) out.add([i, j, cod]);
    i = j;
  }
  return out;
}

/// Observação lida do armazenamento: texto limpo + códigos de estilo.
class ObsRica {
  final String texto;
  final List<int> codigos;
  const ObsRica(this.texto, this.codigos);
}

/// Lê uma observação salva. Aceita o formato novo ('est') e o antigo, em que
/// o negrito vinha marcado com ** (versão 0.6.0).
ObsRica lerObsRica(Map<String, dynamic> e) {
  final bruto = (e['texto'] as String?) ?? '';
  final est = e['est'];
  if (est is List) {
    final c = List<int>.filled(bruto.length, 0);
    for (final r in est) {
      if (r is List && r.length >= 3) {
        final a = (r[0] as num).toInt().clamp(0, bruto.length);
        final b = (r[1] as num).toInt().clamp(0, bruto.length);
        final cod = (r[2] as num).toInt();
        for (var i = a; i < b; i++) {
          c[i] = cod;
        }
      }
    }
    return ObsRica(bruto, c);
  }
  if (bruto.contains('**')) {
    final partes = bruto.split('**');
    final sb = StringBuffer();
    final c = <int>[];
    for (var i = 0; i < partes.length; i++) {
      sb.write(partes[i]);
      c.addAll(List<int>.filled(partes[i].length, i.isOdd ? 1 : 0));
    }
    return ObsRica(sb.toString(), c);
  }
  return ObsRica(bruto, List<int>.filled(bruto.length, 0));
}

/// Só o texto, sem estilos (para relatórios, busca e arquivos de texto).
String textoPuroObs(Map<String, dynamic> e) => lerObsRica(e).texto;

/// Controlador do campo de escrever: guarda o código de cada letra e
/// desenha o texto já formatado dentro do próprio campo.
class ControladorRico extends TextEditingController {
  List<int> codigos = [];
  int? _pendente; // estilo escolhido com o cursor parado, vale para o que digitar

  ControladorRico({ObsRica? inicial}) : super(text: inicial?.texto ?? '') {
    codigos = inicial == null
        ? List<int>.filled(text.length, 0)
        : List<int>.of(inicial.codigos);
  }

  void _garantir() {
    if (codigos.length != text.length) {
      final novo = List<int>.filled(text.length, 0);
      for (var i = 0; i < novo.length && i < codigos.length; i++) {
        novo[i] = codigos[i];
      }
      codigos = novo;
    }
  }

  @override
  set value(TextEditingValue novo) {
    final antigo = text;
    final n = novo.text;
    if (antigo != n) {
      _ajustar(antigo, n);
    } else if (novo.selection != value.selection) {
      _pendente = null;
    }
    super.value = novo;
  }

  /// Acompanha a digitação: o que foi inserido ganha o estilo do cursor e o
  /// que foi apagado leva os seus códigos embora.
  void _ajustar(String o, String n) {
    if (codigos.length != o.length) {
      final novo = List<int>.filled(o.length, 0);
      for (var i = 0; i < novo.length && i < codigos.length; i++) {
        novo[i] = codigos[i];
      }
      codigos = novo;
    }
    final menor = o.length < n.length ? o.length : n.length;
    var p = 0;
    while (p < menor && o.codeUnitAt(p) == n.codeUnitAt(p)) {
      p++;
    }
    var s = 0;
    while (s < menor - p &&
        o.codeUnitAt(o.length - 1 - s) == n.codeUnitAt(n.length - 1 - s)) {
      s++;
    }
    final inseridos = n.length - p - s;
    final estilo = _pendente ?? (p > 0 ? codigos[p - 1] : 0);
    codigos = [
      ...codigos.sublist(0, p),
      ...List<int>.filled(inseridos, estilo),
      ...codigos.sublist(o.length - s),
    ];
    if (inseridos > 0) _pendente = null;
  }

  bool get _temSelecao => selection.isValid && !selection.isCollapsed;

  int _estiloNoCursor() {
    final p = selection.isValid ? selection.start : text.length;
    if (p <= 0 || codigos.isEmpty) return 0;
    return codigos[(p - 1).clamp(0, codigos.length - 1)];
  }

  /// Letra em negrito? (para acender o botão N)
  bool get negritoAtivo {
    _garantir();
    if (_temSelecao) {
      return codigos.sublist(selection.start, selection.end).every((c) => (c & 1) == 1);
    }
    return ((_pendente ?? _estiloNoCursor()) & 1) == 1;
  }

  /// Liga e desliga o negrito. Com texto selecionado vale para ele; com o
  /// cursor parado vale para o que for digitado a seguir.
  void alternarNegrito() {
    _garantir();
    if (_temSelecao) {
      final a = selection.start, b = selection.end;
      final todos = codigos.sublist(a, b).every((c) => (c & 1) == 1);
      for (var i = a; i < b; i++) {
        codigos[i] = todos ? (codigos[i] & ~1) : (codigos[i] | 1);
      }
    } else {
      _pendente = (_pendente ?? _estiloNoCursor()) ^ 1;
    }
    notifyListeners();
  }

  /// Marca-texto: [cor] 0 tira a marca. Mantém o negrito do trecho.
  void definirCor(int cor) {
    _garantir();
    if (_temSelecao) {
      for (var i = selection.start; i < selection.end; i++) {
        codigos[i] = (codigos[i] & 1) | (cor << 1);
      }
    } else {
      _pendente = ((_pendente ?? _estiloNoCursor()) & 1) | (cor << 1);
    }
    notifyListeners();
  }

  @override
  TextSpan buildTextSpan({
    required BuildContext context,
    TextStyle? style,
    required bool withComposing,
  }) {
    _garantir();
    return TextSpan(style: style, children: spansRicos(text, codigos, style));
  }

  /// Os trechos com estilo, prontos para guardar.
  List<List<int>> get trechos {
    _garantir();
    return trechosDe(codigos);
  }
}
