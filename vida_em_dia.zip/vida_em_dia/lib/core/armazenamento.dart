import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../modelos/livro.dart';
import '../modelos/sessao_leitura.dart';
import 'formatos.dart';
import '../modelos/treino.dart';

/// Guarda tudo no próprio celular (sem internet, sem login).
/// Mais para frente dá para trocar por SQLite sem mexer nas telas.
class Armazenamento {
  static late SharedPreferences _prefs;

  /// Sobe de número toda vez que algo é salvo.
  /// A tela "Hoje" escuta isso para se atualizar sozinha.
  static final ValueNotifier<int> mudou = ValueNotifier(0);

  static Future<void> iniciar() async {
    _prefs = await SharedPreferences.getInstance();
  }

  static List<Map<String, dynamic>> _ler(String chave) {
    final texto = _prefs.getString(chave);
    if (texto == null) return [];
    return (jsonDecode(texto) as List).cast<Map<String, dynamic>>();
  }

  static Future<void> _adicionar(String chave, Map<String, dynamic> item) async {
    final lista = _ler(chave)..insert(0, item); // mais novo primeiro
    await _prefs.setString(chave, jsonEncode(lista));
    mudou.value++;
  }

  // ---- Corrida ----
  static List<Treino> treinos() => _ler('treinos').map(Treino.fromJson).toList();

  static Future<void> salvarTreino(Treino t) => _adicionar('treinos', t.toJson());

  // ---- Leitura ----
  static List<SessaoLeitura> leituras() =>
      _ler('leituras').map(SessaoLeitura.fromJson).toList();

  static Future<void> salvarLeitura(SessaoLeitura s) =>
      _adicionar('leituras', s.toJson());

  // ---- Livros ----
  static List<Livro> livros() => _ler('livros').map(Livro.fromJson).toList();

  static Future<void> salvarLivro(Livro l) => _adicionar('livros', l.toJson());

  /// Apaga o livro e todo o histórico de leitura dele.
  static Future<void> removerLivro(int id) async {
    final ls = _ler('livros')..removeWhere((e) => e['id'] == id);
    final ss = _ler('leituras')..removeWhere((e) => e['lid'] == id);
    await _prefs.setString('livros', jsonEncode(ls));
    await _prefs.setString('leituras', jsonEncode(ss));
    mudou.value++;
  }

  /// Apaga uma única sessão de leitura (a que tem esse início e esse livro).
  static Future<void> removerLeitura(SessaoLeitura s) async {
    final ss = _ler('leituras');
    final i = ss.indexWhere(
        (e) => e['data'] == s.data.toIso8601String() && e['lid'] == s.livroId);
    if (i < 0) return;
    ss.removeAt(i);
    await _prefs.setString('leituras', jsonEncode(ss));
    mudou.value++;
  }

  static List<SessaoLeitura> sessoesDoLivro(int id) =>
      leituras().where((s) => s.livroId == id).toList();

  /// Página onde parou na última leitura (0 se ainda não leu).
  static int paginaAtual(int id) {
    final l = sessoesDoLivro(id);
    return l.isEmpty ? 0 : l.first.paginaFim;
  }

  // ---- Cor do app ----
  static int? corSalva() => _prefs.getInt('cor_app');
  static Future<void> salvarCor(int valor) => _prefs.setInt('cor_app', valor);

  // ---- Genérico (Saúde e Finanças) ----
  // Listas com o item mais novo primeiro.
  static List<Map<String, dynamic>> lista(String chave) => _ler(chave);

  static Future<void> adicionar(String chave, Map<String, dynamic> item) =>
      _adicionar(chave, item);

  static Future<void> remover(String chave, int indice) async {
    final l = _ler(chave)..removeAt(indice);
    await _prefs.setString(chave, jsonEncode(l));
    mudou.value++;
  }

  // ---- Resumos usados em mais de uma tela ----
  /// Último peso registrado (70 kg se ainda não houver). Usado nas calorias.
  static double pesoAtual() {
    final l = _ler('pesos');
    return l.isEmpty ? 70.0 : (l.first['kg'] as num).toDouble();
  }

  static int aguaHoje() => _ler('agua')
      .where((e) => mesmoDia(DateTime.parse(e['data'] as String), DateTime.now()))
      .fold<int>(0, (s, e) => s + (e['ml'] as int));

  static double saldoMes() {
    final agora = DateTime.now();
    var saldo = 0.0;
    for (final e in _ler('lancamentos')) {
      final d = DateTime.parse(e['data'] as String);
      if (d.year != agora.year || d.month != agora.month) continue;
      final v = (e['valor'] as num).toDouble();
      saldo += e['tipo'] == 'e' ? v : -v;
    }
    return saldo;
  }
}
