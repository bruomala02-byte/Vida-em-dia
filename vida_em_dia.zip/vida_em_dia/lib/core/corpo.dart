/// Cálculos simples de saúde a partir do peso e da altura.
/// São estimativas gerais (tabela da OMS para adultos) e não substituem
/// a avaliação de um profissional de saúde.
class AnaliseCorpo {
  final double imc;
  final String faixa; // "Abaixo do peso", "Peso normal"...
  final double pesoMin; // menor peso na faixa normal (IMC 18,5)
  final double pesoMax; // maior peso na faixa normal (IMC 24,9)
  final int aguaMl; // 35 ml por kg

  const AnaliseCorpo({
    required this.imc,
    required this.faixa,
    required this.pesoMin,
    required this.pesoMax,
    required this.aguaMl,
  });
}

/// [alturaM] em metros (ex.: 1.79). Devolve null se a altura não for válida.
AnaliseCorpo? analisarCorpo(double pesoKg, double? alturaM) {
  if (alturaM == null || alturaM < 1.0 || alturaM > 2.5 || pesoKg <= 0) return null;
  final imc = pesoKg / (alturaM * alturaM);
  final String faixa;
  if (imc < 18.5) {
    faixa = 'Abaixo do peso';
  } else if (imc < 25) {
    faixa = 'Peso normal';
  } else if (imc < 30) {
    faixa = 'Sobrepeso';
  } else {
    faixa = 'Obesidade';
  }
  return AnaliseCorpo(
    imc: imc,
    faixa: faixa,
    pesoMin: 18.5 * alturaM * alturaM,
    pesoMax: 24.9 * alturaM * alturaM,
    aguaMl: ((pesoKg * 35) / 50).round() * 50,
  );
}

/// Aceita "1,79", "1.79" ou "179" (centímetros) e devolve metros.
double? lerAltura(String texto) {
  final v = double.tryParse(texto.trim().replaceAll(',', '.'));
  if (v == null) return null;
  final m = v > 3 ? v / 100 : v;
  return (m >= 1.0 && m <= 2.5) ? m : null;
}
