import 'marca.dart';

/// Um ponto do percurso: latitude, longitude, altitude e segundo da corrida.
class Ponto {
  final double lat, lng, alt;
  final int s;
  const Ponto(this.lat, this.lng, this.alt, this.s);

  List<num> toJson() => [lat, lng, alt, s];

  factory Ponto.fromJson(List j) => Ponto(
        (j[0] as num).toDouble(),
        (j[1] as num).toDouble(),
        (j[2] as num).toDouble(),
        (j[3] as num).toInt(),
      );
}

/// Um treino de corrida salvo no celular.
class Treino {
  final DateTime data;
  final double km;
  final int segundos;
  final int calorias;
  final double elevacao; // metros subidos
  final double velMaxKmh;
  final List<Ponto> pontos;
  final String modo; // 'corrida' ou 'bike'
  final List<Marca> marcas; // trechos marcados à mão (sem sinal de GPS)

  const Treino({
    required this.data,
    required this.km,
    required this.segundos,
    this.calorias = 0,
    this.elevacao = 0,
    this.velMaxKmh = 0,
    this.pontos = const [],
    this.modo = 'corrida',
    this.marcas = const [],
  });

  bool get ehBike => modo == 'bike';

  Map<String, dynamic> toJson() => {
        'data': data.toIso8601String(),
        'km': km,
        's': segundos,
        'cal': calorias,
        'elev': elevacao,
        'vmax': velMaxKmh,
        'p': pontos.map((p) => p.toJson()).toList(),
        'modo': modo,
        'm': marcas.map((m) => m.toJson()).toList(),
      };

  // Treinos antigos (sem percurso) continuam abrindo normalmente.
  factory Treino.fromJson(Map<String, dynamic> j) => Treino(
        data: DateTime.parse(j['data'] as String),
        km: (j['km'] as num).toDouble(),
        segundos: j['s'] as int,
        calorias: (j['cal'] as num?)?.toInt() ?? 0,
        elevacao: (j['elev'] as num?)?.toDouble() ?? 0,
        velMaxKmh: (j['vmax'] as num?)?.toDouble() ?? 0,
        pontos: ((j['p'] as List?) ?? [])
            .map((e) => Ponto.fromJson(e as List))
            .toList(),
        modo: (j['modo'] as String?) ?? 'corrida',
        marcas: ((j['m'] as List?) ?? []).map((e) => Marca.fromJson(e as List)).toList(),
      );
}

/// Os dois modos de percurso e o limite de velocidade de cada um.
/// Não existe limite de distância, só de velocidade: leituras de GPS acima
/// do limite (carro, ônibus, erro do sinal) são ignoradas.
class ModoPercurso {
  final String id;
  final String nome;
  final double limiteKmh;
  final double kcalKgKm; // estimativa de calorias por kg por km
  const ModoPercurso(this.id, this.nome, this.limiteKmh, this.kcalKgKm);

  static const corrida = ModoPercurso('corrida', 'Corrida', 22, 1.036);
  static const bike = ModoPercurso('bike', 'Ciclismo', 50, 0.40);
  static const todos = [corrida, bike];

  static ModoPercurso de(String id) => id == 'bike' ? bike : corrida;
}
