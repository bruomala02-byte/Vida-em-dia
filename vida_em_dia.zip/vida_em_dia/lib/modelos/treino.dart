/// Um ponto do percurso: latitude, longitude, altitude e segundo da corrida.
class Ponto {
  final double lat, lng, alt;
  final int s;
  const Ponto(this.lat, this.lng, this.alt, this.s);

  List<num> toJson() => [lat, lng, alt, s];

  factory Ponto.fromJson(List j) => Ponto(
        (j[0] as num).toDouble(),
        (j[1] as num).toDouble(),
        (j[2] as num).toDouble(),
        (j[3] as num).toInt(),
      );
}

/// Um treino de corrida salvo no celular.
class Treino {
  final DateTime data;
  final double km;
  final int segundos;
  final int calorias;
  final double elevacao; // metros subidos
  final double velMaxKmh;
  final List<Ponto> pontos;

  const Treino({
    required this.data,
    required this.km,
    required this.segundos,
    this.calorias = 0,
    this.elevacao = 0,
    this.velMaxKmh = 0,
    this.pontos = const [],
  });

  Map<String, dynamic> toJson() => {
        'data': data.toIso8601String(),
        'km': km,
        's': segundos,
        'cal': calorias,
        'elev': elevacao,
        'vmax': velMaxKmh,
        'p': pontos.map((p) => p.toJson()).toList(),
      };

  // Treinos antigos (sem percurso) continuam abrindo normalmente.
  factory Treino.fromJson(Map<String, dynamic> j) => Treino(
        data: DateTime.parse(j['data'] as String),
        km: (j['km'] as num).toDouble(),
        segundos: j['s'] as int,
        calorias: (j['cal'] as num?)?.toInt() ?? 0,
        elevacao: (j['elev'] as num?)?.toDouble() ?? 0,
        velMaxKmh: (j['vmax'] as num?)?.toDouble() ?? 0,
        pontos: ((j['p'] as List?) ?? [])
            .map((e) => Ponto.fromJson(e as List))
            .toList(),
      );
}
