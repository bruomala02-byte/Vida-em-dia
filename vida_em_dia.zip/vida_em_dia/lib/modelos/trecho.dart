/// Um trecho lido numa sessão.
/// Livro simples: [pagIni] e [pagFim].
/// Livro com divisões (ex.: Bíblia): [parte] (ex.: Gênesis), capítulo e
/// versículo de início e de fim. Tudo é opcional (0 = não informado).
class Trecho {
  final String parte;
  final int capIni, versIni, capFim, versFim;
  final int pagIni, pagFim;

  const Trecho({
    this.parte = '',
    this.capIni = 0,
    this.versIni = 0,
    this.capFim = 0,
    this.versFim = 0,
    this.pagIni = 0,
    this.pagFim = 0,
  });

  bool get vazio =>
      parte.isEmpty && capIni == 0 && capFim == 0 && pagIni == 0 && pagFim == 0;

  bool get ehPagina => parte.isEmpty && capIni == 0 && capFim == 0;

  Map<String, dynamic> toJson() => {
        'pt': parte,
        'ci': capIni,
        'vi': versIni,
        'cf': capFim,
        'vf': versFim,
        'pi': pagIni,
        'pf': pagFim,
      };

  factory Trecho.fromJson(Map<String, dynamic> j) => Trecho(
        parte: (j['pt'] as String?) ?? '',
        capIni: (j['ci'] as num?)?.toInt() ?? 0,
        versIni: (j['vi'] as num?)?.toInt() ?? 0,
        capFim: (j['cf'] as num?)?.toInt() ?? 0,
        versFim: (j['vf'] as num?)?.toInt() ?? 0,
        pagIni: (j['pi'] as num?)?.toInt() ?? 0,
        pagFim: (j['pf'] as num?)?.toInt() ?? 0,
      );

  static String _pos(int cap, int vers) =>
      cap <= 0 ? '' : (vers > 0 ? '$cap:$vers' : '$cap');

  /// Onde o trecho termina (onde a pessoa parou): "Gênesis 5:6" ou "pág. 120".
  String get ondeParou {
    if (ehPagina) return pagFim > 0 ? 'pág. $pagFim' : '';
    final fim = capFim > 0 ? _pos(capFim, versFim) : _pos(capIni, versIni);
    return [parte, fim].where((e) => e.isNotEmpty).join(' ');
  }

  /// Texto completo: "Gênesis 1:1 → 5:6" ou "págs 10 → 25".
  String get texto {
    if (ehPagina) {
      if (pagIni > 0 && pagFim > 0 && pagFim != pagIni) return 'págs $pagIni → $pagFim';
      return pagFim > 0 ? 'pág. $pagFim' : (pagIni > 0 ? 'pág. $pagIni' : '');
    }
    final ini = _pos(capIni, versIni);
    final fim = _pos(capFim, versFim);
    final base = [parte, ini].where((e) => e.isNotEmpty).join(' ');
    if (fim.isNotEmpty && fim != ini) return '$base → $fim';
    return base;
  }

  /// Capítulos tocados por este trecho, como "Gênesis|1", "Gênesis|2"...
  Set<String> get capitulos {
    if (ehPagina || capIni <= 0) return {};
    final fim = capFim >= capIni ? capFim : capIni;
    return {for (var c = capIni; c <= fim && c - capIni < 400; c++) '$parte|$c'};
  }

  /// Páginas lidas neste trecho (só livro simples).
  int get paginas => ehPagina && pagFim > pagIni ? pagFim - pagIni : 0;
}
