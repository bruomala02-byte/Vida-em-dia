/// Uma sessão de leitura salva no celular.
class SessaoLeitura {
  final DateTime data; // início
  final DateTime? fim;
  final String livro;
  final int? livroId;
  final int segundos;
  final int paginaInicio;
  final int paginaFim;
  final String nota;

  const SessaoLeitura({
    required this.data,
    this.fim,
    required this.livro,
    this.livroId,
    required this.segundos,
    this.paginaInicio = 0,
    this.paginaFim = 0,
    this.nota = '',
  });

  int get paginasLidas =>
      paginaFim > paginaInicio ? paginaFim - paginaInicio : 0;

  DateTime get fimEfetivo => fim ?? data.add(Duration(seconds: segundos));

  Map<String, dynamic> toJson() => {
        'data': data.toIso8601String(),
        'fim': fim?.toIso8601String(),
        'livro': livro,
        'lid': livroId,
        's': segundos,
        'pi': paginaInicio,
        'pf': paginaFim,
        'nota': nota,
      };

  // Sessões antigas (sem livro cadastrado) continuam abrindo normalmente.
  factory SessaoLeitura.fromJson(Map<String, dynamic> j) => SessaoLeitura(
        data: DateTime.parse(j['data'] as String),
        fim: j['fim'] == null ? null : DateTime.parse(j['fim'] as String),
        livro: j['livro'] as String,
        livroId: j['lid'] as int?,
        segundos: j['s'] as int,
        paginaInicio: (j['pi'] as num?)?.toInt() ?? 0,
        paginaFim: (j['pf'] as num?)?.toInt() ?? 0,
        nota: (j['nota'] as String?) ?? '',
      );
}
