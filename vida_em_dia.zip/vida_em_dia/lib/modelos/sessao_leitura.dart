import 'trecho.dart';

/// Uma sessão de leitura salva no celular.
class SessaoLeitura {
  final DateTime data; // início
  final DateTime? fim;
  final String livro;
  final int? livroId;
  final int segundos;
  final int paginaInicio;
  final int paginaFim;
  final String nota;
  final List<Trecho> trechos; // o 1º é a leitura principal; os outros, trechos extras

  const SessaoLeitura({
    required this.data,
    this.fim,
    required this.livro,
    this.livroId,
    required this.segundos,
    this.paginaInicio = 0,
    this.paginaFim = 0,
    this.nota = '',
    this.trechos = const [],
  });

  int get paginasLidas {
    if (trechos.isNotEmpty) {
      final soma = trechos.fold<int>(0, (a, t) => a + t.paginas);
      if (soma > 0) return soma;
    }
    return paginaFim > paginaInicio ? paginaFim - paginaInicio : 0;
  }

  /// Capítulos tocados nesta sessão (livros com divisões).
  Set<String> get capitulos => {for (final t in trechos) ...t.capitulos};

  DateTime get fimEfetivo => fim ?? data.add(Duration(seconds: segundos));

  Map<String, dynamic> toJson() => {
        'data': data.toIso8601String(),
        'fim': fim?.toIso8601String(),
        'livro': livro,
        'lid': livroId,
        's': segundos,
        'pi': paginaInicio,
        'pf': paginaFim,
        'nota': nota,
        't': trechos.map((t) => t.toJson()).toList(),
      };

  // Sessões antigas (sem livro cadastrado) continuam abrindo normalmente.
  factory SessaoLeitura.fromJson(Map<String, dynamic> j) => SessaoLeitura(
        data: DateTime.parse(j['data'] as String),
        fim: j['fim'] == null ? null : DateTime.parse(j['fim'] as String),
        livro: j['livro'] as String,
        livroId: j['lid'] as int?,
        segundos: j['s'] as int,
        paginaInicio: (j['pi'] as num?)?.toInt() ?? 0,
        paginaFim: (j['pf'] as num?)?.toInt() ?? 0,
        nota: (j['nota'] as String?) ?? '',
        trechos: ((j['t'] as List?) ?? [])
            .map((e) => Trecho.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList(),
      );
}
