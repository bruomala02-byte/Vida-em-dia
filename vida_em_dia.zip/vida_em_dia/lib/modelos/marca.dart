/// Um ponto marcado à mão no mapa quando o GPS ficou sem sinal.
/// [retorno] = ponto fixo onde a pessoa pretende voltar ao percurso.
/// [metros] = trecho somado até este ponto (0 no ponto de retorno).
/// [verificada] = o GPS confirmou que a pessoa passou por aqui.
class Marca {
  final double lat, lng;
  final bool retorno;
  final double metros;
  final int grupo; // qual queda de sinal (0, 1, 2...)
  bool verificada;

  Marca(this.lat, this.lng,
      {this.retorno = false, this.metros = 0, this.verificada = false, this.grupo = 0});

  List<num> toJson() => [lat, lng, verificada ? 1 : 0, metros, retorno ? 1 : 0, grupo];

  factory Marca.fromJson(List j) => Marca(
        (j[0] as num).toDouble(),
        (j[1] as num).toDouble(),
        verificada: (j[2] as num) == 1,
        metros: (j[3] as num).toDouble(),
        retorno: (j[4] as num) == 1,
        grupo: j.length > 5 ? (j[5] as num).toInt() : 0,
      );
}
