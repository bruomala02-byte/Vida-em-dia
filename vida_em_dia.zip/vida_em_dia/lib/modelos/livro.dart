/// Um livro cadastrado. A página atual vem da última leitura salva.
class Livro {
  final int id;
  final String titulo;
  final String autor;
  final int totalPaginas; // 0 = não informado
  final DateTime criado;

  const Livro({
    required this.id,
    required this.titulo,
    this.autor = '',
    this.totalPaginas = 0,
    required this.criado,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'titulo': titulo,
        'autor': autor,
        'total': totalPaginas,
        'criado': criado.toIso8601String(),
      };

  factory Livro.fromJson(Map<String, dynamic> j) => Livro(
        id: j['id'] as int,
        titulo: j['titulo'] as String,
        autor: (j['autor'] as String?) ?? '',
        totalPaginas: (j['total'] as num?)?.toInt() ?? 0,
        criado: DateTime.parse(j['criado'] as String),
      );
}
