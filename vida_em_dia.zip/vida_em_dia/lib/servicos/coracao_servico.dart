import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';

import '../core/armazenamento.dart';

/// O coração do ícone do app.
///
/// Começa cheio (100%). Cada dia fechado sem nenhum registro tira 10%; cada dia
/// com algum registro devolve 10%. Em 0% ele fica vazio e, no 11º dia seguido
/// sem uso, quebra. Ao voltar a usar, ele conserta e começa a subir de novo.
///
/// Conta como "uso" registrar algo no app (corrida, água, sono, peso, leitura,
/// estudo, observação ou lançamento). Só abrir o app não conta.
///
/// O ícone é trocado quando o app vai para o fundo (é o jeito mais seguro:
/// em alguns celulares a tela inicial pisca ao trocar o ícone).
class CoracaoServico {
  static const _canal = MethodChannel('alvovita/icone');

  /// Nomes na ordem dos 12 ícones (100%, 90% ... 0%, quebrado).
  static const rotulos = [
    '100%', '90%', '80%', '70%', '60%', '50%', '40%', '30%', '20%', '10%', '0%', 'quebrado',
  ];

  static const _kNivel = 'cor_nivel'; // 0..10 (10 = 100%), contado até ontem
  static const _kQuebrado = 'cor_quebrado'; // 0 ou 1
  static const _kUltimo = 'cor_ultimo'; // último dia já contado (aaaammdd)
  static const _kLigado = 'cor_ligado'; // 0 ou 1
  static const _kIcone = 'cor_icone2'; // ícone aplicado agora (0..23)
  static const _kFormato = 'cor_formato'; // 0 = coração solto, 1 = coração com fundo

  /// Formato padrão por marca do celular (0 = solto, 1 = com fundo).
  /// É só ajustar esta tabela depois dos testes em cada marca.
  static const _padraoPorMarca = <String, int>{
    'xiaomi': 0,
    'redmi': 0,
    'poco': 0,
    'samsung': 0,
    'motorola': 0,
  };

  /// Marca detectada no celular (para mostrar nas Configurações).
  static String marca = '';

  static bool _iniciado = false;

  /// Liga o "olhar" do app: quando ele vai para o fundo, atualiza o ícone.
  static void iniciar() {
    if (_iniciado) return;
    _iniciado = true;
    WidgetsBinding.instance.addObserver(_Observador());
    _processar(); // só calcula, não troca o ícone agora
    _detectarMarca();
  }

  /// Na primeira vez, escolhe o formato mais seguro para a marca do celular.
  static Future<void> _detectarMarca() async {
    try {
      final m = await _canal.invokeMethod<String>('marca');
      marca = (m ?? '').trim();
    } catch (_) {
      return;
    }
    if (Armazenamento.lerInt(_kFormato) == null) {
      final padrao = _padraoPorMarca[marca.toLowerCase()] ?? 0;
      await Armazenamento.salvarInt(_kFormato, padrao, avisar: false);
      await atualizarIcone();
    }
  }

  /// 0 = coração solto, 1 = coração com fundo.
  static int get formato => Armazenamento.lerInt(_kFormato) ?? 0;

  static Future<void> definirFormato(int f) async {
    await Armazenamento.salvarInt(_kFormato, f, avisar: false);
    await atualizarIcone();
  }

  static bool get ligado => (Armazenamento.lerInt(_kLigado) ?? 1) == 1;

  static Future<void> definirLigado(bool v) async {
    await Armazenamento.salvarInt(_kLigado, v ? 1 : 0, avisar: false);
    await atualizarIcone();
  }

  static int _chave(DateTime d) => d.year * 10000 + d.month * 100 + d.day;

  static DateTime _deChave(int k) => DateTime(k ~/ 10000, (k ~/ 100) % 100, k % 100);

  /// Dias em que a pessoa registrou alguma coisa.
  static Set<int> _diasComRegistro() {
    final dias = <int>{};
    for (final t in Armazenamento.treinos()) {
      dias.add(_chave(t.data));
    }
    for (final l in Armazenamento.leituras()) {
      dias.add(_chave(l.data));
    }
    for (final lista in const [
      'estudos', 'agua', 'sono', 'pesos', 'lancamentos', 'observacoes',
    ]) {
      for (final e in Armazenamento.lista(lista)) {
        final txt = e['data'];
        if (txt is! String) continue;
        final d = DateTime.tryParse(txt);
        if (d != null) dias.add(_chave(d));
      }
    }
    return dias;
  }

  /// Conta os dias que já fecharam e devolve como o coração está hoje:
  /// (índice do ícone de 0 a 11, porcentagem, quebrado?).
  static (int, int, bool) _processar() {
    final agora = DateTime.now();
    final hoje = DateTime(agora.year, agora.month, agora.day);
    final registros = _diasComRegistro();

    var nivel = Armazenamento.lerInt(_kNivel) ?? 10;
    var quebrado = (Armazenamento.lerInt(_kQuebrado) ?? 0) == 1;
    final ultimo = Armazenamento.lerInt(_kUltimo);

    if (ultimo != null) {
      var d = _deChave(ultimo).add(const Duration(days: 1));
      d = DateTime(d.year, d.month, d.day);
      var voltas = 0;
      while (d.isBefore(hoje) && voltas < 4000) {
        if (registros.contains(_chave(d))) {
          if (quebrado) {
            quebrado = false;
            nivel = 1;
          } else {
            nivel = nivel + 1 > 10 ? 10 : nivel + 1;
          }
        } else if (nivel > 0) {
          nivel -= 1;
        } else {
          quebrado = true;
        }
        d = DateTime(d.year, d.month, d.day + 1);
        voltas++;
      }
    }
    final ontem = DateTime(hoje.year, hoje.month, hoje.day - 1);
    Armazenamento.salvarInt(_kNivel, nivel, avisar: false);
    Armazenamento.salvarInt(_kQuebrado, quebrado ? 1 : 0, avisar: false);
    Armazenamento.salvarInt(_kUltimo, _chave(ontem), avisar: false);

    // O dia de hoje já conta na tela: registrou algo, o coração sobe.
    var exibido = nivel;
    var qExibido = quebrado;
    if (registros.contains(_chave(hoje))) {
      if (quebrado) {
        qExibido = false;
        exibido = 1;
      } else {
        exibido = nivel + 1 > 10 ? 10 : nivel + 1;
      }
    }
    final indice = qExibido ? 11 : 10 - exibido;
    return (indice, qExibido ? 0 : exibido * 10, qExibido);
  }

  /// Como o coração está agora (para mostrar nas Configurações).
  static ({int percentual, bool quebrado}) estado() {
    final (_, pct, q) = _processar();
    return (percentual: pct, quebrado: q);
  }

  /// Troca o ícone do app pelo do nível atual (se mudou).
  static Future<void> atualizarIcone() async {
    final (indice, _, _) = _processar();
    final alvo = (ligado ? indice : 0) + (formato == 1 ? 12 : 0);
    if ((Armazenamento.lerInt(_kIcone) ?? 0) == alvo) return;
    try {
      final ok = await _canal.invokeMethod<bool>('definir', {'indice': alvo});
      if (ok == true) {
        await Armazenamento.salvarInt(_kIcone, alvo, avisar: false);
      }
    } catch (_) {
      // sem a parte nativa (ex.: teste fora do Android): ignora
    }
  }
}

class _Observador with WidgetsBindingObserver {
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      CoracaoServico.atualizarIcone();
    }
  }
}
