import 'package:android_intent_plus/android_intent.dart';

/// Cria alarmes no app Relógio do próprio celular.
/// Assim o despertador toca mesmo com o Alvo Vita fechado.
class AlarmeServico {
  /// Cria um alarme que repete todos os dias. Devolve false se o celular não deixou.
  static Future<bool> criar({
    required int hora,
    required int minuto,
    required String rotulo,
  }) async {
    final base = <String, dynamic>{
      'android.intent.extra.alarm.HOUR': hora,
      'android.intent.extra.alarm.MINUTES': minuto,
      'android.intent.extra.alarm.MESSAGE': rotulo,
      'android.intent.extra.alarm.DAYS': <int>[1, 2, 3, 4, 5, 6, 7],
    };
    // 1ª tentativa: cria direto, sem abrir o Relógio.
    try {
      await AndroidIntent(
        action: 'android.intent.action.SET_ALARM',
        arguments: {...base, 'android.intent.extra.alarm.SKIP_UI': true},
      ).launch();
      return true;
    } catch (_) {}
    // 2ª tentativa: abre o Relógio já com o horário preenchido.
    try {
      await AndroidIntent(
        action: 'android.intent.action.SET_ALARM',
        arguments: base,
      ).launch();
      return true;
    } catch (_) {
      return false;
    }
  }
}
