import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';

/// Cuida de tudo que é GPS: pedir permissão e receber as posições.
/// Fica separado da tela para o código ficar limpo e fácil de testar.
class GpsServico {
  StreamSubscription<Position>? _assinatura;

  /// Retorna `null` se está tudo certo, ou uma mensagem de erro em português.
  Future<String?> pedirPermissao() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      return 'Ligue o GPS do celular para registrar a corrida.';
    }

    var permissao = await Geolocator.checkPermission();
    if (permissao == LocationPermission.denied) {
      permissao = await Geolocator.requestPermission();
    }
    if (permissao == LocationPermission.denied) {
      return 'Sem a permissão de localização não dá para medir os km.';
    }
    if (permissao == LocationPermission.deniedForever) {
      return 'A permissão está bloqueada. Libere nas configurações do app.';
    }
    return null;
  }

  /// Começa a escutar o GPS. A cada ~5 metros chama [aoReceber].
  void iniciar(void Function(Position) aoReceber) {
    _assinatura = Geolocator.getPositionStream(
      locationSettings: defaultTargetPlatform != TargetPlatform.android
          ? AppleSettings(
              accuracy: LocationAccuracy.best,
              distanceFilter: 5,
              activityType: ActivityType.fitness,
            )
          : AndroidSettings(
        accuracy: LocationAccuracy.best,
        distanceFilter: 5,
        // Notificação que mantém o GPS funcionando com a tela apagada.
        foregroundNotificationConfig: const ForegroundNotificationConfig(
          notificationTitle: 'Corrida em andamento',
          notificationText: 'Vida em Dia está registrando seu percurso',
          enableWakeLock: true,
        ),
      ),
    ).listen(aoReceber);
  }

  void parar() {
    _assinatura?.cancel();
    _assinatura = null;
  }
}
