# Alvo Vita 🏃📖💚💰

App de celular (Android e iPhone) com:

- **Corrida** com GPS: km, tempo, ritmo e histórico
- **Saúde**: Corpo (água, sono, peso) e Mente (leitura: cronômetro por livro e meta diária)
- **Corrida**: mapa de ruas (OpenStreetMap) ao vivo, resumo com abas (Resumo, Gráficos, Detalhes), calorias, ritmo min/km, parciais por km
- **Finanças**: entradas, saídas, categorias e saldo do mês
- **Hoje**: resumo do seu dia

## Estrutura das pastas

```
lib/
├── main.dart                  ← ponto de partida do app
├── core/
│   ├── tema.dart              ← cores e visual
│   ├── formatos.dart          ← tempo, ritmo, datas
│   └── armazenamento.dart     ← salva tudo no celular
├── modelos/
│   ├── treino.dart
│   └── sessao_leitura.dart
├── servicos/
│   └── gps_servico.dart       ← permissão e leitura do GPS
├── widgets/
│   └── cartao_metrica.dart    ← cartão reutilizável
└── telas/
    ├── navegacao.dart         ← barra de baixo com as 5 abas
    ├── hoje_tela.dart
    ├── corrida_tela.dart
    ├── leitura_tela.dart
    ├── saude_tela.dart
    ├── financas_tela.dart
    └── em_breve_tela.dart
```

## Como rodar (passo a passo)

1. Instale o **Flutter**: https://docs.flutter.dev/get-started/install
   e o **Android Studio** (ele traz o Android SDK).
2. No terminal, crie o projeto base:
   ```
   flutter create --org com.seunome --project-name vida_em_dia vida_em_dia
   ```
3. Dentro da pasta `vida_em_dia` criada, **substitua**:
   - a pasta `lib/` pela `lib/` deste projeto
   - o arquivo `pubspec.yaml` pelo deste projeto
4. Rode `flutter pub get`.
5. Adicione as permissões de GPS (próxima seção).
6. Ligue o celular no PC com **Depuração USB** ativada e rode:
   ```
   flutter run
   ```

## Permissões do Android (obrigatório para o GPS)

Abra `android/app/src/main/AndroidManifest.xml` e coloque estas linhas
**logo acima** da tag `<application ...>`:

```xml
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
<uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_LOCATION"/>
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
<uses-permission android:name="android.permission.WAKE_LOCK"/>
```

## Próximos passos

1. Testar a corrida de verdade na rua e ajustar a precisão
2. Módulo Saúde (água, sono, passos, peso)
3. Módulo Finanças (entradas, saídas, resumo do mês)
4. Mapa do percurso e gráficos
5. Ícone, nome final, política de privacidade e publicação no Google Play

## Aviso

Este código foi escrito sem poder rodar o Flutter no ambiente de criação,
então pode aparecer algum erro pequeno na primeira execução. Se aparecer,
copie a mensagem de erro e me mande que eu corrijo.

## Novidades
- **Leitura por livro** (Saúde > Mente): cadastre o livro (autor e total de páginas opcionais), toque nele para ver o histórico por dia e o desempenho do mês, e use "Continuar de onde parou". Ao finalizar, informe a página e uma anotação (ex.: "3 capítulos").
- **Marcador de Livros**: tela de leitura em andamento com cronômetro HH:MM:SS.
- **Cor do app**: ícone de paleta na tela Hoje abre a roda de cores. A cor escolhida fica salva no celular.

## Novidades da versão 0.2.0

- **Histórico e check-in:** na tela Hoje (ícone de relógio) dá para salvar o resumo
  de cada mês em um arquivo e apagar os dados daquele mês.
- **Aviso de histórico grande:** o app avisa antes de ficar pesado.
- **Cronômetro da corrida** mais preciso (conta o tempo real, mesmo com a tela apagada).
- **Metas editáveis:** água e leitura (toque no cartão na tela Hoje).
- **Apagar treino:** segure o dedo sobre o treino. Também dá para desfazer o último sono e peso.
- Novo nome: **Alvo Vita**.
