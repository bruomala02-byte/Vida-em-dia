# Vida em Dia 🏃📖💚💰

App de celular (Android e iPhone) com:

- **Corrida** com GPS: km, tempo, ritmo e histórico
- **Leitura**: cronômetro por livro e meta diária
- **Saúde** e **Finanças**: telas de prévia (próximas etapas)
- **Hoje**: resumo do seu dia

## Estrutura das pastas

```
lib/
├── main.dart                  ← ponto de partida do app
├── core/
│   ├── tema.dart              ← cores e visual
│   ├── formatos.dart          ← tempo, ritmo, datas
│   └── armazenamento.dart     ← salva tudo no celular
├── modelos/
│   ├── treino.dart
│   └── sessao_leitura.dart
├── servicos/
│   └── gps_servico.dart       ← permissão e leitura do GPS
├── widgets/
│   └── cartao_metrica.dart    ← cartão reutilizável
└── telas/
    ├── navegacao.dart         ← barra de baixo com as 5 abas
    ├── hoje_tela.dart
    ├── corrida_tela.dart
    ├── leitura_tela.dart
    ├── saude_tela.dart
    ├── financas_tela.dart
    └── em_breve_tela.dart
```

## Como rodar (passo a passo)

1. Instale o **Flutter**: https://docs.flutter.dev/get-started/install
   e o **Android Studio** (ele traz o Android SDK).
2. No terminal, crie o projeto base:
   ```
   flutter create --org com.seunome --project-name vida_em_dia vida_em_dia
   ```
3. Dentro da pasta `vida_em_dia` criada, **substitua**:
   - a pasta `lib/` pela `lib/` deste projeto
   - o arquivo `pubspec.yaml` pelo deste projeto
4. Rode `flutter pub get`.
5. Adicione as permissões de GPS (próxima seção).
6. Ligue o celular no PC com **Depuração USB** ativada e rode:
   ```
   flutter run
   ```

## Permissões do Android (obrigatório para o GPS)

Abra `android/app/src/main/AndroidManifest.xml` e coloque estas linhas
**logo acima** da tag `<application ...>`:

```xml
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
<uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_LOCATION"/>
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
<uses-permission android:name="android.permission.WAKE_LOCK"/>
```

## Próximos passos

1. Testar a corrida de verdade na rua e ajustar a precisão
2. Módulo Saúde (água, sono, passos, peso)
3. Módulo Finanças (entradas, saídas, resumo do mês)
4. Mapa do percurso e gráficos
5. Ícone, nome final, política de privacidade e publicação no Google Play

## Aviso

Este código foi escrito sem poder rodar o Flutter no ambiente de criação,
então pode aparecer algum erro pequeno na primeira execução. Se aparecer,
copie a mensagem de erro e me mande que eu corrijo.
