# Alvo Vita 🏃📖💚💰

App de celular (Android e iPhone) com:

- **Corrida** com GPS: km, tempo, ritmo e histórico
- **Saúde**: Corpo (água, sono, peso) e Mente (leitura: cronômetro por livro e meta diária)
- **Corrida**: mapa de ruas (OpenStreetMap) ao vivo, resumo com abas (Resumo, Gráficos, Detalhes), calorias, ritmo min/km, parciais por km
- **Finanças**: entradas, saídas, categorias e saldo do mês
- **Hoje**: resumo do seu dia

## Estrutura das pastas

```
lib/
├── main.dart                  ← ponto de partida do app
├── core/
│   ├── tema.dart              ← cores e visual
│   ├── formatos.dart          ← tempo, ritmo, datas
│   └── armazenamento.dart     ← salva tudo no celular
├── modelos/
│   ├── treino.dart
│   └── sessao_leitura.dart
├── servicos/
│   └── gps_servico.dart       ← permissão e leitura do GPS
├── widgets/
│   └── cartao_metrica.dart    ← cartão reutilizável
└── telas/
    ├── navegacao.dart         ← barra de baixo com as 5 abas
    ├── hoje_tela.dart
    ├── corrida_tela.dart
    ├── leitura_tela.dart
    ├── saude_tela.dart
    ├── financas_tela.dart
    └── em_breve_tela.dart
```

## Como rodar (passo a passo)

1. Instale o **Flutter**: https://docs.flutter.dev/get-started/install
   e o **Android Studio** (ele traz o Android SDK).
2. No terminal, crie o projeto base:
   ```
   flutter create --org com.seunome --project-name vida_em_dia vida_em_dia
   ```
3. Dentro da pasta `vida_em_dia` criada, **substitua**:
   - a pasta `lib/` pela `lib/` deste projeto
   - o arquivo `pubspec.yaml` pelo deste projeto
4. Rode `flutter pub get`.
5. Adicione as permissões de GPS (próxima seção).
6. Ligue o celular no PC com **Depuração USB** ativada e rode:
   ```
   flutter run
   ```

## Permissões do Android (obrigatório para o GPS)

Abra `android/app/src/main/AndroidManifest.xml` e coloque estas linhas
**logo acima** da tag `<application ...>`:

```xml
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
<uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_LOCATION"/>
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
<uses-permission android:name="android.permission.WAKE_LOCK"/>
```

## Próximos passos

1. Testar a corrida de verdade na rua e ajustar a precisão
2. Módulo Saúde (água, sono, passos, peso)
3. Módulo Finanças (entradas, saídas, resumo do mês)
4. Mapa do percurso e gráficos
5. Ícone, nome final, política de privacidade e publicação no Google Play

## Aviso

Este código foi escrito sem poder rodar o Flutter no ambiente de criação,
então pode aparecer algum erro pequeno na primeira execução. Se aparecer,
copie a mensagem de erro e me mande que eu corrijo.

## Novidades
- **Leitura por livro** (Saúde > Mente): cadastre o livro (autor e total de páginas opcionais), toque nele para ver o histórico por dia e o desempenho do mês, e use "Continuar de onde parou". Ao finalizar, informe a página e uma anotação (ex.: "3 capítulos").
- **Marcador de Livros**: tela de leitura em andamento com cronômetro HH:MM:SS.
- **Cor do app**: ícone de paleta na tela Hoje abre a roda de cores. A cor escolhida fica salva no celular.

## Novidades da versão 0.3.0

- **Histórico e check-in:** na tela Hoje (ícone de relógio) dá para salvar o resumo
  de cada mês em um arquivo e apagar os dados daquele mês.
- **Aviso de histórico grande:** o app avisa antes de ficar pesado.
- **Cronômetro da corrida** mais preciso (conta o tempo real, mesmo com a tela apagada).
- **Metas editáveis:** água e leitura (toque no cartão na tela Hoje).
- **Apagar treino:** segure o dedo sobre o treino. Também dá para desfazer o último sono e peso.
- Novo nome: **Alvo Vita**.

## v0.4.0
- Estudos - Leitura (renomeado) com lembrete diário opcional.
- Corrida: modos Corrida (limite 22 km/h) e Ciclismo (limite 50 km/h); sem limite de distância.
- Relatórios em PDF/PNG (extrato de finanças e resumo geral) – diário, semanal e mensal.
- Imagem da corrida com mapa, percurso e resultados arrastáveis (PNG).
- Lembretes de água (10h, 12h e 18h, editáveis) com notificações.
- Ajustes de Android (permissões, notificações) em `tools/ajustar_android.py`.

## v0.5.0
- Modo Estudo (tipo, matéria e anotação opcionais) com histórico; total do dia soma estudo + leitura,
  com os dois separados; relatórios e check-in também mostram total e separado.
- GPS: espera sinal bom antes de começar, pausa automática, ritmo atual, aviso a cada km,
  calorias próprias para ciclismo, recuperação de corrida interrompida.
- Queda de sinal: notificações, marcação de rota e ponto de retorno no mapa, soma do trecho
  respeitando o limite de velocidade, alerta que vibra se o percurso marcado não for seguido.
- Corrida abre com zoom 90% (ajustável em Configurações).

## v0.6.0
- Livros: tipo "por páginas" ou "capítulos e versículos" (modelo Bíblia opcional com os 66 livros).
- Marcador de leitura com trechos (principal + outros), "continuar de onde parou", progresso do livro.
- Observações com negrito (leitura e estudo), planilha com busca e apagar; entram nos relatórios e no check-in.
- Sequência de dias estudando ou lendo.

## v0.6.1
- Observações: negrito com um toque no botão N (sem símbolos), marca-texto em 5 cores e etiqueta colorida opcional (Leitura).
- Observações salvas podem ser editadas (texto, negrito, cor, etiqueta). As antigas com ** são convertidas sozinhas.

## v0.6.2
- Assinatura fixa do APK (tools/alvo-vita.keystore): a partir daqui o app atualiza por cima, sem desinstalar e sem perder os dados.

## v0.7.0
- Imagem da corrida: botão "Mover os resultados (tela cheia)" (arrastar com liberdade, tocar para mudar o tamanho de cada um), ícone em cada resultado, caixa sólida, cor igual à dos botões, modelo "Principal" + até 10 modelos próprios, tabela de cores com seletor livre (inclui preto).
- Extratos separados por área (Corrida, Saúde, Estudos - Leitura, Finanças, Resumo geral) com zoom do conteúdo.
- Configurações: tamanho de textos, ícones e botões por tela, barra de baixo, prévia, "Mostrar meus valores".
- Ícone do app: coração Balão 3D com 12 estados (100% a 0% e quebrado), troca sozinho (tools/icones + ajustar_android.py).

## v0.8.0
- Botões de ação ~75% menores; dois grupos ajustáveis por tela (Ação e Outros) + "Tudo" (zoom da tela inteira) e "Mostrar meus valores".
- Imagem da corrida: modelo fixo "Principal" com os 9 resultados espalhados; seus modelos salvos continuam.
- Ícone do coração com dois formatos (Configurações): "Coração solto" e "Com fundo"; padrão escolhido pela marca do celular.

## v0.9.0
- Corrida: botão Começar/Pausar fixo embaixo (sempre visível); "Seus treinos" virou um cartão que abre a tela só dos treinos.
- Saúde: entrada com dois cartões (Corpo e Estudos - Leitura), cada um abre sua tela com seta de voltar.
- Sono: o app lembra quais alarmes já criou no Relógio e não repete.
- Lembretes de água/estudo: alarme exato (permissão de alarmes) para não atrasar.
- Imagem da corrida: fundo "Minha foto" (foto da galeria arrastável e com zoom, rota por cima que se move e muda de tamanho), fundo escuro refeito, e resultados em "Lista" (estilo pontilhado, com nome Alvo Vita).
- Gráficos e Detalhes do treino: ícones e cartões menores.
