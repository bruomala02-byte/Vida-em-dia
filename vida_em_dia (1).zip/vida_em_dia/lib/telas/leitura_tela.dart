import 'dart:async';

import 'package:flutter/material.dart';

import '../core/armazenamento.dart';
import '../core/formatos.dart';
import '../core/tema.dart';
import '../modelos/sessao_leitura.dart';

class LeituraTela extends StatefulWidget {
  const LeituraTela({super.key});

  @override
  State<LeituraTela> createState() => _LeituraTelaState();
}

class _LeituraTelaState extends State<LeituraTela> {
  static const metaDiariaMinutos = 30;

  final _livro = TextEditingController();
  Timer? _timer;
  int _segundos = 0;
  bool _lendo = false;

  void _comecar() {
    if (_livro.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Escreva o nome do livro primeiro 📖')),
      );
      return;
    }
    FocusScope.of(context).unfocus();
    setState(() => _lendo = true);
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      setState(() => _segundos++);
    });
  }

  void _pausar() {
    _timer?.cancel();
    setState(() => _lendo = false);
  }

  Future<void> _salvar() async {
    _timer?.cancel();
    final segundos = _segundos;
    final livro = _livro.text.trim();

    setState(() {
      _lendo = false;
      _segundos = 0;
    });

    if (segundos < 10) return; // sessão curtinha demais, ignora

    await Armazenamento.salvarLeitura(
      SessaoLeitura(data: DateTime.now(), livro: livro, segundos: segundos),
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Leitura salva: ${formatarTempo(segundos)} 📚')),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    _livro.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final estilo = Theme.of(context).textTheme;

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Text('Leitura', style: estilo.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 16),

        TextField(
          controller: _livro,
          enabled: !_lendo && _segundos == 0,
          textCapitalization: TextCapitalization.sentences,
          decoration: const InputDecoration(
            labelText: 'O que você está lendo?',
            prefixIcon: Icon(Icons.menu_book),
          ),
        ),
        const SizedBox(height: 16),

        Card(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 32),
            child: Center(
              child: Text(
                formatarTempo(_segundos),
                style: const TextStyle(
                  fontSize: 64,
                  fontWeight: FontWeight.w900,
                  color: Cores.leitura,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),

        if (!_lendo && _segundos == 0)
          FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: Cores.leitura),
            onPressed: _comecar,
            icon: const Icon(Icons.play_arrow),
            label: const Text('Começar a ler'),
          )
        else
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(backgroundColor: Cores.leitura),
                  onPressed: _lendo ? _pausar : _comecar,
                  icon: Icon(_lendo ? Icons.pause : Icons.play_arrow),
                  label: Text(_lendo ? 'Pausar' : 'Continuar'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton.tonalIcon(
                  onPressed: _salvar,
                  icon: const Icon(Icons.check),
                  label: const Text('Terminar'),
                ),
              ),
            ],
          ),

        const SizedBox(height: 28),

        // Meta do dia: barra de progresso.
        ValueListenableBuilder<int>(
          valueListenable: Armazenamento.mudou,
          builder: (context, _, __) {
            final hoje = Armazenamento.leituras()
                .where((s) => mesmoDia(s.data, DateTime.now()))
                .fold<int>(0, (soma, s) => soma + s.segundos);
            final minutos = hoje ~/ 60;
            final progresso = (minutos / metaDiariaMinutos).clamp(0.0, 1.0);

            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Meta de hoje', style: estilo.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                LinearProgressIndicator(
                  value: progresso,
                  minHeight: 12,
                  borderRadius: BorderRadius.circular(8),
                  color: Cores.leitura,
                ),
                const SizedBox(height: 6),
                Text(
                  minutos >= metaDiariaMinutos
                      ? 'Meta batida! $minutos min lidos 🎉'
                      : '$minutos de $metaDiariaMinutos min',
                ),
                const SizedBox(height: 24),
                Text('Últimas leituras', style: estilo.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                ..._historico(),
              ],
            );
          },
        ),
      ],
    );
  }

  List<Widget> _historico() {
    final lista = Armazenamento.leituras();
    if (lista.isEmpty) {
      return const [Text('Nenhuma leitura ainda. Que tal ler uns minutinhos? 📖')];
    }
    return [
      for (final s in lista.take(20))
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const CircleAvatar(
            backgroundColor: Color(0x266C5CE7),
            child: Icon(Icons.menu_book, color: Cores.leitura),
          ),
          title: Text(s.livro),
          subtitle: Text('${formatarData(s.data)} · ${formatarTempo(s.segundos)}'),
        ),
    ];
  }
}
