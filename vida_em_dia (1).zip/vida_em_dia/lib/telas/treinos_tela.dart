import 'package:flutter/material.dart';

import '../core/armazenamento.dart';
import '../core/formatos.dart';
import '../core/tema.dart';
import '../modelos/treino.dart';
import 'resumo_corrida_tela.dart';

/// Histórico só dos treinos de corrida e ciclismo.
class TreinosTela extends StatelessWidget {
  const TreinosTela({super.key});

  Future<void> _apagar(BuildContext context, Treino t) async {
    final apagar = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Apagar este treino?'),
        content: Text('${decimal(t.km)} km em ${formatarData(t.data)}. Não dá para desfazer.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Apagar')),
        ],
      ),
    );
    if (apagar == true) await Armazenamento.removerTreino(t);
  }

  @override
  Widget build(BuildContext context) {
    final estilo = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Seus treinos')),
      body: SafeArea(
        child: ValueListenableBuilder<int>(
          valueListenable: Armazenamento.mudou,
          builder: (context, _, __) {
            final treinos = Armazenamento.treinos();
            if (treinos.isEmpty) {
              return const Center(child: Text('Nenhum treino ainda. Bora fazer o primeiro? 🏃'));
            }
            return ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Text('Toque para ver os detalhes · segure para apagar', style: estilo.bodySmall),
                const SizedBox(height: 8),
                for (final t in treinos)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: CircleAvatar(
                      backgroundColor: context.destaque.withValues(alpha: 0.15),
                      child: Icon(t.ehBike ? Icons.directions_bike : Icons.directions_run,
                          color: context.destaque),
                    ),
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => ResumoCorridaTela(treino: t)),
                    ),
                    onLongPress: () => _apagar(context, t),
                    trailing: const Icon(Icons.chevron_right),
                    title: Text('${decimal(t.km)} km · ${t.calorias} kcal'),
                    subtitle: Text(
                      '${formatarData(t.data)} às ${formatarHora(t.data)} · '
                      '${formatarTempo(t.segundos)} · ${t.ehBike ? '${velocidadeMedia(t.km, t.segundos)} km/h' : '${formatarRitmo(t.km, t.segundos)} /km'}',
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }
}
