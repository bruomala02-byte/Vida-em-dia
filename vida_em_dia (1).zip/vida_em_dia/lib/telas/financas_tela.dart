import 'package:flutter/material.dart';

import '../core/tema.dart';
import 'em_breve_tela.dart';

class FinancasTela extends StatelessWidget {
  const FinancasTela({super.key});

  @override
  Widget build(BuildContext context) {
    return const EmBreveTela(
      titulo: 'Finanças',
      icone: Icons.account_balance_wallet,
      cor: Cores.financas,
      recursos: [
        'Registro de entradas e saídas',
        'Categorias (mercado, transporte, lazer...)',
        'Resumo do mês com gráfico',
        'Meta de economia',
      ],
    );
  }
}
