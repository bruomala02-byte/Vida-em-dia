import 'package:flutter/material.dart';

import '../core/armazenamento.dart';
import '../core/checkin.dart';
import '../core/formatos.dart';
import '../relatorios/folhas.dart';
import '../widgets/aviso_historico.dart';
import 'corrida_imagem_tela.dart';
import 'relatorio_tela.dart';

/// Histórico por mês: salvar o check-in (arquivo com o resumo) e apagar
/// meses antigos para o app e o celular não ficarem pesados.
class HistoricoTela extends StatelessWidget {
  const HistoricoTela({super.key});

  String _nome(int ano, int mes) => '${nomesMeses[mes - 1]} de $ano';

  String _tamanho() {
    final kb = Armazenamento.tamanhoHistorico() / 1000;
    return kb < 1000 ? '${kb.round()} KB' : '${decimal(kb / 1000, 1)} MB';
  }

  String _resumo(int ano, int mes) {
    final partes = <String>[];
    final corridas = Armazenamento.doMes('treinos', ano, mes).length;
    final leituras = Armazenamento.doMes('leituras', ano, mes).length;
    final estudos = Armazenamento.doMes('estudos', ano, mes).length;
    final saude = Armazenamento.doMes('agua', ano, mes).length +
        Armazenamento.doMes('sono', ano, mes).length +
        Armazenamento.doMes('pesos', ano, mes).length;
    final fin = Armazenamento.doMes('lancamentos', ano, mes).length;
    if (corridas > 0) partes.add('$corridas corrida(s)');
    if (leituras > 0) partes.add('$leituras leitura(s)');
    if (estudos > 0) partes.add('$estudos estudo(s)');
    if (saude > 0) partes.add('$saude registro(s) de saúde');
    if (fin > 0) partes.add('$fin lançamento(s)');
    return partes.join(' · ');
  }

  void _aviso(BuildContext context, String texto) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(texto)));
  }

  Future<void> _salvar(BuildContext context, int ano, int mes) async {
    final ok = await compartilharCheckin(ano, mes);
    if (!ok && context.mounted) {
      _aviso(context, 'Não consegui criar o arquivo do check-in. Tente de novo.');
    }
  }

  Future<void> _apagar(BuildContext context, int ano, int mes) async {
    final nome = _nome(ano, mes);
    final escolha = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Apagar $nome?'),
        content: const Text(
          'Isso apaga as corridas, leituras, estudos, registros de saúde e lançamentos '
          'deste mês. Não dá para desfazer.\n\n'
          'Quer salvar o check-in antes?',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, 'sem'),
            child: const Text('Apagar sem salvar'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, 'salvar'),
            child: const Text('Salvar e apagar'),
          ),
        ],
      ),
    );
    if (escolha == null || !context.mounted) return;

    if (escolha == 'salvar') {
      final ok = await compartilharCheckin(ano, mes);
      if (!context.mounted) return;
      if (!ok) {
        _aviso(context, 'Não consegui criar o arquivo. Nada foi apagado.');
        return;
      }
      // O celular não avisa se a pessoa realmente guardou o arquivo,
      // então perguntamos antes de apagar de verdade.
      final confirmou = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Você guardou o arquivo?'),
          content: Text(
            'Se o check-in de $nome já está salvo no seu celular (ou enviado '
            'para você), pode apagar os dados do mês.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Ainda não'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Sim, apagar'),
            ),
          ],
        ),
      );
      if (confirmou != true || !context.mounted) return;
    }

    await Armazenamento.apagarMes(ano, mes);
    if (context.mounted) _aviso(context, '$nome apagado.');
  }

  @override
  Widget build(BuildContext context) {
    final estilo = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(title: const Text('Histórico e check-in')),
      body: SafeArea(
        child: ValueListenableBuilder<int>(
          valueListenable: Armazenamento.mudou,
          builder: (context, _, __) {
            final meses = Armazenamento.mesesComDados();

            return ListView(
              padding: const EdgeInsets.all(20),
              children: [
                const AvisoHistorico(),
                if (Armazenamento.historicoGrande()) const SizedBox(height: 12),
                _Salvar(
                  titulo: 'Salvar relatório',
                  itens: [
                    _ItemSalvar(Icons.payments_outlined, 'Extrato de finanças',
                        'Tabela de entradas e saídas · PDF ou PNG',
                        () => const RelatorioTela(tipo: TipoRelatorio.financas)),
                    _ItemSalvar(Icons.table_chart_outlined, 'Resumo geral',
                        'Corrida, estudos, saúde e finanças em tabelas · PDF ou PNG',
                        () => const RelatorioTela(tipo: TipoRelatorio.geral)),
                    _ItemSalvar(Icons.map_outlined, 'Imagem da corrida',
                        'Mapa, percurso e resultados · PNG',
                        () => const CorridaImagemTela()),
                  ],
                ),
                const SizedBox(height: 12),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Como funciona',
                            style: estilo.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                        const SizedBox(height: 8),
                        const Text(
                          'O check-in é um arquivo com o resumo do mês. Você guarda no '
                          'celular (ou envia para você mesmo) e depois pode apagar os '
                          'dados daquele mês para o app continuar leve.',
                        ),
                        const SizedBox(height: 8),
                        Text('Espaço usado pelo histórico: ${_tamanho()}'),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                if (meses.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 24),
                    child: Text('Ainda não há nada guardado. Quando você usar o app, os meses aparecem aqui.'),
                  ),
                for (final (ano, mes) in meses) ...[
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(_nome(ano, mes),
                              style: estilo.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
                          const SizedBox(height: 4),
                          Text(_resumo(ano, mes)),
                          const SizedBox(height: 12),
                          Row(
                            children: [
                              Expanded(
                                child: OutlinedButton.icon(
                                  onPressed: () => _salvar(context, ano, mes),
                                  icon: const Icon(Icons.save_alt),
                                  label: const Text('Salvar check-in'),
                                ),
                              ),
                              const SizedBox(width: 8),
                              TextButton.icon(
                                style: TextButton.styleFrom(
                                  foregroundColor: Theme.of(context).colorScheme.error,
                                ),
                                onPressed: () => _apagar(context, ano, mes),
                                icon: const Icon(Icons.delete_outline),
                                label: const Text('Apagar'),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                ],
              ],
            );
          },
        ),
      ),
    );
  }
}

class _ItemSalvar {
  final IconData icone;
  final String titulo, subtitulo;
  final Widget Function() pagina;
  const _ItemSalvar(this.icone, this.titulo, this.subtitulo, this.pagina);
}

/// Cartão com as opções de salvar (diário, semanal ou mensal se escolhe dentro).
class _Salvar extends StatelessWidget {
  final String titulo;
  final List<_ItemSalvar> itens;
  const _Salvar({required this.titulo, required this.itens});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
              child: Text(titulo,
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(fontWeight: FontWeight.w700)),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 2, 16, 4),
              child: Text('Escolha diário, semanal ou mensal na próxima tela.',
                  style: TextStyle(fontSize: 12)),
            ),
            for (final i in itens)
              ListTile(
                dense: true,
                leading: Icon(i.icone),
                title: Text(i.titulo, style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(i.subtitulo),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.of(context)
                    .push(MaterialPageRoute(builder: (_) => i.pagina())),
              ),
          ],
        ),
      ),
    );
  }
}
