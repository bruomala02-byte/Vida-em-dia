import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/formatos.dart';
import '../core/tema.dart';
import '../modelos/treino.dart';
import '../widgets/cartao_metrica.dart';
import '../widgets/graficos_corrida.dart';
import '../widgets/icones_app.dart';
import '../widgets/mapa_percurso.dart';
import 'corrida_imagem_tela.dart';
import '../widgets/zoom_tela.dart';

/// Resumo de um treino, em 3 abas: Resumo, Gráficos e Detalhes.
class ResumoCorridaTela extends StatelessWidget {
  final Treino treino;
  const ResumoCorridaTela({super.key, required this.treino});

  Treino get _t => treino;

  void _compartilhar(BuildContext context) {
    final t = _t;
    final texto = 'Corrida de ${formatarData(t.data)}: ${decimal(t.km)} km em '
        '${formatarTempo(t.segundos)} · ritmo ${formatarRitmo(t.km, t.segundos)} min/km · '
        '${t.calorias} kcal 🏃 (Alvo Vita)';
    Clipboard.setData(ClipboardData(text: texto));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Resumo copiado! Cole onde quiser.')),
    );
  }

  Widget _stat(BuildContext context, TipoIcone icone, String valor, String rotulo) => Expanded(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconeApp(icone, tamanho: 24, cor: context.destaque),
            const SizedBox(height: 6),
            FittedBox(
              child: Text(valor,
                  style: const TextStyle(
                      fontSize: 22, fontWeight: FontWeight.w800, color: Colors.white)),
            ),
            Text(rotulo,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12, color: Colors.white70)),
          ],
        ),
      );

  Widget _cartaoGrafico(BuildContext context, String titulo, Widget grafico,
      {Widget? extra}) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Icon(Icons.bar_chart, color: context.destaque, size: 20),
              const SizedBox(width: 8),
              Expanded(
                child: Text(titulo,
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium
                        ?.copyWith(fontWeight: FontWeight.w700)),
              ),
              if (extra != null) extra,
            ]),
            const SizedBox(height: 12),
            SizedBox(height: 150, child: grafico),
          ],
        ),
      ),
    );
  }

  Widget _semDados() => const Center(child: Text('Sem dados suficientes'));

  // ---------------- Aba 1: Resumo ----------------
  Widget _abaResumo(BuildContext context, List<Amostra> vel) {
    final t = _t;
    final cs = Theme.of(context).colorScheme;
    final ritmos = [for (final a in vel) Amostra(a.km, ritmoDe(a.valor))];

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(children: [
          Icon(Icons.calendar_month, color: context.destaque),
          const SizedBox(width: 10),
          Text('${formatarData(t.data)}/${t.data.year}  •  ${formatarHora(t.data)}',
              style: Theme.of(context).textTheme.titleMedium),
        ]),
        const SizedBox(height: 12),
        ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: SizedBox(
            height: 430,
            child: Stack(children: [
              Positioned.fill(
                child: MapaPercurso(pontos: t.pontos, margemInferior: 160, marcas: t.marcas),
              ),
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: IgnorePointer(
                  child: Container(
                    padding: const EdgeInsets.fromLTRB(8, 40, 8, 14),
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.transparent, Color(0xE6000000)],
                      ),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        _stat(context, TipoIcone.pes, '${decimal(t.km)} km', 'Distância'),
                        _stat(context, TipoIcone.relogio, formatarTempo(t.segundos), 'Tempo total'),
                        _stat(context, TipoIcone.chama, '${t.calorias} kcal', 'Calorias'),
                        t.ehBike
                            ? _stat(context, TipoIcone.velocimetro,
                                velocidadeMedia(t.km, t.segundos), 'Velocidade\nmédia (km/h)')
                            : _stat(context, TipoIcone.velocimetro,
                                formatarRitmo(t.km, t.segundos), 'Ritmo médio\n(min/km)'),
                      ],
                    ),
                  ),
                ),
              ),
            ]),
          ),
        ),
        const SizedBox(height: 12),
        _cartaoGrafico(
          context,
          'Ritmo da corrida',
          ritmos.length < 2
              ? _semDados()
              : CustomPaint(
                  size: Size.infinite,
                  painter: GraficoLinhaPainter(
                    amostras: ritmos,
                    rotulo: ritmoTexto,
                    menorEmCima: true,
                    cor: context.destaque,
                    corTexto: cs.onSurface,
                  ),
                ),
          extra: const Text('min/km'),
        ),
      ],
    );
  }

  // ---------------- Aba 2: Gráficos ----------------
  Widget _abaGraficos(BuildContext context, List<Amostra> vel) {
    final cs = Theme.of(context).colorScheme;
    final alt = calcularAltitudes(_t.pontos);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _cartaoGrafico(
          context,
          'Velocidade',
          vel.length < 2
              ? _semDados()
              : CustomPaint(
                  size: Size.infinite,
                  painter: GraficoLinhaPainter(
                    amostras: vel,
                    rotulo: (v) => v.toStringAsFixed(0),
                    menorEmCima: false,
                    cor: context.destaque,
                    corTexto: cs.onSurface,
                  ),
                ),
          extra: const Text('km/h'),
        ),
        const SizedBox(height: 12),
        _cartaoGrafico(
          context,
          'Elevação',
          alt.length < 2
              ? _semDados()
              : CustomPaint(
                  size: Size.infinite,
                  painter: GraficoLinhaPainter(
                    amostras: alt,
                    rotulo: (v) => '${v.round()} m',
                    menorEmCima: false,
                    cor: context.destaque,
                    corTexto: cs.onSurface,
                  ),
                ),
          extra: Text('+${_t.elevacao.round()} m'),
        ),
      ],
    );
  }

  // ---------------- Aba 3: Detalhes ----------------
  Widget _abaDetalhes(BuildContext context, List<Amostra> vel) {
    final t = _t;
    final kmh = t.segundos > 0 ? t.km / (t.segundos / 3600) : 0.0;
    final melhor = vel.isEmpty
        ? '--:--'
        : ritmoTexto(ritmoDe(vel.map((a) => a.valor).reduce((a, b) => a > b ? a : b)));
    final parciais = calcularParciais(t.pontos);
    final velParcial = [
      for (final p in parciais) p.segundos > 0 ? p.km / (p.segundos / 3600) : 0.0
    ];
    final maxVel = velParcial.isEmpty ? 1.0 : velParcial.reduce((a, b) => a > b ? a : b);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(children: [
          Expanded(
            child: CartaoMetrica(
              icone: Icons.bolt,
              titulo: 'Velocidade máxima',
              valor: '${decimal(t.velMaxKmh, 1)} km/h',
              cor: context.destaque,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: CartaoMetrica(
              icone: Icons.speed,
              titulo: 'Velocidade média',
              valor: '${decimal(kmh, 1)} km/h',
              cor: context.destaque,
            ),
          ),
        ]),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(
            child: CartaoMetrica(
              icone: Icons.emoji_events,
              titulo: 'Melhor ritmo (min/km)',
              valor: melhor,
              cor: context.destaque,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: CartaoMetrica(
              icone: Icons.terrain,
              titulo: 'Elevação (subida)',
              valor: '${t.elevacao.round()} m',
              cor: context.destaque,
            ),
          ),
        ]),
        const SizedBox(height: 20),
        Text('Parciais por km',
            style: Theme.of(context)
                .textTheme
                .titleLarge
                ?.copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        if (parciais.isEmpty)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 12),
            child: Text('Sem percurso gravado neste treino.'),
          ),
        for (var i = 0; i < parciais.length; i++)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Row(children: [
              SizedBox(
                width: 64,
                child: Text(
                  parciais[i].km >= 1 ? 'Km ${i + 1}' : '${decimal(parciais[i].km)} km',
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
              Expanded(
                child: LinearProgressIndicator(
                  value: maxVel > 0 ? velParcial[i] / maxVel : 0,
                  minHeight: 12,
                  borderRadius: BorderRadius.circular(8),
                  color: context.destaque,
                ),
              ),
              SizedBox(
                width: 70,
                child: Text(
                  formatarRitmo(parciais[i].km, parciais[i].segundos),
                  textAlign: TextAlign.end,
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
            ]),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final vel = calcularVelocidades(_t.pontos);

    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Corrida'),
          actions: [
            IconButton(
              tooltip: 'Salvar imagem com o mapa',
              icon: const Icon(Icons.image_outlined),
              onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                builder: (_) => CorridaImagemTela(treino: _t),
              )),
            ),
            IconButton(
              icon: const Icon(Icons.share),
              onPressed: () => _compartilhar(context),
            ),
          ],
          bottom: const TabBar(
            tabs: [Tab(text: 'Resumo'), Tab(text: 'Gráficos'), Tab(text: 'Detalhes')],
          ),
        ),
        body: TabBarView(
          children: [
            _abaResumo(context, vel),
            _abaGraficos(context, vel),
            _abaDetalhes(context, vel),
          ],
        ),
        bottomNavigationBar: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: Row(children: [
              Expanded(
                child: OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                    minimumSize: Size.fromHeight(context.altSec(44)),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                  ),
                  onPressed: () => _compartilhar(context),
                  icon: const Icon(Icons.share),
                  label: const Text('Compartilhar'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton(
                  style: FilledButton.styleFrom(backgroundColor: context.destaque),
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Concluído'),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}
