import 'package:flutter/material.dart';

import '../core/config.dart';
import '../widgets/escolher_cor.dart';
import 'historico_tela.dart';

/// Configurações: aparência (modo escuro, cor) e zoom de cada tela.
class ConfigTela extends StatelessWidget {
  const ConfigTela({super.key});

  @override
  Widget build(BuildContext context) {
    final estilo = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(title: const Text('Configurações')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text('Aparência',
                style: estilo.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            ValueListenableBuilder<ThemeMode>(
              valueListenable: Config.modoTema,
              builder: (context, modo, _) => SizedBox(
                width: double.infinity,
                child: SegmentedButton<ThemeMode>(
                  segments: const [
                    ButtonSegment(value: ThemeMode.system, label: Text('Sistema')),
                    ButtonSegment(value: ThemeMode.light, label: Text('Claro')),
                    ButtonSegment(value: ThemeMode.dark, label: Text('Escuro')),
                  ],
                  selected: {modo},
                  onSelectionChanged: (s) => Config.definirModo(s.first),
                ),
              ),
            ),
            const SizedBox(height: 4),
            Text('O modo escuro é preto, com textos brancos e ícones na cor escolhida.',
                style: estilo.bodySmall),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.palette_outlined),
              title: const Text('Cor do app'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => showModalBottomSheet(
                context: context,
                isScrollControlled: true,
                showDragHandle: true,
                builder: (_) => const EscolherCor(),
              ),
            ),
            const Divider(),
            const SizedBox(height: 8),
            Text('Zoom de cada tela',
                style: estilo.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
            Text('Teste e veja qual tamanho fica melhor. Depois é só me dizer os valores.',
                style: estilo.bodySmall),
            for (final t in Config.telas)
              ValueListenableBuilder<int>(
                valueListenable: Config.zoom[t]!,
                builder: (context, p, _) => Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 8),
                    Text('${Config.rotulos[t]}: $p%',
                        style: const TextStyle(fontWeight: FontWeight.w700)),
                    Slider(
                      value: p.toDouble(),
                      min: Config.zoomMin.toDouble(),
                      max: Config.zoomMax.toDouble(),
                      divisions: Config.zoomMax - Config.zoomMin,
                      label: '$p%',
                      onChanged: (v) => Config.definirZoom(t, v.round()),
                    ),
                  ],
                ),
              ),
            TextButton.icon(
              onPressed: Config.restaurarZoom,
              icon: const Icon(Icons.restart_alt),
              label: const Text('Restaurar zoom padrão'),
            ),
            const Divider(),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.history),
              title: const Text('Histórico e check-in'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context)
                  .push(MaterialPageRoute(builder: (_) => const HistoricoTela())),
            ),
          ],
        ),
      ),
    );
  }
}
