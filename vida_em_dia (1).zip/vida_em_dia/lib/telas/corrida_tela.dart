import 'dart:async';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

import '../core/armazenamento.dart';
import '../core/formatos.dart';
import '../core/tema.dart';
import '../modelos/treino.dart';
import '../servicos/gps_servico.dart';

enum _Estado { parado, correndo, pausado }

class CorridaTela extends StatefulWidget {
  const CorridaTela({super.key});

  @override
  State<CorridaTela> createState() => _CorridaTelaState();
}

class _CorridaTelaState extends State<CorridaTela> {
  final _gps = GpsServico();
  _Estado _estado = _Estado.parado;
  double _metros = 0;
  int _segundos = 0;
  Position? _ultima;
  Timer? _timer;
  String? _erro;

  double get _km => _metros / 1000;

  Future<void> _iniciar() async {
    final erro = await _gps.pedirPermissao();
    if (erro != null) {
      setState(() => _erro = erro);
      return;
    }
    setState(() {
      _erro = null;
      _estado = _Estado.correndo;
      _metros = 0;
      _segundos = 0;
      _ultima = null;
    });
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (_estado == _Estado.correndo) setState(() => _segundos++);
    });
    _gps.iniciar(_aoReceberPosicao);
  }

  void _aoReceberPosicao(Position p) {
    if (_estado != _Estado.correndo) return;
    // Ignora leituras ruins do GPS (muito imprecisas).
    if (p.accuracy > 30) return;
    if (_ultima != null) {
      _metros += Geolocator.distanceBetween(
        _ultima!.latitude,
        _ultima!.longitude,
        p.latitude,
        p.longitude,
      );
    }
    _ultima = p;
    setState(() {});
  }

  void _pausar() => setState(() => _estado = _Estado.pausado);

  void _retomar() {
    // Zera a última posição para não "pular" a distância percorrida na pausa.
    _ultima = null;
    setState(() => _estado = _Estado.correndo);
  }

  Future<void> _finalizar() async {
    _timer?.cancel();
    _gps.parar();

    final km = _km;
    final segundos = _segundos;

    setState(() {
      _estado = _Estado.parado;
      _metros = 0;
      _segundos = 0;
      _ultima = null;
    });

    if (km < 0.01) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Percurso muito curto, não foi salvo.')),
      );
      return;
    }

    await Armazenamento.salvarTreino(
      Treino(data: DateTime.now(), km: km, segundos: segundos),
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Treino salvo: ${km.toStringAsFixed(2)} km 🎉')),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    _gps.parar();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final estilo = Theme.of(context).textTheme;

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Text('Corrida', style: estilo.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 16),

        // Painel principal: km em destaque, tempo e ritmo embaixo.
        Card(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 20),
            child: Column(
              children: [
                Text(
                  _km.toStringAsFixed(2),
                  style: const TextStyle(
                    fontSize: 72,
                    fontWeight: FontWeight.w900,
                    color: Cores.corrida,
                  ),
                ),
                const Text('quilômetros'),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _Dado(titulo: 'Tempo', valor: formatarTempo(_segundos)),
                    _Dado(titulo: 'Ritmo /km', valor: formatarRitmo(_km, _segundos)),
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),

        if (_erro != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Text(
              _erro!,
              style: TextStyle(color: Theme.of(context).colorScheme.error),
            ),
          ),

        // Botões mudam conforme o estado da corrida.
        if (_estado == _Estado.parado)
          FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: Cores.corrida),
            onPressed: _iniciar,
            icon: const Icon(Icons.play_arrow),
            label: const Text('Começar corrida'),
          )
        else
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(backgroundColor: Cores.corrida),
                  onPressed: _estado == _Estado.correndo ? _pausar : _retomar,
                  icon: Icon(_estado == _Estado.correndo ? Icons.pause : Icons.play_arrow),
                  label: Text(_estado == _Estado.correndo ? 'Pausar' : 'Retomar'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton.tonalIcon(
                  onPressed: _finalizar,
                  icon: const Icon(Icons.stop),
                  label: const Text('Finalizar'),
                ),
              ),
            ],
          ),

        const SizedBox(height: 28),
        Text('Seus treinos', style: estilo.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),

        // Histórico: se atualiza sozinho quando um treino é salvo.
        ValueListenableBuilder<int>(
          valueListenable: Armazenamento.mudou,
          builder: (context, _, __) {
            final treinos = Armazenamento.treinos();
            if (treinos.isEmpty) {
              return const Padding(
                padding: EdgeInsets.symmetric(vertical: 16),
                child: Text('Nenhum treino ainda. Bora fazer o primeiro? 🏃'),
              );
            }
            return Column(
              children: [
                for (final t in treinos.take(20))
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const CircleAvatar(
                      backgroundColor: Color(0x26FF6B35),
                      child: Icon(Icons.directions_run, color: Cores.corrida),
                    ),
                    title: Text('${t.km.toStringAsFixed(2)} km'),
                    subtitle: Text(
                      '${formatarData(t.data)} às ${formatarHora(t.data)} · '
                      '${formatarTempo(t.segundos)} · ${formatarRitmo(t.km, t.segundos)} /km',
                    ),
                  ),
              ],
            );
          },
        ),
      ],
    );
  }
}

class _Dado extends StatelessWidget {
  final String titulo;
  final String valor;
  const _Dado({required this.titulo, required this.valor});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(valor, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
        Text(titulo),
      ],
    );
  }
}
