import 'package:flutter/material.dart';

import '../core/tema.dart';
import 'em_breve_tela.dart';

class SaudeTela extends StatelessWidget {
  const SaudeTela({super.key});

  @override
  Widget build(BuildContext context) {
    return const EmBreveTela(
      titulo: 'Saúde',
      icone: Icons.favorite,
      cor: Cores.saude,
      recursos: [
        'Meta diária de água com lembretes',
        'Registro de horas de sono',
        'Contador de passos',
        'Acompanhamento de peso',
      ],
    );
  }
}
