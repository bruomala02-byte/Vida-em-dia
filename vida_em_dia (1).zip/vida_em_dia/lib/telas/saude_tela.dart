import 'package:flutter/material.dart';

import '../core/armazenamento.dart';
import '../core/formatos.dart';
import '../core/tema.dart';
import '../widgets/zoom_tela.dart';
import 'agua_tela.dart';
import 'corpo_perfil_tela.dart';
import 'estudos_leitura_tela.dart';
import 'sono_tela.dart';

/// Parte "Corpo": três cartões compactos (Água, Sono, Peso e corpo).
/// Cada um abre a sua própria página, como acontece com a Leitura.
class CorpoTela extends StatelessWidget {
  const CorpoTela({super.key});

  void _abrir(BuildContext context, Widget pagina) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => ZoomTela(tela: 'saude', child: pagina),
    ));
  }

  String _resumoSono() {
    final noites = Armazenamento.lista('sono');
    if (noites.isEmpty) return 'Registre a hora de dormir e acordar';
    final e = noites.first;
    final min = (e['min'] as int?) ?? (((e['h'] as num) * 60).round());
    final d = e['dormiu'] as String?;
    final a = e['acordou'] as String?;
    final horas = (d != null && a != null) ? '$d → $a · ' : '';
    return 'Última noite: $horas${duracaoMin(min)}';
  }

  String _resumoPeso() {
    final pesos = Armazenamento.lista('pesos');
    if (pesos.isEmpty) return 'Informe peso e altura';
    final kg = (pesos.first['kg'] as num).toDouble();
    final alt = Armazenamento.alturaM();
    var t = '${decimal(kg, 1)} kg';
    if (alt != null) t += ' · ${decimal(alt)} m';
    return t;
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: Armazenamento.mudou,
      builder: (context, _, __) {
        final meta = Armazenamento.metaAgua();
        final ml = Armazenamento.aguaHoje();
        return ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
          children: [
            _Cartao(
              icone: Icons.water_drop_outlined,
              titulo: 'Água',
              linha1: '$ml de $meta ml hoje',
              progresso: (ml / meta).clamp(0.0, 1.0),
              aoTocar: () => _abrir(context, const AguaTela()),
            ),
            _Cartao(
              icone: Icons.bedtime_outlined,
              titulo: 'Sono',
              linha1: _resumoSono(),
              aoTocar: () => _abrir(context, const SonoTela()),
            ),
            _Cartao(
              icone: Icons.monitor_weight_outlined,
              titulo: 'Peso e corpo',
              linha1: _resumoPeso(),
              aoTocar: () => _abrir(context, const CorpoPerfilTela()),
            ),
          ],
        );
      },
    );
  }
}

class _Cartao extends StatelessWidget {
  final IconData icone;
  final String titulo;
  final String linha1;
  final double? progresso;
  final VoidCallback aoTocar;

  const _Cartao({
    required this.icone,
    required this.titulo,
    required this.linha1,
    required this.aoTocar,
    this.progresso,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: aoTocar,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: Row(
            children: [
              CircleAvatar(
                radius: 18,
                backgroundColor: context.destaque.withOpacity(0.15),
                child: Icon(icone, size: 20, color: context.destaque),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(titulo,
                        style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                    const SizedBox(height: 2),
                    Text(linha1, style: Theme.of(context).textTheme.bodySmall),
                    if (progresso != null) ...[
                      const SizedBox(height: 6),
                      LinearProgressIndicator(
                        value: progresso,
                        minHeight: 5,
                        borderRadius: BorderRadius.circular(4),
                        color: context.destaque,
                      ),
                    ],
                  ],
                ),
              ),
              const Icon(Icons.chevron_right, size: 20),
            ],
          ),
        ),
      ),
    );
  }
}


/// Aba Saúde: duas entradas (Corpo e Estudos - Leitura). Cada uma abre uma
/// tela só dela, com a seta de voltar. As telas ficam todas montadas
/// (IndexedStack) para o cronômetro de leitura seguir rodando ao voltar.
class SaudeTela extends StatefulWidget {
  const SaudeTela({super.key});

  @override
  State<SaudeTela> createState() => _SaudeTelaState();
}

class _SaudeTelaState extends State<SaudeTela> {
  int? _aberta; // null = entrada; 0 = Corpo; 1 = Estudos - Leitura

  void _voltar() => setState(() => _aberta = null);

  Widget _cabecalho(BuildContext context) {
    final estilo = Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800);
    return Padding(
      padding: EdgeInsets.fromLTRB(_aberta == null ? 20 : 8, 16, 20, 8),
      child: Row(
        children: [
          if (_aberta != null)
            IconButton(
              tooltip: 'Voltar',
              icon: const Icon(Icons.arrow_back),
              onPressed: _voltar,
            ),
          Expanded(
            child: Text(
              _aberta == null ? 'Saúde' : (_aberta == 0 ? 'Corpo' : 'Estudos - Leitura'),
              style: estilo,
            ),
          ),
        ],
      ),
    );
  }

  Widget _entrada(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: Armazenamento.mudou,
      builder: (context, _, __) {
        final hoje = DateTime.now();
        final ml = Armazenamento.aguaHoje();
        final meta = Armazenamento.metaAgua();
        final minutos =
            (Armazenamento.segLeituraDia(hoje) + Armazenamento.segEstudoDia(hoje)) ~/ 60;
        final metaLeitura = Armazenamento.metaLeitura();
        return ListView(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
          children: [
            _Cartao(
              icone: Icons.favorite,
              titulo: 'Corpo',
              linha1: 'Água, sono, peso e corpo · $ml de $meta ml hoje',
              progresso: (ml / meta).clamp(0.0, 1.0),
              aoTocar: () => setState(() => _aberta = 0),
            ),
            _Cartao(
              icone: Icons.menu_book,
              titulo: 'Estudos - Leitura',
              linha1: 'Livros, estudos e observações · $minutos de $metaLeitura min hoje',
              progresso: (minutos / metaLeitura).clamp(0.0, 1.0),
              aoTocar: () => setState(() => _aberta = 1),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: _aberta == null,
      onPopInvoked: (_) {
        if (_aberta != null) _voltar();
      },
      child: Column(
        children: [
          _cabecalho(context),
          Expanded(
            child: IndexedStack(
              index: _aberta == null ? 0 : _aberta! + 1,
              children: [
                _entrada(context),
                const CorpoTela(),
                const EstudosLeituraTela(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
