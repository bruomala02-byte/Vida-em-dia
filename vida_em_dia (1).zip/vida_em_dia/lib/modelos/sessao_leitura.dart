/// Uma sessão de leitura salva no celular.
class SessaoLeitura {
  final DateTime data;
  final String livro;
  final int segundos;

  const SessaoLeitura({
    required this.data,
    required this.livro,
    required this.segundos,
  });

  Map<String, dynamic> toJson() => {
        'data': data.toIso8601String(),
        'livro': livro,
        's': segundos,
      };

  factory SessaoLeitura.fromJson(Map<String, dynamic> j) => SessaoLeitura(
        data: DateTime.parse(j['data'] as String),
        livro: j['livro'] as String,
        segundos: j['s'] as int,
      );
}
