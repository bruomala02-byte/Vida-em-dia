/// Um treino de corrida salvo no celular.
class Treino {
  final DateTime data;
  final double km;
  final int segundos;

  const Treino({required this.data, required this.km, required this.segundos});

  Map<String, dynamic> toJson() => {
        'data': data.toIso8601String(),
        'km': km,
        's': segundos,
      };

  factory Treino.fromJson(Map<String, dynamic> j) => Treino(
        data: DateTime.parse(j['data'] as String),
        km: (j['km'] as num).toDouble(),
        segundos: j['s'] as int,
      );
}
