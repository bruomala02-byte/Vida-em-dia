import 'package:flutter/material.dart';

import '../core/armazenamento.dart';
import '../core/formatos.dart';
import '../core/periodo.dart';

const _tinta = Color(0xFF14181F);
const _suave = Color(0xFF5F6B7A);
const _linha = Color(0xFFE3E7EC);
const _verde = Color(0xFF1E9E5A);
const _vermelho = Color(0xFFD64545);

enum TipoRelatorio { financas, geral }

/// A "folha" do relatório: sempre fundo branco e texto escuro,
/// para ficar bonita no PDF e no PNG (mesmo com o app no modo escuro).
class FolhaRelatorio extends StatelessWidget {
  final TipoRelatorio tipo;
  final PeriodoRel periodo;
  final Color cor;
  final double largura;

  const FolhaRelatorio({
    super.key,
    required this.tipo,
    required this.periodo,
    required this.cor,
    required this.largura,
  });

  @override
  Widget build(BuildContext context) {
    final filhos = tipo == TipoRelatorio.financas
        ? _financas()
        : _geral();
    final agora = DateTime.now();

    return MediaQuery(
      // texto sempre no tamanho normal, para o arquivo sair igual em qualquer celular
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.noScaling),
      child: Container(
        width: largura,
        color: Colors.white,
        padding: const EdgeInsets.all(16),
        child: DefaultTextStyle(
          style: const TextStyle(color: _tinta, fontSize: 12, height: 1.25),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Container(
                    width: 10,
                    height: 34,
                    decoration: BoxDecoration(color: cor, borderRadius: BorderRadius.circular(4)),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          tipo == TipoRelatorio.financas
                              ? 'Extrato financeiro · ${periodo.nomeTipo}'
                              : 'Resumo geral · ${periodo.nomeTipo}',
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
                        ),
                        Text(periodo.rotulo, style: const TextStyle(color: _suave)),
                      ],
                    ),
                  ),
                  Text('ALVO VITA',
                      style: TextStyle(fontWeight: FontWeight.w900, color: cor, fontSize: 11)),
                ],
              ),
              const SizedBox(height: 12),
              ...filhos,
              const SizedBox(height: 10),
              Text(
                'Gerado em ${formatarData(agora)}/${agora.year} às ${formatarHora(agora)}',
                style: const TextStyle(color: _suave, fontSize: 10),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ------------------------------------------------------------------
  // Peças reutilizáveis
  // ------------------------------------------------------------------
  Widget _titulo(String t) => Padding(
        padding: const EdgeInsets.only(top: 12, bottom: 6),
        child: Text(t, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: cor)),
      );

  Widget _caixa(String rotulo, String valor, Color c) => Expanded(
        child: Container(
          margin: const EdgeInsets.only(right: 6),
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
          decoration: BoxDecoration(
            color: c.withValues(alpha: 0.10),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(rotulo, style: const TextStyle(fontSize: 10, color: _suave)),
              const SizedBox(height: 2),
              FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Text(valor,
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: c)),
              ),
            ],
          ),
        ),
      );

  /// Tabela simples. [direita] = colunas alinhadas à direita (números).
  Widget _tabela({
    required List<String> titulos,
    required List<List<String>> linhas,
    List<String>? total,
    Map<int, TableColumnWidth>? larguras,
    Set<int> direita = const {},
  }) {
    Widget celula(String t, int i,
        {bool negrito = false, Color? fundo, Color? cTexto}) {
      return Container(
        color: fundo,
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 5),
        child: Text(
          t,
          textAlign: direita.contains(i) ? TextAlign.right : TextAlign.left,
          style: TextStyle(
            fontSize: 11,
            fontWeight: negrito ? FontWeight.w800 : FontWeight.w400,
            color: cTexto ?? _tinta,
          ),
        ),
      );
    }

    return Table(
      columnWidths: larguras ?? const {},
      border: const TableBorder(horizontalInside: BorderSide(color: _linha)),
      defaultVerticalAlignment: TableCellVerticalAlignment.middle,
      children: [
        TableRow(children: [
          for (var i = 0; i < titulos.length; i++)
            celula(titulos[i], i,
                negrito: true, fundo: cor.withValues(alpha: 0.14)),
        ]),
        for (final l in linhas)
          TableRow(children: [for (var i = 0; i < l.length; i++) celula(l[i], i)]),
        if (total != null)
          TableRow(children: [
            for (var i = 0; i < total.length; i++)
              celula(total[i], i, negrito: true, fundo: const Color(0xFFF1F3F6)),
          ]),
      ],
    );
  }

  Widget _vazio(String t) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Text(t, style: const TextStyle(color: _suave)),
      );

  // ------------------------------------------------------------------
  // Extrato de finanças
  // ------------------------------------------------------------------
  List<Widget> _financas() {
    final lanc = [
      for (final e in Armazenamento.lista('lancamentos'))
        if (periodo.contem(DateTime.parse(e['data'] as String))) e,
    ]..sort((a, b) => (a['data'] as String).compareTo(b['data'] as String));

    final salario = periodo.salario;
    var ent = salario, sai = 0.0;
    final porCat = <String, double>{};
    final linhas = <List<String>>[];

    if (salario > 0) {
      linhas.add([
        '—',
        periodo.tipo == TipoPeriodo.mes ? 'Salário base' : 'Salário (proporcional)',
        formatarReais(salario),
        '',
      ]);
    }
    for (final e in lanc) {
      final v = (e['valor'] as num).toDouble();
      final d = DateTime.parse(e['data'] as String);
      final cat = (e['cat'] as String?) ?? 'Outros';
      final desc = (e['desc'] as String?) ?? '';
      final entrada = e['tipo'] == 'e';
      if (entrada) {
        ent += v;
      } else {
        sai += v;
        porCat[cat] = (porCat[cat] ?? 0) + v;
      }
      linhas.add([
        formatarData(d),
        desc.isEmpty ? cat : '$desc ($cat)',
        entrada ? formatarReais(v) : '',
        entrada ? '' : formatarReais(v),
      ]);
    }
    final saldo = ent - sai;
    final cats = porCat.entries.toList()..sort((a, b) => b.value.compareTo(a.value));

    return [
      Row(children: [
        _caixa('Entradas', formatarReais(ent), _verde),
        _caixa('Saídas', formatarReais(sai), _vermelho),
        _caixa('Saldo', formatarReais(saldo), saldo >= 0 ? _verde : _vermelho),
      ]),
      _titulo('Lançamentos'),
      if (linhas.isEmpty)
        _vazio('Nenhum lançamento neste período.')
      else
        _tabela(
          titulos: const ['Data', 'Descrição', 'Entrada', 'Saída'],
          linhas: linhas,
          total: ['', 'Total', formatarReais(ent), formatarReais(sai)],
          larguras: const {
            0: FixedColumnWidth(42),
            2: FixedColumnWidth(70),
            3: FixedColumnWidth(70),
          },
          direita: const {2, 3},
        ),
      if (cats.isNotEmpty) ...[
        _titulo('Gastos por categoria'),
        _tabela(
          titulos: const ['Categoria', 'Valor', '%'],
          linhas: [
            for (final c in cats)
              [
                c.key,
                formatarReais(c.value),
                '${(sai > 0 ? c.value / sai * 100 : 0).round()}%',
              ],
          ],
          larguras: const {1: FixedColumnWidth(80), 2: FixedColumnWidth(44)},
          direita: const {1, 2},
        ),
      ],
    ];
  }

  // ------------------------------------------------------------------
  // Resumo geral
  // ------------------------------------------------------------------
  List<Widget> _geral() {
    final out = <Widget>[];

    // ---- Corrida ----
    final treinos = Armazenamento.treinos().where((t) => periodo.contem(t.data)).toList()
      ..sort((a, b) => a.data.compareTo(b.data));
    out.add(_titulo('Corrida e ciclismo'));
    if (treinos.isEmpty) {
      out.add(_vazio('Nenhum treino neste período.'));
    } else {
      final km = treinos.fold<double>(0, (s, t) => s + t.km);
      final seg = treinos.fold<int>(0, (s, t) => s + t.segundos);
      final cal = treinos.fold<int>(0, (s, t) => s + t.calorias);
      final dias = treinos.map((t) => '${t.data.year}-${t.data.month}-${t.data.day}').toSet().length;
      out.add(_tabela(
        titulos: const ['Data', 'Modo', 'Km', 'Tempo', 'kcal'],
        linhas: [
          for (final t in treinos)
            [
              formatarData(t.data),
              t.ehBike ? 'Bike' : 'Corrida',
              decimal(t.km),
              formatarTempo(t.segundos),
              '${t.calorias}',
            ],
        ],
        total: ['${treinos.length}x', 'Total', decimal(km), formatarTempo(seg), '$cal'],
        direita: const {2, 3, 4},
      ));
      if (periodo.tipo != TipoPeriodo.dia) {
        out.add(_vazio('Dias com treino: $dias de ${periodo.dias}.'));
      }
    }

    // ---- Estudos - Leitura ----
    final leituras = Armazenamento.leituras().where((l) => periodo.contem(l.data)).toList()
      ..sort((a, b) => a.data.compareTo(b.data));
    final estudos = [
      for (final e in Armazenamento.lista('estudos'))
        if (periodo.contem(DateTime.parse(e['data'] as String))) e,
    ]..sort((a, b) => (a['data'] as String).compareTo(b['data'] as String));
    final segLeitura = leituras.fold<int>(0, (s, l) => s + l.segundos);
    final segEstudo = estudos.fold<int>(0, (s, e) => s + (e['s'] as int));

    out.add(_titulo('Estudos - Leitura'));
    if (leituras.isEmpty && estudos.isEmpty) {
      out.add(_vazio('Nenhum estudo ou leitura neste período.'));
    } else {
      final dias = <String>{
        for (final l in leituras) '${l.data.year}-${l.data.month}-${l.data.day}',
        for (final e in estudos)
          () {
            final d = DateTime.parse(e['data'] as String);
            return '${d.year}-${d.month}-${d.day}';
          }(),
      }.length;
      out.add(_tabela(
        titulos: const ['Tempo', 'Total'],
        linhas: [
          ['Leitura', formatarDuracao(segLeitura)],
          ['Estudo', formatarDuracao(segEstudo)],
        ],
        total: ['Estudo + leitura', formatarDuracao(segLeitura + segEstudo)],
        direita: const {1},
      ));
      if (periodo.tipo != TipoPeriodo.dia) {
        out.add(_vazio('Dias estudando ou lendo: $dias de ${periodo.dias}.'));
      }
      if (leituras.isNotEmpty) {
        final pag = leituras.fold<int>(0, (s, l) => s + l.paginasLidas);
        out.add(_titulo('Leitura'));
        out.add(_tabela(
          titulos: const ['Data', 'Livro', 'Tempo', 'Págs'],
          linhas: [
            for (final l in leituras)
              [formatarData(l.data), l.livro, formatarDuracao(l.segundos), '${l.paginasLidas}'],
          ],
          total: ['', 'Total', formatarDuracao(segLeitura), '$pag'],
          larguras: const {
            0: FixedColumnWidth(42),
            2: FixedColumnWidth(54),
            3: FixedColumnWidth(44),
          },
          direita: const {2, 3},
        ));
      }
      if (estudos.isNotEmpty) {
        out.add(_titulo('Estudo'));
        out.add(_tabela(
          titulos: const ['Data', 'Matéria · tipo', 'Tempo'],
          linhas: [
            for (final e in estudos)
              [
                formatarData(DateTime.parse(e['data'] as String)),
                '${((e['materia'] as String?) ?? '').trim().isEmpty ? 'Sem matéria' : (e['materia'] as String).trim()}'
                    ' · ${e['tipo'] ?? 'Estudo'}',
                formatarDuracao(e['s'] as int),
              ],
          ],
          total: ['', 'Total', formatarDuracao(segEstudo)],
          larguras: const {0: FixedColumnWidth(42), 2: FixedColumnWidth(54)},
          direita: const {2},
        ));
      }
    }

    // ---- Saúde ----
    out.add(_titulo('Saúde'));
    final linhasSaude = <List<String>>[];
    final agua = [
      for (final e in Armazenamento.lista('agua'))
        if (periodo.contem(DateTime.parse(e['data'] as String))) e,
    ];
    if (agua.isNotEmpty) {
      final porDia = <String, int>{};
      for (final e in agua) {
        final d = DateTime.parse(e['data'] as String);
        final k = '${d.year}-${d.month}-${d.day}';
        porDia[k] = (porDia[k] ?? 0) + (e['ml'] as int);
      }
      final total = porDia.values.fold<int>(0, (s, v) => s + v);
      linhasSaude.add([
        'Água',
        periodo.tipo == TipoPeriodo.dia
            ? '$total ml (meta ${Armazenamento.metaAgua()} ml)'
            : 'média de ${(total / porDia.length).round()} ml por dia (${porDia.length} dia(s))',
      ]);
    }
    final sono = [
      for (final e in Armazenamento.lista('sono'))
        if (periodo.contem(DateTime.parse(e['data'] as String))) e,
    ];
    if (sono.isNotEmpty) {
      final mins = [
        for (final e in sono) (e['min'] as int?) ?? (((e['h'] as num) * 60).round()),
      ];
      final media = mins.fold<int>(0, (s, v) => s + v) ~/ mins.length;
      linhasSaude.add([
        'Sono',
        periodo.tipo == TipoPeriodo.dia
            ? duracaoMin(mins.first)
            : 'média de ${duracaoMin(media)} por noite (${mins.length} noite(s))',
      ]);
    }
    final pesos = [
      for (final e in Armazenamento.lista('pesos'))
        if (periodo.contem(DateTime.parse(e['data'] as String))) e,
    ]..sort((a, b) => (a['data'] as String).compareTo(b['data'] as String));
    if (pesos.isNotEmpty) {
      final p = (pesos.first['kg'] as num).toDouble();
      final u = (pesos.last['kg'] as num).toDouble();
      linhasSaude.add([
        'Peso',
        pesos.length == 1 ? '${decimal(u, 1)} kg' : '${decimal(p, 1)} kg → ${decimal(u, 1)} kg',
      ]);
    }
    if (linhasSaude.isEmpty) {
      out.add(_vazio('Sem registros de saúde neste período.'));
    } else {
      out.add(_tabela(
        titulos: const ['Item', 'Resultado'],
        linhas: linhasSaude,
        larguras: const {0: FixedColumnWidth(60)},
      ));
    }

    // ---- Finanças ----
    out.add(_titulo('Finanças'));
    var ent = periodo.salario, sai = 0.0;
    for (final e in Armazenamento.lista('lancamentos')) {
      if (!periodo.contem(DateTime.parse(e['data'] as String))) continue;
      final v = (e['valor'] as num).toDouble();
      if (e['tipo'] == 'e') {
        ent += v;
      } else {
        sai += v;
      }
    }
    out.add(_tabela(
      titulos: const ['Item', 'Valor'],
      linhas: [
        ['Entradas', formatarReais(ent)],
        ['Saídas', formatarReais(sai)],
      ],
      total: ['Saldo', formatarReais(ent - sai)],
      direita: const {1},
    ));
    return out;
  }
}
