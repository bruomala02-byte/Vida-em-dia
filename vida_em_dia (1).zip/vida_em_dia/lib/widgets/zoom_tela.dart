import 'package:flutter/material.dart';

import '../core/config.dart';

/// Aplica o zoom escolhido (em Configurações) a uma tela inteira:
/// aumenta ou diminui os textos e os ícones padrão.
class ZoomTela extends StatelessWidget {
  final String tela;
  final Widget child;
  const ZoomTela({super.key, required this.tela, required this.child});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: Config.zoom[tela]!,
      builder: (context, percentual, _) {
        final fator = percentual / 100;
        final mq = MediaQuery.of(context);
        return MediaQuery(
          data: mq.copyWith(
            textScaler: TextScaler.linear(mq.textScaler.scale(1) * fator),
          ),
          child: IconTheme(
            data: IconTheme.of(context).copyWith(
              size: (IconTheme.of(context).size ?? 24) * fator,
            ),
            child: child,
          ),
        );
      },
    );
  }
}
