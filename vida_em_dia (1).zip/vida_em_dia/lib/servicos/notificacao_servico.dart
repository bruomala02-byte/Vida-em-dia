import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

import '../core/armazenamento.dart';
import '../core/formatos.dart';

/// Lembretes do app: beber água (vários horários) e estudar (1 por dia).
/// Tudo é agendado no próprio celular; não precisa de internet.
class NotificacaoServico {
  static final _plugin = FlutterLocalNotificationsPlugin();
  static bool _pronto = false;

  static const horariosAguaPadrao = [10 * 60, 12 * 60, 18 * 60];
  static const _idAgua = 100; // 100 a 139
  static const _idEstudo = 1;

  // ---------- Configurações guardadas ----------
  static bool aguaLigada() => Armazenamento.lerBool('agua_lembretes') ?? true;

  static List<int> horariosAgua() {
    final t = Armazenamento.lerTexto('agua_horarios');
    if (t == null) return List<int>.from(horariosAguaPadrao);
    try {
      final l = (jsonDecode(t) as List).map((e) => (e as num).toInt()).toList()..sort();
      return l;
    } catch (_) {
      return List<int>.from(horariosAguaPadrao);
    }
  }

  static Future<void> salvarHorariosAgua(List<int> horarios) async {
    final unicos = horarios.toSet().toList()..sort();
    await Armazenamento.salvarTexto('agua_horarios', jsonEncode(unicos.take(30).toList()));
    await reagendarAgua();
  }

  static Future<void> ligarAgua(bool ligado) async {
    await Armazenamento.salvarBool('agua_lembretes', ligado);
    await reagendarAgua();
  }

  static bool estudoLigado() => Armazenamento.lerBool('estudo_lembrete') ?? false;
  static int horaEstudo() => Armazenamento.lerInt('estudo_hora') ?? 20 * 60;

  static Future<void> ligarEstudo(bool ligado) async {
    await Armazenamento.salvarBool('estudo_lembrete', ligado);
    await reagendarEstudo();
  }

  static Future<void> definirHoraEstudo(int minutos) async {
    await Armazenamento.salvarInt('estudo_hora', minutos);
    await reagendarEstudo();
  }

  // ---------- Funcionamento ----------
  static Future<void> iniciar() async {
    try {
      tzdata.initializeTimeZones();
      try {
        final nome = await FlutterTimezone.getLocalTimezone();
        tz.setLocalLocation(tz.getLocation(nome));
      } catch (_) {
        // sem o fuso, usa UTC: os lembretes ainda funcionam, só podem
        // sair em horário diferente
      }
      await _plugin.initialize(const InitializationSettings(
        android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      ));
      final android = _plugin
          .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      await android?.requestNotificationsPermission();
      // Alarme exato: sem isso o Android atrasa os lembretes em vários minutos.
      try {
        await android?.requestExactAlarmsPermission();
      } catch (_) {}
      _pronto = true;
      await reagendarAgua();
      await reagendarEstudo();
    } catch (_) {
      // Lembretes são um extra: se falhar, o resto do app segue normal.
    }
  }

  static tz.TZDateTime _proxima(int minutos, {bool pularHoje = false}) {
    final agora = tz.TZDateTime.now(tz.local);
    var d = tz.TZDateTime(
        tz.local, agora.year, agora.month, agora.day, minutos ~/ 60, minutos % 60);
    if (pularHoje || !d.isAfter(agora)) d = d.add(const Duration(days: 1));
    return d;
  }

  static Future<void> _agendar({
    required int id,
    required String titulo,
    required String corpo,
    required int minutos,
    required String canal,
    required String nomeCanal,
    bool pularHoje = false,
  }) async {
    final detalhes = NotificationDetails(
      android: AndroidNotificationDetails(
        canal,
        nomeCanal,
        channelDescription: 'Lembretes do Alvo Vita',
        importance: Importance.high,
        priority: Priority.high,
        category: AndroidNotificationCategory.reminder,
      ),
    );
    final quando = _proxima(minutos, pularHoje: pularHoje);
    try {
      // horário exato (precisa da permissão de alarmes e lembretes)
      await _plugin.zonedSchedule(
        id,
        titulo,
        corpo,
        quando,
        detalhes,
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        matchDateTimeComponents: DateTimeComponents.time, // repete todo dia
      );
    } catch (_) {
      // sem a permissão de alarme exato: usa o modo aproximado
      await _plugin.zonedSchedule(
        id,
        titulo,
        corpo,
        quando,
        detalhes,
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        matchDateTimeComponents: DateTimeComponents.time,
      );
    }
  }

  static Future<void> reagendarAgua() async {
    if (!_pronto) return;
    try {
      for (var i = 0; i < 40; i++) {
        await _plugin.cancel(_idAgua + i);
      }
      if (!aguaLigada()) return;
      final hs = horariosAgua();
      for (var i = 0; i < hs.length && i < 40; i++) {
        await _agendar(
          id: _idAgua + i,
          titulo: 'Hora de beber água 💧',
          corpo: 'Um copo agora ajuda a bater a meta de hoje.',
          minutos: hs[i],
          canal: 'agua',
          nomeCanal: 'Lembrete de água',
        );
      }
    } catch (_) {}
  }

  /// Se você já estudou hoje, o primeiro aviso fica para amanhã.
  static Future<void> reagendarEstudo() async {
    if (!_pronto) return;
    try {
      await _plugin.cancel(_idEstudo);
      if (!estudoLigado()) return;
      final agora = DateTime.now();
      final estudouHoje = Armazenamento.leituras().any((l) => mesmoDia(l.data, agora)) ||
          Armazenamento.lista('estudos').any((e) => mesmoDia(DateTime.parse(e['data'] as String), agora));
      await _agendar(
        id: _idEstudo,
        titulo: 'Hora de estudar 📚',
        corpo: 'Você ainda não registrou estudos hoje.',
        minutos: horaEstudo(),
        canal: 'estudo',
        nomeCanal: 'Lembrete de estudo',
        pularHoje: estudouHoje,
      );
    } catch (_) {}
  }

  static Future<void> testar() async {
    if (!_pronto) return;
    await _plugin.show(
      9,
      'Alvo Vita',
      'Os lembretes estão funcionando! 🎯',
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'teste',
          'Teste',
          channelDescription: 'Teste de notificação',
          importance: Importance.high,
          priority: Priority.high,
        ),
      ),
    );
  }

  static bool get disponivel => _pronto;

  static const _idSinal = 20;
  static const _idDesvio = 22;

  /// Aviso simples e imediato durante a corrida (sinal perdido, sinal de volta...).
  static Future<void> avisoCorrida(String titulo, String corpo) async {
    if (!_pronto) return;
    try {
      await _plugin.show(
        _idSinal,
        titulo,
        corpo,
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'corrida',
            'Avisos da corrida',
            channelDescription: 'Avisos sobre o GPS durante a corrida',
            importance: Importance.max,
            priority: Priority.high,
          ),
        ),
      );
    } catch (_) {}
  }

  /// Alerta que vibra sem parar (a notificação "insistente" repete a vibração
  /// até ser cancelada) quando a pessoa não está seguindo o percurso marcado.
  static Future<void> alertaDesvio(bool ligar) async {
    if (!_pronto) return;
    try {
      if (!ligar) {
        await _plugin.cancel(_idDesvio);
        return;
      }
      await _plugin.show(
        _idDesvio,
        'Siga o percurso marcado! ⚠️',
        'Você não está passando pelos pontos marcados. Continue o percurso ou '
            'desative o alerta no app.',
        NotificationDetails(
          android: AndroidNotificationDetails(
            'desvio',
            'Alerta de percurso',
            channelDescription: 'Vibra até você seguir o percurso marcado',
            importance: Importance.max,
            priority: Priority.high,
            playSound: false,
            enableVibration: true,
            vibrationPattern: Int64List.fromList([0, 700, 500, 700, 500]),
            ongoing: true,
            autoCancel: false,
            additionalFlags: Int32List.fromList(<int>[4]), // FLAG_INSISTENT
          ),
        ),
      );
    } catch (_) {}
  }

  static Future<void> limparAvisosCorrida() async {
    if (!_pronto) return;
    try {
      await _plugin.cancel(_idSinal);
      await _plugin.cancel(_idDesvio);
    } catch (_) {}
  }
}
