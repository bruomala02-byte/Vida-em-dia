import 'package:flutter/material.dart';

import 'core/armazenamento.dart';
import 'core/tema.dart';
import 'telas/navegacao.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Armazenamento.iniciar();
  runApp(const VidaEmDiaApp());
}

class VidaEmDiaApp extends StatelessWidget {
  const VidaEmDiaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Vida em Dia',
      debugShowCheckedModeBanner: false,
      theme: criarTema(Brightness.light),
      darkTheme: criarTema(Brightness.dark),
      themeMode: ThemeMode.system,
      home: const Navegacao(),
    );
  }
}
