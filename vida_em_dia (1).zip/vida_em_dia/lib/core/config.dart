import 'package:flutter/material.dart';

import 'armazenamento.dart';

/// Configurações do app: modo escuro e zoom de cada tela.
/// Tudo fica salvo no celular.
class Config {
  /// Telas que têm zoom próprio.
  static const telas = ['hoje', 'corrida', 'saude', 'financas'];

  static const rotulos = {
    'hoje': 'Hoje',
    'corrida': 'Corrida',
    'saude': 'Saúde',
    'financas': 'Finanças',
  };

  /// Zoom padrão de cada tela, em %. É aqui que fica a "alteração fixa":
  /// depois de testar, é só dizer os valores que ficaram bons.
  static const zoomPadrao = {
    'hoje': 100,
    'corrida': 90,
    'saude': 100,
    'financas': 94,
  };

  static const zoomMin = 80;
  static const zoomMax = 120;

  static final ValueNotifier<ThemeMode> modoTema = ValueNotifier(ThemeMode.system);

  static final Map<String, ValueNotifier<int>> zoom = {
    for (final t in telas) t: ValueNotifier<int>(zoomPadrao[t]!),
  };

  static void carregar() {
    final m = Armazenamento.lerInt('modo_tema');
    if (m != null && m >= 0 && m < ThemeMode.values.length) {
      modoTema.value = ThemeMode.values[m];
    }
    for (final t in telas) {
      final z = Armazenamento.lerInt('zoom_$t');
      if (z != null) zoom[t]!.value = z.clamp(zoomMin, zoomMax);
    }
  }

  static Future<void> definirModo(ThemeMode modo) async {
    modoTema.value = modo;
    await Armazenamento.salvarInt('modo_tema', modo.index, avisar: false);
  }

  static Future<void> definirZoom(String tela, int percentual) async {
    final p = percentual.clamp(zoomMin, zoomMax);
    zoom[tela]!.value = p;
    await Armazenamento.salvarInt('zoom_$tela', p, avisar: false);
  }

  static Future<void> restaurarZoom() async {
    for (final t in telas) {
      await definirZoom(t, zoomPadrao[t]!);
    }
  }
}
