import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../modelos/livro.dart';
import '../modelos/sessao_leitura.dart';
import 'formatos.dart';
import '../modelos/treino.dart';

/// Guarda tudo no próprio celular (sem internet, sem login).
/// Mais para frente dá para trocar por SQLite sem mexer nas telas.
class Armazenamento {
  static late SharedPreferences _prefs;

  /// Sobe de número toda vez que algo é salvo.
  /// A tela "Hoje" escuta isso para se atualizar sozinha.
  static final ValueNotifier<int> mudou = ValueNotifier(0);

  static Future<void> iniciar() async {
    _prefs = await SharedPreferences.getInstance();
  }

  static List<Map<String, dynamic>> _ler(String chave) {
    final texto = _prefs.getString(chave);
    if (texto == null) return [];
    return (jsonDecode(texto) as List).cast<Map<String, dynamic>>();
  }

  static Future<void> _adicionar(String chave, Map<String, dynamic> item) async {
    final lista = _ler(chave)..insert(0, item); // mais novo primeiro
    await _prefs.setString(chave, jsonEncode(lista));
    mudou.value++;
  }

  // ---- Corrida ----
  static List<Treino> treinos() => _ler('treinos').map(Treino.fromJson).toList();

  static Future<void> salvarTreino(Treino t) => _adicionar('treinos', t.toJson());

  // ---- Leitura ----
  static List<SessaoLeitura> leituras() =>
      _ler('leituras').map(SessaoLeitura.fromJson).toList();

  static Future<void> salvarLeitura(SessaoLeitura s) =>
      _adicionar('leituras', s.toJson());

  // ---- Livros ----
  static List<Livro> livros() => _ler('livros').map(Livro.fromJson).toList();

  static Future<void> salvarLivro(Livro l) => _adicionar('livros', l.toJson());

  /// Apaga o livro e todo o histórico de leitura dele.
  static Future<void> removerLivro(int id) async {
    final ls = _ler('livros')..removeWhere((e) => e['id'] == id);
    final ss = _ler('leituras')..removeWhere((e) => e['lid'] == id);
    await _prefs.setString('livros', jsonEncode(ls));
    await _prefs.setString('leituras', jsonEncode(ss));
    await _prefs.remove('pag_$id');
    mudou.value++;
  }

  /// Apaga uma única sessão de leitura (a que tem esse início e esse livro).
  static Future<void> removerLeitura(SessaoLeitura s) async {
    final ss = _ler('leituras');
    final i = ss.indexWhere(
        (e) => e['data'] == s.data.toIso8601String() && e['lid'] == s.livroId);
    if (i < 0) return;
    ss.removeAt(i);
    await _prefs.setString('leituras', jsonEncode(ss));
    mudou.value++;
  }

  static List<SessaoLeitura> sessoesDoLivro(int id) =>
      leituras().where((s) => s.livroId == id).toList();

  /// Página onde parou na última leitura (0 se ainda não leu).
  static int paginaAtual(int id) {
    final l = sessoesDoLivro(id);
    // Se o histórico foi apagado, usa a página guardada antes de apagar.
    return l.isEmpty ? (_prefs.getInt('pag_$id') ?? 0) : l.first.paginaFim;
  }

  // ---- Cor do app ----
  static int? corSalva() => _prefs.getInt('cor_app');
  static Future<void> salvarCor(int valor) => _prefs.setInt('cor_app', valor);

  // ---- Genérico (Saúde e Finanças) ----
  // Listas com o item mais novo primeiro.
  static List<Map<String, dynamic>> lista(String chave) => _ler(chave);

  static Future<void> adicionar(String chave, Map<String, dynamic> item) =>
      _adicionar(chave, item);

  static Future<void> remover(String chave, int indice) async {
    final l = _ler(chave)..removeAt(indice);
    await _prefs.setString(chave, jsonEncode(l));
    mudou.value++;
  }

  // ---- Resumos usados em mais de uma tela ----
  /// Último peso registrado (70 kg se ainda não houver). Usado nas calorias.
  static double pesoAtual() {
    final l = _ler('pesos');
    return l.isEmpty ? 70.0 : (l.first['kg'] as num).toDouble();
  }

  /// Segundos de leitura num dia (livros).
  static int segLeituraDia(DateTime d) => _ler('leituras')
      .where((e) => mesmoDia(DateTime.parse(e['data'] as String), d))
      .fold<int>(0, (s, e) => s + (e['s'] as int));

  /// Segundos de estudo num dia (matérias, videoaulas...).
  static int segEstudoDia(DateTime d) => _ler('estudos')
      .where((e) => mesmoDia(DateTime.parse(e['data'] as String), d))
      .fold<int>(0, (s, e) => s + (e['s'] as int));

  /// Minutos de estudo feitos hoje (não conta leitura).
  static int minutosEstudoHoje() => segEstudoDia(DateTime.now()) ~/ 60;

  static int aguaHoje() => _ler('agua')
      .where((e) => mesmoDia(DateTime.parse(e['data'] as String), DateTime.now()))
      .fold<int>(0, (s, e) => s + (e['ml'] as int));

  static double saldoMes() {
    final agora = DateTime.now();
    var saldo = salarioBase(); // salário base entra todo mês
    for (final e in _ler('lancamentos')) {
      final d = DateTime.parse(e['data'] as String);
      if (d.year != agora.year || d.month != agora.month) continue;
      final v = (e['valor'] as num).toDouble();
      saldo += e['tipo'] == 'e' ? v : -v;
    }
    return saldo;
  }

  // ---- Metas (a pessoa pode mudar) ----
  /// Meta de água: a que a pessoa escolheu, ou a calculada pelo peso (35 ml por kg),
  /// ou 2000 ml se ainda não há peso registrado.
  static bool metaAguaManual() => _prefs.containsKey('meta_agua');

  static int metaAguaSugerida() {
    final l = _ler('pesos');
    if (l.isEmpty) return 2000;
    final kg = (l.first['kg'] as num).toDouble();
    return ((kg * 35) / 50).round() * 50;
  }

  static int metaAgua() => _prefs.getInt('meta_agua') ?? metaAguaSugerida();

  static Future<void> usarMetaAguaAutomatica() async {
    await _prefs.remove('meta_agua');
    mudou.value++;
  }
  static int metaLeitura() => _prefs.getInt('meta_leitura') ?? 30;

  static Future<void> salvarMetaAgua(int ml) async {
    await _prefs.setInt('meta_agua', ml);
    mudou.value++;
  }

  static Future<void> salvarMetaLeitura(int minutos) async {
    await _prefs.setInt('meta_leitura', minutos);
    mudou.value++;
  }

  // ---- Apagar um treino ----
  static Future<void> removerTreino(Treino t) async {
    final l = _ler('treinos');
    final i = l.indexWhere((e) => e['data'] == t.data.toIso8601String());
    if (i < 0) return;
    l.removeAt(i);
    await _prefs.setString('treinos', jsonEncode(l));
    mudou.value++;
  }

  // ---- Histórico por mês (check-in e limpeza) ----
  // Listas que têm um campo 'data' e podem ser separadas por mês.
  // Os livros não entram: eles ficam, só o histórico de leitura é apagado.
  static const _chavesComData = [
    'treinos', 'leituras', 'estudos', 'agua', 'sono', 'pesos', 'lancamentos',
  ];

  static bool _noMes(Map<String, dynamic> e, int ano, int mes) {
    final d = DateTime.parse(e['data'] as String);
    return d.year == ano && d.month == mes;
  }

  /// Registros de uma lista (ex.: 'agua') que são de um mês.
  static List<Map<String, dynamic>> doMes(String chave, int ano, int mes) =>
      _ler(chave).where((e) => _noMes(e, ano, mes)).toList();

  /// Meses que têm algum registro, do mais novo para o mais antigo: (ano, mês).
  static List<(int, int)> mesesComDados() {
    final achados = <int>{};
    for (final c in _chavesComData) {
      for (final e in _ler(c)) {
        final d = DateTime.parse(e['data'] as String);
        achados.add(d.year * 100 + d.month);
      }
    }
    final ordenados = achados.toList()..sort((a, b) => b.compareTo(a));
    return [for (final v in ordenados) (v ~/ 100, v % 100)];
  }

  /// Apaga tudo de um mês (corridas, leituras, saúde e finanças).
  static Future<void> apagarMes(int ano, int mes) async {
    // Antes de apagar, guarda em que página cada livro parou.
    for (final l in livros()) {
      final p = paginaAtual(l.id);
      if (p > 0) await _prefs.setInt('pag_${l.id}', p);
    }
    for (final c in _chavesComData) {
      final l = _ler(c)..removeWhere((e) => _noMes(e, ano, mes));
      await _prefs.setString(c, jsonEncode(l));
    }
    mudou.value++;
  }

  // ---- Tamanho do histórico ----
  /// Aviso aparece quando o histórico passa de ~500 mil caracteres
  /// (mais ou menos 25 corridas com mapa). Antes de o app ficar pesado.
  static const limiteAviso = 500000;

  static int tamanhoHistorico() {
    var total = 0;
    for (final c in [..._chavesComData, 'livros']) {
      total += _prefs.getString(c)?.length ?? 0;
    }
    return total;
  }

  static bool historicoGrande() => tamanhoHistorico() >= limiteAviso;

  // ---- Salário base (fica salvo, só muda se a pessoa quiser) ----
  static double salarioBase() => _prefs.getDouble('salario_base') ?? 0;

  static Future<void> salvarSalarioBase(double v) async {
    await _prefs.setDouble('salario_base', v);
    mudou.value++;
  }

  // ---- Perfil do corpo (altura em metros, idade opcional) ----
  static double? alturaM() => _prefs.getDouble('altura_m');
  static int? idade() => _prefs.getInt('idade');

  static Future<void> salvarPerfil({double? alturaM, int? idade}) async {
    if (alturaM != null) await _prefs.setDouble('altura_m', alturaM);
    if (idade != null) {
      await _prefs.setInt('idade', idade);
    } else {
      await _prefs.remove('idade');
    }
    mudou.value++;
  }

  // ---- Editar um item de uma lista (ex.: uma noite de sono) ----
  static Future<void> substituir(String chave, int indice, Map<String, dynamic> item) async {
    final l = _ler(chave);
    if (indice < 0 || indice >= l.length) return;
    l[indice] = item;
    await _prefs.setString(chave, jsonEncode(l));
    mudou.value++;
  }

  // ---- Configurações simples (zoom, modo escuro, horários do sono...) ----
  // [avisar] = false evita redesenhar o app inteiro (usado no zoom).
  static int? lerInt(String k) => _prefs.getInt(k);
  static String? lerTexto(String k) => _prefs.getString(k);
  static bool? lerBool(String k) => _prefs.getBool(k);

  static Future<void> salvarInt(String k, int v, {bool avisar = true}) async {
    await _prefs.setInt(k, v);
    if (avisar) mudou.value++;
  }

  static Future<void> salvarTexto(String k, String v) async {
    await _prefs.setString(k, v);
    mudou.value++;
  }

  /// Salva sem avisar as telas (usado no rascunho da corrida, a cada poucos segundos).
  static Future<void> salvarTextoSilencioso(String k, String v) => _prefs.setString(k, v);

  static Future<void> removerChave(String k) => _prefs.remove(k);

  static Future<void> salvarBool(String k, bool v) async {
    await _prefs.setBool(k, v);
    mudou.value++;
  }
}
