import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../modelos/sessao_leitura.dart';
import '../modelos/treino.dart';

/// Guarda tudo no próprio celular (sem internet, sem login).
/// Mais para frente dá para trocar por SQLite sem mexer nas telas.
class Armazenamento {
  static late SharedPreferences _prefs;

  /// Sobe de número toda vez que algo é salvo.
  /// A tela "Hoje" escuta isso para se atualizar sozinha.
  static final ValueNotifier<int> mudou = ValueNotifier(0);

  static Future<void> iniciar() async {
    _prefs = await SharedPreferences.getInstance();
  }

  static List<Map<String, dynamic>> _ler(String chave) {
    final texto = _prefs.getString(chave);
    if (texto == null) return [];
    return (jsonDecode(texto) as List).cast<Map<String, dynamic>>();
  }

  static Future<void> _adicionar(String chave, Map<String, dynamic> item) async {
    final lista = _ler(chave)..insert(0, item); // mais novo primeiro
    await _prefs.setString(chave, jsonEncode(lista));
    mudou.value++;
  }

  // ---- Corrida ----
  static List<Treino> treinos() => _ler('treinos').map(Treino.fromJson).toList();

  static Future<void> salvarTreino(Treino t) => _adicionar('treinos', t.toJson());

  // ---- Leitura ----
  static List<SessaoLeitura> leituras() =>
      _ler('leituras').map(SessaoLeitura.fromJson).toList();

  static Future<void> salvarLeitura(SessaoLeitura s) =>
      _adicionar('leituras', s.toJson());
}
