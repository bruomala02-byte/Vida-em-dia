/// Funções pequenas para mostrar tempo, ritmo e datas de forma bonita.

String _doisDigitos(int n) => n.toString().padLeft(2, '0');

/// 3725 segundos -> "1:02:05"  |  125 segundos -> "02:05"
String formatarTempo(int segundos) {
  final h = segundos ~/ 3600;
  final m = (segundos % 3600) ~/ 60;
  final s = segundos % 60;
  if (h > 0) return '$h:${_doisDigitos(m)}:${_doisDigitos(s)}';
  return '${_doisDigitos(m)}:${_doisDigitos(s)}';
}

/// Ritmo = minutos por km. Ex.: 5:30 /km
String formatarRitmo(double km, int segundos) {
  if (km < 0.05 || segundos == 0) return '--:--';
  final total = (segundos / km).round();
  return '${total ~/ 60}:${_doisDigitos(total % 60)}';
}

/// 17/11
String formatarData(DateTime d) => '${_doisDigitos(d.day)}/${_doisDigitos(d.month)}';

/// 23:41
String formatarHora(DateTime d) => '${_doisDigitos(d.hour)}:${_doisDigitos(d.minute)}';

bool mesmoDia(DateTime a, DateTime b) =>
    a.year == b.year && a.month == b.month && a.day == b.day;

/// "Bom dia", "Boa tarde" ou "Boa noite"
String saudacao() {
  final h = DateTime.now().hour;
  if (h < 12) return 'Bom dia';
  if (h < 18) return 'Boa tarde';
  return 'Boa noite';
}
